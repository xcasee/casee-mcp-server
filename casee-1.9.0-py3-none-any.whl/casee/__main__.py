"""casee CLI 入口。

支持命令行搜索：

    # 快速检索
    casee search "AI,Nvidia" --days 30 --api-key sk_xxx

    # 高级检索
    casee searchx "+EV +(battery|charging) -China" --source-ids reuters,bloomberg --min-tscore 0.6

    # 语义检索（基于 CVC 模型）
    casee semantic cvc_9f8e7d6c "竞争对手在东南亚的电动化布局战略" --mode hybrid --top-k 20

    # 信源检索
    casee sources --category wire --min-tscore 0.7

    # 统计
    casee stats

    # 列出所有信源
    casee sources --list

    # 枚举过滤值
    casee locations

环境变量：
    CASEE_API_KEY            — API Key
    CASEE_API_BASE_URL       — API 基址（默认 http://121.43.113.132:8000）
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Dict, List, Optional

from . import __version__
from .exceptions import CaseeError
from .search import (
    IntelligenceSearch,
    get_locations,
    get_stats,
    list_sources,
    search_advanced,
    search_sources,
)
from .search import semantic_search as semantic_search_fn


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="casee",
        description="CaSee Intelligence CLI — 情报检索命令行工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
子命令:
  search    快速检索（简单关键词 + 时间窗口）
  searchx   高级检索（AND/OR/NOT/短语 + 信源过滤 + tscore + 精确时间窗口）
  semantic  语义检索（基于 CVC 模型的两阶段混合检索）
  sources   信源检索（发现可信信源）
  stats     情报集合统计
  locations 过滤值枚举

示例:
  # 快速检索
  casee search "AI,Nvidia" --days 30

  # 快速检索（预设时间范围 + 关闭回退）
  casee search "AI,Nvidia" --time-range 7d --no-fallback

  # 高级检索（查询语法）
  casee searchx "+EV +(battery|charging) -China" --source-ids reuters,bloomberg --min-tscore 0.6

  # 高级检索（高级参数 + 预设时间范围）
  casee searchx --must-keywords EV,battery --not-keywords China --time-range 3m

  # 语义检索（混合模式）
  casee semantic cvc_9f8e7d6c "竞争对手在东南亚的电动化布局战略" --mode hybrid --top-k 20

  # 信源检索
  casee sources --category wire --min-tscore 0.7 --sample-size 3

  # 统计
  casee stats

  # 枚举过滤值
  casee locations

环境变量:
  CASEE_API_KEY            API Key
  CASEE_API_BASE_URL       API 基址（默认 http://121.43.113.132:8000）
  CASEE_TIMEOUT            请求超时秒数（默认 30）
""",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    subparsers = parser.add_subparsers(dest="command", help="子命令")

    # ---- search（快速检索）----
    search_p = subparsers.add_parser("search", help="快速检索：简单关键词 + 时间窗口")
    search_p.add_argument("q", type=str, nargs="?", default=None,
                          help="查询关键词（逗号分隔，OR 逻辑）")
    search_p.add_argument("--days", type=int, default=30, help="时间窗口（天），默认 30")
    search_p.add_argument("--time-range", dest="time_range", type=str, default=None,
                          help="预设时间范围：1d/7d/1m/3m（优先于 days）")
    search_p.add_argument("--start-date", dest="start_date", type=str, default=None,
                          help="起始日期 YYYY-MM-DD（优先于 time_range/days）")
    search_p.add_argument("--end-date", dest="end_date", type=str, default=None,
                          help="结束日期 YYYY-MM-DD")
    search_p.add_argument("--cvc-model-id", dest="cvc_model_id", type=str, default=None,
                          help="CVC 模型 ID（传入时检索结果异步归集到语义检索库）")
    search_p.add_argument("--category", type=str, default=None, help="信源类别过滤")
    search_p.add_argument("--region", type=str, default=None, help="信源地区过滤")
    search_p.add_argument("--language", type=str, default=None, help="信源语言过滤")
    search_p.add_argument("--min-tscore", dest="min_tscore", type=float, default=0.0,
                          help="最低 tscore（0.0-1.0）")
    search_p.add_argument("--limit", type=int, default=50, help="返回条数上限，默认 50")
    search_p.add_argument("--fallback", dest="fallback", action="store_true", default=False,
                          help="无结果时启用 Google News 回退检索（[v1.8 FIX-S3] 默认关闭）")
    search_p.add_argument("--no-fallback", dest="fallback", action="store_false",
                          help="关闭 Google News 回退检索")
    search_p.add_argument("--min-content-words", dest="min_content_words", type=int, default=200,
                          help="最低正文字数过滤（0=不过滤，默认 200）")
    _add_auth_args(search_p)
    _add_output_args(search_p)

    # ---- searchx（高级检索）----
    searchx_p = subparsers.add_parser("searchx", help="高级检索：AND/OR/NOT/短语 + 信源过滤 + tscore")
    searchx_p.add_argument("q", type=str, nargs="?", default=None,
                           help="查询语法字符串（类 Google 语法）")
    searchx_p.add_argument("--must-keywords", dest="must_keywords", type=str, default=None,
                           help="AND 关键词（逗号分隔）")
    searchx_p.add_argument("--should-keywords", dest="should_keywords", type=str, default=None,
                           help="OR 关键词（逗号分隔）")
    searchx_p.add_argument("--not-keywords", dest="not_keywords", type=str, default=None,
                           help="NOT 排除关键词（逗号分隔）")
    searchx_p.add_argument("--phrase-keywords", dest="phrase_keywords", type=str, default=None,
                           help="精确短语（逗号分隔）")
    searchx_p.add_argument("--keywords", type=str, default=None,
                           help="[兼容] 逗号分隔关键词（OR 逻辑）")
    searchx_p.add_argument("--days", type=int, default=30, help="时间窗口（天），默认 30")
    searchx_p.add_argument("--time-range", dest="time_range", type=str, default=None,
                           help="预设时间范围：1d/7d/1m/3m（优先于 days）")
    searchx_p.add_argument("--start-date", dest="start_date", type=str, default=None,
                           help="起始日期 YYYY-MM-DD")
    searchx_p.add_argument("--end-date", dest="end_date", type=str, default=None,
                           help="结束日期 YYYY-MM-DD")
    searchx_p.add_argument("--cvc-model-id", dest="cvc_model_id", type=str, default=None,
                           help="CVC 模型 ID（传入时检索结果异步归集到语义检索库）")
    searchx_p.add_argument("--category", type=str, default=None, help="信源类别过滤")
    searchx_p.add_argument("--region", type=str, default=None, help="信源地区过滤")
    searchx_p.add_argument("--language", type=str, default=None, help="信源语言过滤")
    searchx_p.add_argument("--source-ids", dest="source_ids", type=str, default=None,
                           help="信源 ID 列表（逗号分隔），如 reuters,bloomberg")
    searchx_p.add_argument("--min-tscore", dest="min_tscore", type=float, default=0.0,
                           help="最低 tscore（0.0-1.0）")
    searchx_p.add_argument("--limit", type=int, default=50, help="返回条数上限，默认 50")
    searchx_p.add_argument("--fallback", dest="fallback", action="store_true", default=False,
                           help="无结果时启用 Google News 回退检索（[v1.8 FIX-S3] 默认关闭）")
    searchx_p.add_argument("--no-fallback", dest="fallback", action="store_false",
                           help="关闭 Google News 回退检索")
    searchx_p.add_argument("--min-content-words", dest="min_content_words", type=int, default=200,
                           help="最低正文字数过滤（0=不过滤，默认 200）")
    _add_auth_args(searchx_p)
    _add_output_args(searchx_p)

    # ---- semantic（语义检索）----
    semantic_p = subparsers.add_parser(
        "semantic", help="语义检索：基于 CVC 模型的两阶段混合检索（BM25 + 向量 ANN + RRF 融合）")
    semantic_p.add_argument("cvc_model_id", type=str,
                           help="CVC 模型 ID（格式 ^cvc_[a-z0-9]{8,32}$）")
    semantic_p.add_argument("q", type=str, help="查询文本（自然语言）")
    semantic_p.add_argument("--mode", type=str, default="hybrid",
                            choices=["hybrid", "semantic", "keyword"],
                            help="检索模式：hybrid（默认）/ semantic / keyword")
    semantic_p.add_argument("--top-k", dest="top_k", type=int, default=20,
                            help="返回条数上限，默认 20")
    semantic_p.add_argument("--time-range", dest="time_range", type=str, default=None,
                            help="预设时间范围：1d/7d/1m/3m")
    semantic_p.add_argument("--days", type=int, default=None, help="自定义时间窗口（天）")
    semantic_p.add_argument("--start-date", dest="start_date", type=str, default=None,
                            help="起始日期 YYYY-MM-DD")
    semantic_p.add_argument("--end-date", dest="end_date", type=str, default=None,
                            help="结束日期 YYYY-MM-DD")
    semantic_p.add_argument("--category", type=str, default=None, help="信源类别过滤")
    semantic_p.add_argument("--region", type=str, default=None, help="信源地区过滤")
    semantic_p.add_argument("--language", type=str, default=None, help="信源语言过滤（单个，如 en/zh）")
    semantic_p.add_argument("--languages", dest="languages", type=str, default=None,
                            help="信源语言过滤（逗号分隔多个，如 en,zh）")
    semantic_p.add_argument("--source-categories", dest="source_categories", type=str, default=None,
                            help="信源类别过滤（逗号分隔多个，如 wire,tech）")
    semantic_p.add_argument("--min-tscore", dest="min_tscore", type=float, default=0.0,
                            help="最低 tscore（0.0-1.0）")
    semantic_p.add_argument("--rerank", dest="rerank", action="store_true", default=True,
                            help="启用结果重排序（默认开启）")
    semantic_p.add_argument("--no-rerank", dest="rerank", action="store_false",
                            help="关闭结果重排序")
    _add_auth_args(semantic_p)
    _add_output_args(semantic_p)

    # ---- sources（信源检索）----
    sources_p = subparsers.add_parser("sources", help="信源检索：发现可信信源")
    sources_p.add_argument("--keyword", type=str, default=None, help="关键字模糊查询")
    sources_p.add_argument("--category", type=str, default=None, help="信源类别过滤")
    sources_p.add_argument("--region", type=str, default=None, help="信源地区过滤")
    sources_p.add_argument("--language", type=str, default=None, help="信源语言过滤")
    sources_p.add_argument("--min-tscore", dest="min_tscore", type=float, default=0.0,
                           help="最低 tscore（0.0-1.0）")
    sources_p.add_argument("--sample-size", dest="sample_size", type=int, default=3,
                           help="每个信源返回的 sample data 条数（0=不返回）")
    sources_p.add_argument("--limit", type=int, default=50, help="返回信源数上限，默认 50")
    sources_p.add_argument("--skip", type=int, default=0, help="分页偏移")
    sources_p.add_argument("--list", dest="list_sources", action="store_true",
                           help="列出所有信源（GET /v1/sources）")
    _add_auth_args(sources_p)
    _add_output_args(sources_p)

    # ---- stats ----
    stats_p = subparsers.add_parser("stats", help="情报集合统计")
    _add_auth_args(stats_p)
    _add_output_args(stats_p)

    # ---- locations ----
    locations_p = subparsers.add_parser("locations", help="过滤值枚举")
    _add_auth_args(locations_p)
    _add_output_args(locations_p)

    return parser


def _add_auth_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--api-key", dest="api_key", type=str, default=None,
                   help="API Key（默认读 CASEE_API_KEY 环境变量）")
    p.add_argument("--base-url", dest="base_url", type=str, default=None,
                   help="API 基址（默认读 CASEE_API_BASE_URL 环境变量）")
    p.add_argument("--timeout", type=float, default=None, help="请求超时秒数")


def _add_output_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("-o", "--output", dest="output", type=str, default=None,
                   help="输出到文件（默认 stdout）")
    p.add_argument("--indent", type=int, default=2, help="JSON 缩进，默认 2")
    p.add_argument("--no-indent", dest="indent", action="store_const", const=None,
                   help="不缩进（紧凑输出）")
    p.add_argument("--links", action="store_true", help="仅输出 links（每行一个 URL）")
    p.add_argument("--ids", action="store_true", help="仅输出 news_id 列表")
    p.add_argument("--titles", action="store_true", help="仅输出标题列表")


def main(argv: Optional[List[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help(sys.stderr)
        return 2

    try:
        if args.command == "stats":
            result = get_stats(api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "locations":
            result = get_locations(api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "sources":
            if getattr(args, "list_sources", False):
                result = list_sources(
                    api_key=args.api_key,
                    base_url=args.base_url,
                    category=args.category,
                    region=args.region,
                    language=args.language,
                    limit=args.limit if args.limit != 50 else 2000,
                )
                return _print_json(result, args)

            result = search_sources(
                keyword=args.keyword,
                category=args.category,
                region=args.region,
                language=args.language,
                min_tscore=args.min_tscore,
                sample_size=args.sample_size,
                limit=args.limit,
                skip=args.skip,
                api_key=args.api_key,
                base_url=args.base_url,
            )
            return _print_json(result, args)

        if args.command == "search":
            if not args.q:
                print("Error: search requires a query argument", file=sys.stderr)
                return 2
            params: Dict[str, Any] = {
                "engine": "intelligence",
                "q": args.q,
                "days": args.days,
                "time_range": args.time_range,
                "start_date": args.start_date,
                "end_date": args.end_date,
                "cvc_model_id": args.cvc_model_id,
                "category": args.category,
                "region": args.region,
                "language": args.language,
                "min_tscore": args.min_tscore,
                "limit": args.limit,
                "fallback": args.fallback,
                "min_content_words": args.min_content_words,
                "api_key": args.api_key,
                "api_base_url": args.base_url,
                "timeout": args.timeout,
            }
            params = {k: v for k, v in params.items() if v is not None}

            with IntelligenceSearch(params) as search:
                response = search.get_dict()
            return _format_output(response, args)

        if args.command == "searchx":
            if not any([args.q, args.must_keywords, args.should_keywords,
                        args.not_keywords, args.phrase_keywords, args.keywords]):
                print("Error: searchx requires at least one search parameter", file=sys.stderr)
                return 2

            result = search_advanced(
                q=args.q,
                must_keywords=args.must_keywords.split(",") if args.must_keywords else None,
                should_keywords=args.should_keywords.split(",") if args.should_keywords else None,
                not_keywords=args.not_keywords.split(",") if args.not_keywords else None,
                phrase_keywords=args.phrase_keywords.split(",") if args.phrase_keywords else None,
                keywords=args.keywords,
                days=args.days,
                time_range=args.time_range,
                start_date=args.start_date,
                end_date=args.end_date,
                cvc_model_id=args.cvc_model_id,
                category=args.category,
                region=args.region,
                language=args.language,
                source_ids=args.source_ids.split(",") if args.source_ids else None,
                min_tscore=args.min_tscore,
                limit=args.limit,
                fallback=args.fallback,
                min_content_words=args.min_content_words,
                api_key=args.api_key,
                base_url=args.base_url,
            )
            return _print_json(result, args)

        if args.command == "semantic":
            result = semantic_search_fn(
                cvc_model_id=args.cvc_model_id,
                q=args.q,
                mode=args.mode,
                top_k=args.top_k,
                time_range=args.time_range,
                days=args.days,
                start_date=args.start_date,
                end_date=args.end_date,
                category=args.category,
                region=args.region,
                language=args.language,
                languages=args.languages.split(",") if args.languages else None,
                source_categories=args.source_categories.split(",") if args.source_categories else None,
                min_tscore=args.min_tscore,
                rerank=args.rerank,
                api_key=args.api_key,
                base_url=args.base_url,
            )
            return _format_output(result, args)

        return 0

    except CaseeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


def _format_output(response: Dict[str, Any], args: argparse.Namespace) -> int:
    """格式化输出（支持 --links / --ids / --titles 等特殊格式）。"""
    if args.links:
        items = response.get("organic_results", [])
        for item in items:
            link = item.get("link") or item.get("url") or ""
            if link:
                print(link)
        return 0

    if args.ids:
        items = response.get("organic_results", [])
        for item in items:
            print(item.get("news_id", ""))
        return 0

    if args.titles:
        items = response.get("organic_results", [])
        for item in items:
            print(item.get("title", ""))
        return 0

    return _print_json(response, args)


def _print_json(data: Any, args: argparse.Namespace) -> int:
    """输出 JSON 到 stdout 或文件。"""
    text = json.dumps(data, indent=args.indent, ensure_ascii=False, default=str)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"Written to {args.output}", file=sys.stderr)
    else:
        print(text)

    return 0


if __name__ == "__main__":
    sys.exit(main())
