"""casee SDK — CVC 模型与关联情报管理接口（v1.7 新增）。

对应 ``/v1/cvc/*`` 管理端点，支持：

- 模型生命周期：列表 / 按 id 注册 / 删除（级联清除关联关系）/ 多选批量删除
- 关联情报：列出已关联情报 / 把指定情报文档关联进模型 / 解除指定关联
  （解除关联**不删除情报本身**，仅删除 cvc model id 与情报之间的关系）

函数式便捷接口：
    from casee import list_cvc_models, register_cvc_model, delete_cvc_model
    from casee import batch_delete_cvc_models
    from casee import list_associated_docs, link_docs, unlink_docs

    models = list_cvc_models(api_key="sk_xxx")
    register_cvc_model("cvc_ai_20260101", api_key="sk_xxx")

    # 检索到情报后，把指定的 mongo_id 关联进模型（跳过质量门槛，人工指定即权威）
    link_docs("cvc_ai_20260101", ["66b1f0a1..."], q="人工补关联", api_key="sk_xxx")
    docs = list_associated_docs("cvc_ai_20260101", api_key="sk_xxx")

    # 解除指定情报关联（不删除 source_feed 中的情报本身）
    unlink_docs("cvc_ai_20260101", ["66b1f0a1..."], api_key="sk_xxx")
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from .client import HTTPClient
from .constants import (
    PATH_CVC_MODEL,
    PATH_CVC_MODEL_CACHE_PURGE,
    PATH_CVC_MODEL_CLEANUP_STATUS,
    PATH_CVC_MODEL_DOCS,
    PATH_CVC_MODEL_REINDEX,
    PATH_CVC_MODEL_STATS,
    PATH_CVC_MODELS,
    PATH_CVC_MODELS_BATCH_DELETE,
)
from .exceptions import ValidationError

_CVC_MODEL_ID_RE = re.compile(r"^cvc_[a-z0-9]{8,32}$")
_MAX_BATCH_IDS = 1000


def _check_cvc_model_id(cvc_model_id: str) -> str:
    """校验 cvc model id 格式（与服务端一致：``^cvc_[a-z0-9]{8,32}$``）。"""
    if not cvc_model_id or not _CVC_MODEL_ID_RE.match(cvc_model_id):
        raise ValidationError(
            f"cvc_model_id must match pattern ^cvc_[a-z0-9]{{8,32}}$, got: {cvc_model_id!r}"
        )
    return cvc_model_id


def _check_mongo_ids(mongo_ids: List[str]) -> List[str]:
    """清洗并校验 mongo_ids 列表（非空、去重、≤1000）。"""
    if not isinstance(mongo_ids, (list, tuple)) or not mongo_ids:
        raise ValidationError("mongo_ids must be a non-empty list of document ids.")
    cleaned = [str(x).strip() for x in mongo_ids if str(x).strip()]
    cleaned = list(dict.fromkeys(cleaned))
    if not cleaned:
        raise ValidationError("mongo_ids must be a non-empty list of document ids.")
    if len(cleaned) > _MAX_BATCH_IDS:
        raise ValidationError(f"mongo_ids cannot exceed {_MAX_BATCH_IDS} items per call.")
    return cleaned


def list_cvc_models(
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """列出全部 CVC 模型及归集统计摘要（GET /v1/cvc/models）。

    供语义检索 / 情报检索选择模型，以及多选删除时获取候选集。
    返回 ``{"count": int, "models": [{cvc_model_id, doc_count, query_count,
    first_collected_at, last_collected_at, registered, registered_at, source}]}``。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_CVC_MODELS)


def register_cvc_model(
    cvc_model_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """按指定 cvc model id 注册模型（幂等，POST /v1/cvc/models）。

    注册后的模型即使尚未归集情报，也会出现在 ``list_cvc_models()`` 列表中，
    便于后续关联情报、批量删除等管理操作。
    """
    _check_cvc_model_id(cvc_model_id)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_CVC_MODELS, json_data={"cvc_model_id": cvc_model_id})


def delete_cvc_model(
    cvc_model_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """删除单个 CVC 模型（DELETE /v1/cvc/{id}，不可恢复）。

    删除时级联清除该模型的情报关联（Redis docids / OpenSearch / Qdrant /
    cvc_search_logs / 租户绑定 / 注册库）；source_feed 原始情报不清除。
    有归集语料时服务端异步执行（202，返回 task_id，可轮询
    ``GET /v1/cvc/{id}/cleanup/status``）；仅注册/空模型同步返回 status="deleted"。
    """
    _check_cvc_model_id(cvc_model_id)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.delete(PATH_CVC_MODEL.format(cvc_model_id=cvc_model_id))


def batch_delete_cvc_models(
    cvc_model_ids: List[str],
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """多选批量删除 CVC 模型（POST /v1/cvc/models/batch-delete，≤100/批）。

    每个模型删除时一并清除其情报相关关系；有归集语料者受理异步任务
    （响应 202 + task_id），仅注册/空模型同步删除。返回逐项结果：
    ``{"count": int, "queued": bool, "results": [{cvc_model_id, ok, status, ...}]}``。
    """
    if not isinstance(cvc_model_ids, (list, tuple)) or not cvc_model_ids:
        raise ValidationError("cvc_model_ids must be a non-empty list.")
    if len(cvc_model_ids) > 100:
        raise ValidationError("cvc_model_ids cannot exceed 100 items per call.")
    clean = []
    for raw in cvc_model_ids:
        value = _check_cvc_model_id(str(raw).strip())
        if value not in clean:
            clean.append(value)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_CVC_MODELS_BATCH_DELETE,
                           json_data={"cvc_model_ids": clean})


def list_associated_docs(
    cvc_model_id: str,
    *,
    skip: int = 0,
    limit: int = 50,
    keyword: Optional[str] = None,
    min_tscore: Optional[float] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """分页列出某 CVC 模型已关联情报（GET /v1/cvc/{id}/docs）。

    返回条目与情报检索结果同构（news_id/title/link/published_at/source_*/tscore），
    可直接复用检索结果表格渲染。参数：

    - ``skip``: 跳过条数（默认 0）
    - ``limit``: 每页条数（默认 50，上限 200）
    - ``keyword``: 标题/摘要/来源关键词过滤
    - ``min_tscore``: 最低 tscore 过滤
    """
    _check_cvc_model_id(cvc_model_id)
    params: Dict[str, Any] = {"skip": int(skip), "limit": int(limit)}
    if keyword:
        params["keyword"] = keyword
    if min_tscore is not None:
        params["min_tscore"] = float(min_tscore)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_CVC_MODEL_DOCS.format(cvc_model_id=cvc_model_id),
                          params=params)


def link_docs(
    cvc_model_id: str,
    mongo_ids: List[str],
    *,
    q: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """把**指定情报文档**关联进某 CVC 模型（POST /v1/cvc/{id}/docs，≤1000/批）。

    跳过归集质量门槛（人工指定即权威），写入路径与自动归集一致：Redis docids →
    OpenSearch → Qdrant 向量化 → cvc_search_logs（可 reindex 回放）。不会删除或
    改动 source_feed 中的原始情报。

    - ``mongo_ids``: source_feed 文档 _id 列表（先在情报检索中取得）
    - ``q``: 关联说明/来源上下文（可选，写入审计日志）
    """
    _check_cvc_model_id(cvc_model_id)
    clean = _check_mongo_ids(mongo_ids)
    payload: Dict[str, Any] = {"mongo_ids": clean}
    if q:
        payload["q"] = str(q)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_CVC_MODEL_DOCS.format(cvc_model_id=cvc_model_id),
                           json_data=payload)


def unlink_docs(
    cvc_model_id: str,
    mongo_ids: List[str],
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """解除指定情报关联（DELETE /v1/cvc/{id}/docs，≤1000/批）。

    仅删除 cvc model id 与情报之间的关系（Redis docids / OS / Qdrant /
    审计日志中的关联），**不删除情报本身**（source_feed 原始情报保留）。

    - ``mongo_ids``: 需要解除关联的情报 _id 列表
    """
    _check_cvc_model_id(cvc_model_id)
    clean = _check_mongo_ids(mongo_ids)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.delete(PATH_CVC_MODEL_DOCS.format(cvc_model_id=cvc_model_id),
                             json_data={"mongo_ids": clean})


# ---- CVC 运维接口（v1.9 新增）----


def cvc_stats(
    cvc_model_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """CVC 归集统计（GET /v1/cvc/{id}/stats）。

    返回 doc 数 / 向量数 / 来源与语言分布 / 时间跨度等归集统计摘要，
    供运维评估模型规模与质量。
    """
    _check_cvc_model_id(cvc_model_id)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_CVC_MODEL_STATS.format(cvc_model_id=cvc_model_id))


def cvc_cache_purge(
    cvc_model_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """CVC 缓存重置：三库归集数据清除（POST /v1/cvc/{id}/cache/purge）。

    按 CVC 清除 OpenSearch / Qdrant / Redis 三库归集数据；**CVC 模型保留**
    （cvc_search_logs / 租户绑定不动），MongoDB source_feed 原始情报绝不清除。

    - 若该模型有归集语料 → 受理异步清除（响应 202，返回 task_id），
      可轮询 ``cvc_cleanup_status()`` 获取进度与三库对账；
    - 已完成/空模型 → 幂等返回 status="completed"。

    如需恢复，调用 :func:`cvc_reindex` 重放 cvc_search_logs 重建归集库。
    """
    _check_cvc_model_id(cvc_model_id)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_CVC_MODEL_CACHE_PURGE.format(cvc_model_id=cvc_model_id))


def cvc_cleanup_status(
    cvc_model_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """CVC 清除进度与三库对账（GET /v1/cvc/{id}/cleanup/status）。

    查询该模型最近一次清除任务（cache/purge 缓存重置 或 模型删除）的进度，
    并实时统计 OpenSearch / Qdrant / Redis docids 三库残留计数。
    """
    _check_cvc_model_id(cvc_model_id)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_CVC_MODEL_CLEANUP_STATUS.format(cvc_model_id=cvc_model_id))


def cvc_reindex(
    cvc_model_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """CVC 重放归集审计重建归集库（POST /v1/cvc/{id}/reindex）。

    读取该 CVC 全部归集审计记录（cvc_search_logs），按 doc_ids 批量回源 MongoDB
    后重新归集到 OpenSearch + Qdrant。

    - 通常用于 ``cvc_cache_purge``（缓存重置）之后恢复归集库；
    - 模型删除后 logs 已清，重建等同从零归集。
    """
    _check_cvc_model_id(cvc_model_id)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_CVC_MODEL_REINDEX.format(cvc_model_id=cvc_model_id))
