"""批量检索助手（SDK 优化 S3 / E1）。

将"实体组 × 渠道 × 批次"的多关键词串行往返收敛为一次编排（本地并发执行各检索组，
未来可无缝切换到服务端 ``POST /v1/search/batch``，见 design 文档 §5.2-3 / §5.1-1）。

特点：
- ``search_many(groups, concurrency, total_timeout, ...)`` 本地并发、整体超时预算；
- 每组结果携带 ``stats``（search_information + 组级清洗剔除计数）；
- ``sanitize=True``（默认）在发往服务端前做词表卫生化（``clean_keywords``），
  清洗剔除词计入该组 ``hygiene_dropped``（与 FIX-S2 观测语义一致）；
- 单组失败不拖垮其它组（组错误字段隔离）。
"""
from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

from .exceptions import CaseeError
from .search import AdvancedSearch, QuickSearch
from .search_terms import clean_keywords

# 走 AdvancedSearch 的分组字段（出现其一即按 /v1/searchx 高级检索，否则按 /v1/search 快速检索）
_ADV_LIST_FIELDS = (
    "must_keywords", "should_keywords", "not_keywords", "phrase_keywords",
    "source_ids", "start_date", "end_date", "time_range", "cvc_model_id",
)


def _group_kwargs(g: Dict[str, Any], *, cred: Dict[str, Any],
                  dropped: Optional[List[str]]) -> Dict[str, Any]:
    """由组 dict 构造检索参数。"""
    kw: Dict[str, Any] = {
        "days": g.get("days", 30),
        "category": g.get("category"),
        "region": g.get("region"),
        "language": g.get("language"),
        "min_tscore": g.get("min_tscore", 0.0),
        "limit": g.get("limit", 20),
        "fallback": g.get("fallback", False),
        "min_content_words": g.get("min_content_words", 0),
    }
    kw.update(cred)
    if dropped is None:
        dropped = []

    advanced = any(k in g for k in _ADV_LIST_FIELDS)
    if advanced:
        lists = {}
        for f in ("must_keywords", "should_keywords", "not_keywords", "phrase_keywords"):
            if g.get(f):
                clean, _dr = clean_keywords(g[f])
                lists[f] = clean
                dropped.extend(_dr)
        kw.update({
            "q": g.get("q"),
            "keywords": g.get("keywords"),
            **lists,
            "source_ids": g.get("source_ids"),
            "start_date": g.get("start_date"),
            "end_date": g.get("end_date"),
            "time_range": g.get("time_range"),
            "cvc_model_id": g.get("cvc_model_id"),
        })
    else:
        if g.get("q"):
            kw["q"] = g["q"]
        elif g.get("keywords"):
            kw["q"] = g["keywords"]
    return kw


def _run_group(gid: str, kw: Dict[str, Any], dropped: List[str]) -> Dict[str, Any]:
    advanced = kw.get("cvc_model_id") is not None or any(
        kw.get(k) for k in ("must_keywords", "should_keywords", "not_keywords",
                            "phrase_keywords", "source_ids", "start_date",
                            "end_date", "time_range"))
    t0 = time.time()
    try:
        obj = AdvancedSearch(**kw) if advanced else QuickSearch(**kw)
        resp = obj.get_dict()
        info = resp.get("search_information") or {}
        items = resp.get("organic_results") or []
        return {
            "id": gid,
            "count": len(items),
            "items": items,
            "stats": {
                "returned": len(items),
                "total_results": info.get("total_results"),
                "raw_hits": info.get("raw_hits"),
                "duplicates_removed": info.get("duplicates_removed"),
                "truncated": info.get("truncated"),
                "hygiene_dropped": dropped or info.get("hygiene_dropped"),
            },
            "elapsed_ms": int((time.time() - t0) * 1000),
        }
    except CaseeError as exc:
        return {"id": gid, "error": f"{type(exc).__name__}: {exc}",
                "elapsed_ms": int((time.time() - t0) * 1000)}


def search_many(
    groups: List[Dict[str, Any]],
    *,
    concurrency: int = 4,
    total_timeout: float = 45.0,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
    sanitize: bool = True,
) -> Dict[str, Any]:
    """并发批量检索多组情报，返回每组结果。

    Args:
        groups: 组列表。每组含 ``id`` + 检索参数；检索参数分两种形态：
            - 高级组：出现 must_keywords / should_keywords / not_keywords /
              phrase_keywords / source_ids / time_range 等任一 → 走 ``AdvancedSearch``；
            - 快速组：仅 ``q``/``keywords``（+ days/limit 等）→ 走 ``QuickSearch``。
        concurrency: 本地并发上限。
        total_timeout: 整批墙钟预算（秒）；超时未完成组以 ``timed_out`` 错误返回。
        sanitize: 上送前用 ``clean_keywords`` 清洗 must/should/not/phrase 词表。

    Returns:
        ``{"results": [{id, count?, items?, stats?, error?}], "meta": {groups,
        succeeded, failed, elapsed_ms, concurrency, total_timeout, sanitize}}``；
        单组失败隔离，不影响其它组。
    """
    started = time.time()
    deadline = started + max(total_timeout, 1.0)
    cred = {"api_key": api_key, "base_url": base_url, "timeout": timeout}

    tasks: List[Dict[str, Any]] = []
    for idx, g in enumerate(groups):
        gid = str(g.get("id", idx))
        dropped: List[str] = []
        kw = _group_kwargs(g, cred=cred, dropped=dropped)
        tasks.append((gid, kw, dropped))

    results: List[Dict[str, Any]] = []
    done_ids: set = set()
    if tasks:
        with ThreadPoolExecutor(max_workers=max(1, concurrency)) as pool:
            futures = {pool.submit(_run_group, gid, kw, dr): (gid, kw, dr)
                       for gid, kw, dr in tasks}
            try:
                for fut in as_completed(futures, timeout=total_timeout):
                    gid, kw, dr = futures[fut]
                    done_ids.add(gid)
                    try:
                        results.append(fut.result())
                    except Exception as exc:  # noqa: BLE001
                        results.append({"id": gid, "error": f"{type(exc).__name__}: {exc}"})
            except TimeoutError:
                # 未完成组统一标记 timed_out
                for gid, _kw, _dr in tasks:
                    if gid not in done_ids:
                        results.append({"id": gid, "error": "timed_out (total budget exceeded)"})

    ok = sum(1 for r in results if "error" not in r)
    return {
        "results": results,
        "meta": {
            "groups": len(groups),
            "succeeded": ok,
            "failed": len(results) - ok,
            "elapsed_ms": int((time.time() - started) * 1000),
            "concurrency": max(1, concurrency),
            "total_timeout": total_timeout,
            "sanitize": bool(sanitize),
        },
    }
