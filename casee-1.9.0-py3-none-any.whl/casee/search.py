"""casee SDK 主搜索接口。

函数式便捷接口：
    from casee import search

    result = search("AI,Nvidia", api_key="sk_xxx", days=30)

    from casee import search_advanced, search_sources

    # 高级检索
    result = search_advanced("+EV +(battery|charging) -China", source_ids=["reuters"],
                             api_key="sk_xxx")

    # 信源检索
    result = search_sources(category="wire", min_tscore=0.7, api_key="sk_xxx")

类风格：
    from casee import QuickSearch, AdvancedSearch, SourceSearch

    with QuickSearch(q="AI,Nvidia", api_key="sk_xxx") as s:
        items = s.get_organic_results()
"""
from __future__ import annotations

import json
import warnings
from typing import Any, Dict, List, Optional

from .client import HTTPClient
from .constants import (
    DEFAULT_DAYS,
    DEFAULT_ENGINE,
    DEFAULT_FALLBACK,
    DEFAULT_LIMIT,
    DEFAULT_MIN_TSCORE,
    ENGINE_ENTITIES,
    ENGINE_FEED,
    ENGINE_INTELLIGENCE,
    ENGINE_LATEST,
    ENGINE_SOURCE,
    PATH_ADVANCED_SEARCH,
    PATH_LOCATIONS,
    PATH_SEARCH,
    PATH_SEARCHX,
    PATH_SEARCH_BATCH,
    PATH_SEMANTIC_SEARCH,
    PATH_SOURCES,
    PATH_SOURCES_SEARCH,
    PATH_STATS,
    SUPPORTED_ENGINES,
)
from .exceptions import ValidationError
from .models import IntelligenceItem


class IntelligenceSearch:
    """SerpAPI 风格的统一情报搜索客户端。

    Args:
        params: 搜索参数 dict，支持以下 key（全部可选，``api_key`` 也可来自环境变量）：
            - ``api_key`` (str): API Key，默认读 ``CASEE_API_KEY`` 环境变量
            - ``api_base_url`` (str): API 基址，默认读 ``CASEE_API_BASE_URL``，fallback ``http://121.43.113.132:8000``
            - ``timeout`` (float): 请求超时（秒），默认 30
            - ``engine`` (str): 搜索引擎，默认 ``intelligence``
            - ``q`` (str): 关键词或逗号分隔多关键词
            - ``source_id`` (str): 信源 ID（engine=feed/source 时必填）
            - ``days`` (int): 时间窗口（天），默认 30
            - ``category`` (str): 信源类别过滤
            - ``region`` (str): 信源地区过滤
            - ``language`` (str): 信源语言过滤
            - ``min_tscore`` (float): 最低 tscore（0.0-1.0）
            - ``limit`` (int): 返回条数上限，默认 50
    """

    def __init__(self, params: Optional[Dict[str, Any]] = None) -> None:
        params = dict(params or {})
        self._raw_params = params

        # 提取客户端配置
        api_key = params.pop("api_key", None)
        base_url = params.pop("api_base_url", None)
        timeout = params.pop("timeout", None)

        # 引擎校验
        engine = params.get("engine", DEFAULT_ENGINE)
        if engine not in SUPPORTED_ENGINES:
            raise ValidationError(
                f"Unsupported engine: {engine!r}. Supported: {', '.join(SUPPORTED_ENGINES)}"
            )

        # 引擎必填字段校验
        self._validate_engine_params(params)

        # 保留搜索参数（不含客户端配置），补全 engine 默认值
        params.setdefault("engine", engine)
        self._search_params: Dict[str, Any] = params
        self._client = HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout)
        self._last_response: Optional[Dict[str, Any]] = None

    # ---- 参数校验 ----

    @staticmethod
    def _validate_engine_params(params: Dict[str, Any]) -> None:
        """根据 engine 校验必填字段。"""
        engine = params.get("engine", DEFAULT_ENGINE)

        if engine in (ENGINE_INTELLIGENCE, ENGINE_ENTITIES):
            if not params.get("q"):
                raise ValidationError(
                    f"engine={engine!r} requires 'q' parameter "
                    f"(comma-separated keywords or entity names)."
                )
        elif engine in (ENGINE_FEED, ENGINE_SOURCE):
            if not params.get("source_id"):
                raise ValidationError(
                    f"engine={engine!r} requires 'source_id' parameter."
                )

    # ---- 同步接口 ----

    def get_dict(self) -> Dict[str, Any]:
        """发起同步搜索请求，返回完整响应 dict（SerpAPI 风格四段式）。

        返回结构：
        - ``search_metadata``: 请求 ID / 状态 / 时间戳 / 耗时
        - ``search_parameters``: echo back 请求参数
        - ``search_information``: 命中数 / 耗时 / 查询文本
        - ``organic_results``: 情报条目数组
        """
        response = self._client.get(PATH_SEARCH, params=self._build_query_params())
        self._last_response = response
        return response

    def get_organic_results(self) -> List[IntelligenceItem]:
        """快捷获取 ``organic_results`` 数组。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return self._last_response.get("organic_results", [])

    def get_search_metadata(self) -> Dict[str, Any]:
        """快捷获取 ``search_metadata`` 块。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return self._last_response.get("search_metadata", {})

    def get_search_information(self) -> Dict[str, Any]:
        """快捷获取 ``search_information`` 块。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return self._last_response.get("search_information", {})

    def get_json(self, indent: Optional[int] = 2) -> str:
        """JSON 字符串形式返回（参考 serpapi.get_json()）。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return json.dumps(self._last_response, indent=indent, ensure_ascii=False)

    def get_links(self) -> List[str]:
        """提取所有 organic_results 中的 link/url 字段（去重）。"""
        items = self.get_organic_results()
        seen: set = set()
        links: List[str] = []
        for item in items:
            url = item.get("link") or item.get("url") or ""
            if url and url not in seen:
                seen.add(url)
                links.append(url)
        return links

    # ---- 异步接口 ----

    async def async_get_dict(self) -> Dict[str, Any]:
        """异步版本 :meth:`get_dict`。"""
        response = await self._client.async_get(PATH_SEARCH, params=self._build_query_params())
        self._last_response = response
        return response

    async def async_get_organic_results(self) -> List[IntelligenceItem]:
        """异步版本 :meth:`get_organic_results`。"""
        await self.async_get_dict()
        assert self._last_response is not None
        return self._last_response.get("organic_results", [])

    # ---- 上下文管理 ----

    def __enter__(self) -> "IntelligenceSearch":
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def close(self) -> None:
        """释放底层 HTTP 连接池。"""
        self._client.close()

    # ---- 工具 ----

    def _build_query_params(self) -> Dict[str, Any]:
        """构造 GET /v1/search 的 query 参数（去除空值 + 应用默认值）。"""
        params = self._search_params.copy()
        # 应用默认值
        params.setdefault("engine", DEFAULT_ENGINE)
        params.setdefault("days", DEFAULT_DAYS)
        params.setdefault("limit", DEFAULT_LIMIT)
        params.setdefault("min_tscore", DEFAULT_MIN_TSCORE)
        # 剔除 None 值（避免 URL 拼出 `q=None`）
        return {k: v for k, v in params.items() if v is not None}

    @property
    def params(self) -> Dict[str, Any]:
        """只读视图：当前搜索参数。"""
        return dict(self._search_params)

    @property
    def last_response(self) -> Optional[Dict[str, Any]]:
        """上次请求的完整响应（未发起请求时为 None）。"""
        return self._last_response


# ---- 辅助便捷类（不同 engine 的语义化构造器）----


class IntelligenceKeywordSearch(IntelligenceSearch):
    """``engine=intelligence`` 的语义化别名。

    Example:
        >>> search = IntelligenceKeywordSearch(q="AI,Nvidia", api_key="sk_xxx")
        >>> items = search.get_organic_results()
    """

    def __init__(self, q: str, *, api_key: Optional[str] = None, **kwargs: Any) -> None:
        params: Dict[str, Any] = {"engine": ENGINE_INTELLIGENCE, "q": q, **kwargs}
        if api_key is not None:
            params["api_key"] = api_key
        super().__init__(params)


class EntitySearch(IntelligenceSearch):
    """``engine=entities`` 的语义化别名。

    Example:
        >>> search = EntitySearch(q="Apple,Google", api_key="sk_xxx")
        >>> items = search.get_organic_results()
    """

    def __init__(self, q: str, *, api_key: Optional[str] = None, **kwargs: Any) -> None:
        params: Dict[str, Any] = {"engine": ENGINE_ENTITIES, "q": q, **kwargs}
        if api_key is not None:
            params["api_key"] = api_key
        super().__init__(params)


class LatestIntelligence(IntelligenceSearch):
    """``engine=latest`` 的语义化别名。

    Example:
        >>> search = LatestIntelligence(days=3, min_tscore=0.5, api_key="sk_xxx")
        >>> items = search.get_organic_results()
    """

    def __init__(self, *, api_key: Optional[str] = None, **kwargs: Any) -> None:
        params: Dict[str, Any] = {"engine": ENGINE_LATEST, **kwargs}
        if api_key is not None:
            params["api_key"] = api_key
        super().__init__(params)


class SourceFeedSearch(IntelligenceSearch):
    """``engine=feed`` 的语义化别名。

    Example:
        >>> search = SourceFeedSearch(source_id="reuters", days=7, api_key="sk_xxx")
        >>> items = search.get_organic_results()
    """

    def __init__(self, source_id: str, *, api_key: Optional[str] = None, **kwargs: Any) -> None:
        params: Dict[str, Any] = {"engine": ENGINE_FEED, "source_id": source_id, **kwargs}
        if api_key is not None:
            params["api_key"] = api_key
        super().__init__(params)


class LatestBySource(IntelligenceSearch):
    """``engine=source`` 的语义化别名。

    Example:
        >>> search = LatestBySource(source_id="reuters", api_key="sk_xxx")
        >>> items = search.get_organic_results()
    """

    def __init__(self, source_id: str, *, api_key: Optional[str] = None, **kwargs: Any) -> None:
        params: Dict[str, Any] = {"engine": ENGINE_SOURCE, "source_id": source_id, **kwargs}
        if api_key is not None:
            params["api_key"] = api_key
        super().__init__(params)


# ---- 函数式便捷接口 ----


def search(
    q: Optional[str] = None,
    *,
    engine: str = DEFAULT_ENGINE,
    api_key: Optional[str] = None,
    days: int = DEFAULT_DAYS,
    time_range: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    cvc_model_id: Optional[str] = None,
    category: Optional[str] = None,
    region: Optional[str] = None,
    language: Optional[str] = None,
    min_tscore: float = DEFAULT_MIN_TSCORE,
    limit: int = DEFAULT_LIMIT,
    source_id: Optional[str] = None,
    fallback: bool = DEFAULT_FALLBACK,  # [v1.8 FIX-S3] 默认关闭 Google News 外部补源（确需时显式 True）
    min_content_words: int = 200,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """函数式便捷搜索接口（一次性请求，自动释放连接池）。

    Example:
        >>> from casee_intelligence import search
        >>> result = search("AI,Nvidia", api_key="sk_xxx", days=30)
        >>> print(len(result["organic_results"]))
        42

    Args:
        q: 关键词或逗号分隔多关键词（engine=intelligence/entities 必填）
        engine: 搜索引擎，默认 ``intelligence``
        api_key: API Key（默认读 ``CASEE_API_KEY`` 环境变量）
        days: 时间窗口（天），默认 30
        category / region / language: 多维过滤
        min_tscore: 最低 tscore（0.0-1.0）
        limit: 返回条数上限
        source_id: 信源 ID（engine=feed/source 必填）
        base_url: API 基址（默认读环境变量）

    Returns:
        完整响应 dict（含 search_metadata / search_parameters /
        search_information / organic_results）
    """
    params: Dict[str, Any] = {
        "engine": engine,
        "days": days,
        "min_tscore": min_tscore,
        "limit": limit,
        "fallback": fallback,
        "min_content_words": min_content_words,
    }
    if q is not None:
        params["q"] = q
    if time_range is not None:
        params["time_range"] = time_range
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if cvc_model_id is not None:
        params["cvc_model_id"] = cvc_model_id
    if source_id is not None:
        params["source_id"] = source_id
    if category is not None:
        params["category"] = category
    if region is not None:
        params["region"] = region
    if language is not None:
        params["language"] = language
    if api_key is not None:
        params["api_key"] = api_key
    if base_url is not None:
        params["api_base_url"] = base_url

    with IntelligenceSearch(params) as s:
        return s.get_dict()


def get_organic_results(
    q: Optional[str] = None,
    *,
    engine: str = DEFAULT_ENGINE,
    api_key: Optional[str] = None,
    **kwargs: Any,
) -> List[IntelligenceItem]:
    """函数式便捷接口：直接拿到 organic_results 数组。"""
    result = search(q, engine=engine, api_key=api_key, **kwargs)
    return result.get("organic_results", [])


# ---- 辅助查询接口 ----


def list_sources(
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    category: Optional[str] = None,
    region: Optional[str] = None,
    language: Optional[str] = None,
    limit: int = 500,
) -> Dict[str, Any]:
    """列出所有信源（GET /v1/sources）。"""
    params: Dict[str, Any] = {"limit": limit}
    if category:
        params["category"] = category
    if region:
        params["region"] = region
    if language:
        params["language"] = language

    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_SOURCES, params=params)


def get_stats(
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """获取情报集合统计（GET /v1/stats）。"""
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_STATS)


def get_locations(
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """枚举可用的过滤值（GET /v1/locations）。

    返回所有出现过的 source_category / source_region / source_language 值。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_LOCATIONS)


# ---- 高级检索接口（v1.2 新增，支持 AND/OR/NOT/精确短语）----

# ---- 快速检索接口（v1.4 新增，无 engine 参数）----


class QuickSearch:
    """快速检索客户端，简单关键词 + 时间窗口，开箱即用。

    通过 ``GET /v1/search`` 端点，无需 engine 参数，适合快速验证和简单场景。

    Args:
        q: 查询关键词（逗号分隔，OR 逻辑）
        days: 时间窗口（天），默认 30
        category: 信源类别过滤
        region: 信源地区过滤
        language: 信源语言过滤
        min_tscore: 最低可信度（0.0-1.0）
        limit: 返回条数上限，默认 50
        api_key: API Key
        base_url: API 基址
        timeout: 请求超时（秒）

    Example:
        >>> from casee import QuickSearch
        >>> with QuickSearch(q="AI,Nvidia", api_key="sk_xxx") as s:
        ...     items = s.get_organic_results()
    """

    def __init__(
        self,
        q: Optional[str] = None,
        *,
        days: int = DEFAULT_DAYS,
        time_range: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        cvc_model_id: Optional[str] = None,
        category: Optional[str] = None,
        region: Optional[str] = None,
        language: Optional[str] = None,
        min_tscore: float = DEFAULT_MIN_TSCORE,
        limit: int = DEFAULT_LIMIT,
        fallback: bool = DEFAULT_FALLBACK,  # [v1.8 FIX-S3] 默认关闭 Google News 外部补源（确需时显式 True）
        min_content_words: int = 200,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        client: Optional[Any] = None,  # [v1.8.1] 注入复用 httpx.Client（共享连接池；不负责关闭）
    ) -> None:
        self._search_params: Dict[str, Any] = {
            "days": days,
            "limit": limit,
            "min_tscore": min_tscore,
            "fallback": fallback,
            "min_content_words": min_content_words,
        }
        if q:
            self._search_params["q"] = q
        if time_range:
            self._search_params["time_range"] = time_range
        if start_date:
            self._search_params["start_date"] = start_date
        if end_date:
            self._search_params["end_date"] = end_date
        if cvc_model_id:
            self._search_params["cvc_model_id"] = cvc_model_id
        if category:
            self._search_params["category"] = category
        if region:
            self._search_params["region"] = region
        if language:
            self._search_params["language"] = language

        self._client = HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout, client=client)
        self._last_response: Optional[Dict[str, Any]] = None

    def get_dict(self) -> Dict[str, Any]:
        """发起快速检索请求，返回完整响应 dict。"""
        response = self._client.get(PATH_SEARCH, params=self._search_params)
        self._last_response = response
        return response

    def get_organic_results(self) -> List[IntelligenceItem]:
        """快捷获取 ``organic_results`` 数组。"""
        if self._last_response is None:
            self.get_dict()
        return [
            IntelligenceItem(**item) if isinstance(item, dict) else item
            for item in self._last_response.get("organic_results", [])
        ]

    def get_search_metadata(self) -> Dict[str, Any]:
        """获取 ``search_metadata``。"""
        if self._last_response is None:
            self.get_dict()
        return self._last_response.get("search_metadata", {})

    async def async_get_dict(self) -> Dict[str, Any]:
        """异步版本 :meth:`get_dict`。"""
        response = await self._client.async_get(PATH_SEARCH, params=self._search_params)
        self._last_response = response
        return response

    async def async_get_organic_results(self) -> List[IntelligenceItem]:
        """异步获取 organic_results。"""
        await self.async_get_dict()
        return self.get_organic_results()

    def __enter__(self) -> "QuickSearch":
        return self

    def __exit__(self, *_: Any) -> None:
        self._client.close()


# ---- 高级检索（v1.2 新增，v1.4 端点改为 /v1/searchx）----


class AdvancedSearch:
    """高级情报检索客户端，支持 AND/OR/NOT/精确短语组合查询。

    通过 ``GET /v1/searchx`` 端点，支持三种查询模式（优先级从高到低）：

    1. **查询语法模式**（``q`` 参数）：类 Google 语法，``+``AND / 空格OR / ``-``NOT / ``""``精确短语 / ``|``同义词组 / ``()``分组
    2. **高级参数模式**（``must_keywords`` / ``should_keywords`` / ``not_keywords`` / ``phrase_keywords``）
    3. **兼容模式**（``keywords`` 参数，逗号分隔 OR 逻辑，等价旧版 ``/v1/search``）

    过滤维度（v1.3 新增 ``source_ids`` / ``start_date`` / ``end_date``）：
    - ``days`` / ``start_date`` + ``end_date``：情报发布时间窗口
    - ``min_tscore``：情报可信度阈值（0.0-1.0）
    - ``source_ids``：信源 ID 列表（与 :func:`search_sources` 联动的两段式查询）
    - ``category`` / ``region`` / ``language``：信源维度过滤

    Example:
        >>> from casee import AdvancedSearch
        >>> # 方式1：查询语法
        >>> s = AdvancedSearch(q="+AI +(Nvidia OR Apple) -research", api_key="sk_xxx")
        >>> items = s.get_organic_results()
        >>> # 方式2：高级参数
        >>> s = AdvancedSearch(
        ...     must_keywords=["AI", "chip"],
        ...     should_keywords=["Nvidia", "Apple"],
        ...     not_keywords=["research"],
        ...     phrase_keywords=["AI chip"],
        ...     api_key="sk_xxx",
        ... )
        >>> items = s.get_organic_results()
        >>> # 方式3：两段式查询（先 search_sources 拿可信信源，再限定信源检索）
        >>> s = AdvancedSearch(
        ...     q="+(EV OR battery) +Nvidia",
        ...     source_ids=["reuters", "bloomberg"],
        ...     min_tscore=0.6,
        ...     days=30,
        ...     api_key="sk_xxx",
        ... )
        >>> items = s.get_organic_results()
        >>> # 异步
        >>> items = await s.async_get_organic_results()

    Context manager:
        >>> with AdvancedSearch(q="+AI -Google", api_key="sk_xxx") as s:
        ...     items = s.get_organic_results()
    """

    def __init__(
        self,
        q: Optional[str] = None,
        *,
        must_keywords: Optional[List[str]] = None,
        should_keywords: Optional[List[str]] = None,
        not_keywords: Optional[List[str]] = None,
        phrase_keywords: Optional[List[str]] = None,
        keywords: Optional[str] = None,
        days: int = DEFAULT_DAYS,
        time_range: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        category: Optional[str] = None,
        region: Optional[str] = None,
        language: Optional[str] = None,
        source_ids: Optional[List[str]] = None,
        cvc_model_id: Optional[str] = None,
        min_tscore: float = DEFAULT_MIN_TSCORE,
        limit: int = DEFAULT_LIMIT,
        fallback: bool = DEFAULT_FALLBACK,  # [v1.8 FIX-S3] 默认关闭 Google News 外部补源（确需时显式 True）
        min_content_words: int = 200,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        client: Optional[Any] = None,  # [v1.8.1] 注入复用 httpx.Client（共享连接池；不负责关闭）
    ) -> None:
        if not any([q, must_keywords, should_keywords, not_keywords, phrase_keywords, keywords]):
            raise ValidationError(
                "AdvancedSearch requires at least one of: q, must_keywords, "
                "should_keywords, not_keywords, phrase_keywords, keywords"
            )

        self._search_params: Dict[str, Any] = {
            "days": days,
            "min_tscore": min_tscore,
            "limit": limit,
            "fallback": fallback,
            "min_content_words": min_content_words,
        }
        if q is not None:
            self._search_params["q"] = q
        if must_keywords is not None:
            self._search_params["must_keywords"] = ",".join(must_keywords)
        if should_keywords is not None:
            self._search_params["should_keywords"] = ",".join(should_keywords)
        if not_keywords is not None:
            self._search_params["not_keywords"] = ",".join(not_keywords)
        if phrase_keywords is not None:
            self._search_params["phrase_keywords"] = ",".join(phrase_keywords)
        if keywords is not None:
            self._search_params["keywords"] = keywords
        if time_range is not None:
            self._search_params["time_range"] = time_range
        if start_date is not None:
            self._search_params["start_date"] = start_date
        if end_date is not None:
            self._search_params["end_date"] = end_date
        if category is not None:
            self._search_params["category"] = category
        if region is not None:
            self._search_params["region"] = region
        if language is not None:
            self._search_params["language"] = language
        if source_ids is not None:
            self._search_params["source_ids"] = ",".join(source_ids)
        if cvc_model_id is not None:
            self._search_params["cvc_model_id"] = cvc_model_id

        self._client = HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout, client=client)
        self._last_response: Optional[Dict[str, Any]] = None

    # ---- 同步 ----

    def get_dict(self) -> Dict[str, Any]:
        """发起高级检索请求，返回完整响应 dict。"""
        response = self._client.get(PATH_SEARCHX, params=self._search_params)
        self._last_response = response
        return response

    def get_organic_results(self) -> List[IntelligenceItem]:
        """快捷获取 ``items`` 数组。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return self._last_response.get("items", [])

    def get_count(self) -> int:
        """快捷获取命中总数。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return self._last_response.get("count", 0)

    def get_json(self, indent: Optional[int] = 2) -> str:
        """JSON 字符串形式返回。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return json.dumps(self._last_response, indent=indent, ensure_ascii=False)

    # ---- 异步 ----

    async def async_get_dict(self) -> Dict[str, Any]:
        """异步版本 :meth:`get_dict`。"""
        response = await self._client.async_get(PATH_SEARCHX, params=self._search_params)
        self._last_response = response
        return response

    async def async_get_organic_results(self) -> List[IntelligenceItem]:
        """异步版本 :meth:`get_organic_results`。"""
        await self.async_get_dict()
        assert self._last_response is not None
        return self._last_response.get("items", [])

    # ---- 上下文管理 ----

    def __enter__(self) -> "AdvancedSearch":
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    @property
    def params(self) -> Dict[str, Any]:
        return dict(self._search_params)

    @property
    def last_response(self) -> Optional[Dict[str, Any]]:
        return self._last_response


def search_advanced(
    q: Optional[str] = None,
    *,
    must_keywords: Optional[List[str]] = None,
    should_keywords: Optional[List[str]] = None,
    not_keywords: Optional[List[str]] = None,
    phrase_keywords: Optional[List[str]] = None,
    keywords: Optional[str] = None,
    days: int = DEFAULT_DAYS,
    time_range: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    category: Optional[str] = None,
    region: Optional[str] = None,
    language: Optional[str] = None,
    source_ids: Optional[List[str]] = None,
    cvc_model_id: Optional[str] = None,
    min_tscore: float = DEFAULT_MIN_TSCORE,
    limit: int = DEFAULT_LIMIT,
    fallback: bool = DEFAULT_FALLBACK,  # [v1.8 FIX-S3] 默认关闭 Google News 外部补源（确需时显式 True）
    min_content_words: int = 200,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """函数式高级检索接口（一次性请求，自动释放连接池）。

    支持三种查询模式，优先级：``q`` > 高级参数 > ``keywords`` 兼容模式。

    Example:
        >>> from casee_intelligence import search_advanced
        >>> # 查询语法
        >>> result = search_advanced("+AI +(Nvidia OR Apple) -research", api_key="sk_xxx")
        >>> # 高级参数
        >>> result = search_advanced(
        ...     must_keywords=["AI", "chip"],
        ...     not_keywords=["Google"],
        ...     api_key="sk_xxx",
        ... )
        >>> # 两段式：限定可信信源 + 时间窗口（v1.3）
        >>> result = search_advanced(
        ...     q="+(EV OR battery)",
        ...     source_ids=["reuters", "bloomberg"],
        ...     start_date="2026-07-01",
        ...     end_date="2026-07-31",
        ...     min_tscore=0.6,
        ...     api_key="sk_xxx",
        ... )

    Args:
        q: 查询语法字符串（类 Google 语法，优先级最高）
            - ``+word``: 必须包含（AND）
            - ``word1 word2``: 任一匹配（OR）
            - ``-word``: 排除（NOT）
            - ``"phrase"``: 精确短语匹配
            - ``word1|word2``: 同义词组（OR）
            - ``+(A OR B)``: 分组
        must_keywords: 必须匹配的关键词列表（AND 逻辑）
        should_keywords: 可选匹配的关键词列表（OR 逻辑）
        not_keywords: 排除的关键词列表（NOT 逻辑）
        phrase_keywords: 精确短语列表
        keywords: 逗号分隔关键词（OR 逻辑，兼容旧版）
        days: 时间窗口（天），默认 30
        start_date: 精确起始日期 YYYY-MM-DD（优先级高于 days）
        end_date: 精确结束日期 YYYY-MM-DD（与 start_date 配对）
        category / region / language: 多维过滤
        source_ids: 信源 ID 列表（限定检索的信源范围，v1.3 新增）
        cvc_model_id: CVC 模型 ID（传入时触发 CVC 归集流程）
        min_tscore: 最低 tscore（0.0-1.0）
        limit: 返回条数上限
        api_key: API Key（默认读 ``CASEE_API_KEY`` 环境变量）
        base_url: API 基址（默认读环境变量）

    Returns:
        完整响应 dict（含 ``count`` + ``items``）
    """
    with AdvancedSearch(
        q=q,
        must_keywords=must_keywords,
        should_keywords=should_keywords,
        not_keywords=not_keywords,
        phrase_keywords=phrase_keywords,
        keywords=keywords,
        days=days,
        time_range=time_range,
        start_date=start_date,
        end_date=end_date,
        category=category,
        region=region,
        language=language,
        source_ids=source_ids,
        cvc_model_id=cvc_model_id,
        min_tscore=min_tscore,
        limit=limit,
        fallback=fallback,
        min_content_words=min_content_words,
        api_key=api_key,
        base_url=base_url,
    ) as s:
        return s.get_dict()


# ---- 信源检索接口（v1.3 新增，支持关键字/类别/tscore 过滤 + sample data）----


class SourceSearch:
    """信源检索客户端：按类别/关键字模糊查询 + tscore 可信度过滤。

    通过 ``GET /v1/sources/search`` 端点，返回每个信源的详细 properties
    （plugin_registry 完整元数据）与 sample data（该信源最新 N 条情报样例），
    结果按 tscore 降序排列。

    典型用法（两段式可信情报检索的第一段）：
        >>> from casee_intelligence import SourceSearch
        >>> # 检索可信度 >= 0.6 的 market/tech 类信源
        >>> s = SourceSearch(keyword="finance", min_tscore=0.6, api_key="sk_xxx")
        >>> sources = s.get_sources()
        >>> ids = [x["source_id"] for x in sources]
        >>> # 第二段：拿 source_ids 去检索情报
        >>> from casee_intelligence import search_advanced
        >>> result = search_advanced(q="+EV +battery", source_ids=ids, api_key="sk_xxx")

    Context manager:
        >>> with SourceSearch(category="tech", min_tscore=0.6) as s:
        ...     sources = s.get_sources()
    """

    def __init__(
        self,
        *,
        keyword: Optional[str] = None,
        category: Optional[str] = None,
        region: Optional[str] = None,
        language: Optional[str] = None,
        min_tscore: float = 0.0,
        sample_size: int = 3,
        limit: int = 50,
        skip: int = 0,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> None:
        if not any([keyword, category, region, language, min_tscore > 0]):
            raise ValidationError(
                "SourceSearch requires at least one filter: keyword, category, "
                "region, language, or min_tscore > 0"
            )

        self._search_params: Dict[str, Any] = {
            "min_tscore": min_tscore,
            "sample_size": sample_size,
            "limit": limit,
            "skip": skip,
        }
        if keyword is not None:
            self._search_params["keyword"] = keyword
        if category is not None:
            self._search_params["category"] = category
        if region is not None:
            self._search_params["region"] = region
        if language is not None:
            self._search_params["language"] = language

        self._client = HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout)
        self._last_response: Optional[Dict[str, Any]] = None

    # ---- 同步 ----

    def get_dict(self) -> Dict[str, Any]:
        """发起信源检索请求，返回完整响应 dict。"""
        response = self._client.get(PATH_SOURCES_SEARCH, params=self._search_params)
        self._last_response = response
        return response

    def get_sources(self) -> List[Dict[str, Any]]:
        """快捷获取 ``sources`` 数组（含 properties + sample_data）。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return self._last_response.get("sources", [])

    def get_source_ids(self) -> List[str]:
        """快捷提取 source_id 列表（可直接传给 AdvancedSearch(source_ids=...)）。"""
        return [s.get("source_id") for s in self.get_sources() if s.get("source_id")]

    def get_json(self, indent: Optional[int] = 2) -> str:
        """JSON 字符串形式返回。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return json.dumps(self._last_response, indent=indent, ensure_ascii=False)

    # ---- 异步 ----

    async def async_get_dict(self) -> Dict[str, Any]:
        """异步版本 :meth:`get_dict`。"""
        response = await self._client.async_get(PATH_SOURCES_SEARCH, params=self._search_params)
        self._last_response = response
        return response

    async def async_get_sources(self) -> List[Dict[str, Any]]:
        """异步版本 :meth:`get_sources`。"""
        await self.async_get_dict()
        assert self._last_response is not None
        return self._last_response.get("sources", [])

    # ---- 上下文管理 ----

    def __enter__(self) -> "SourceSearch":
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    @property
    def params(self) -> Dict[str, Any]:
        return dict(self._search_params)

    @property
    def last_response(self) -> Optional[Dict[str, Any]]:
        return self._last_response


def search_sources(
    *,
    keyword: Optional[str] = None,
    category: Optional[str] = None,
    region: Optional[str] = None,
    language: Optional[str] = None,
    min_tscore: float = 0.0,
    sample_size: int = 3,
    limit: int = 50,
    skip: int = 0,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """函数式信源检索接口（一次性请求，自动释放连接池）。

    Example:
        >>> from casee_intelligence import search_sources
        >>> # 可信度 >= 0.6 的 tech 类信源，附 3 条样例数据
        >>> result = search_sources(category="tech", min_tscore=0.6, api_key="sk_xxx")
        >>> for src in result["sources"]:
        ...     print(src["source_id"], src["tscore"], len(src["sample_data"]))

    Args:
        keyword: 关键字模糊查询（匹配 source_id / name / description，不区分大小写）
        category: 信源类别过滤（模糊匹配，如 wire / mainstream / tech / market / ai）
        region: 地区过滤（模糊匹配）
        language: 语言过滤（精确匹配，如 en / zh）
        min_tscore: 最低信源可信度 tscore（0.0-1.0），如 0.6
        sample_size: 每个信源返回的 sample data 条数（0=不返回）
        limit: 返回信源数上限
        skip: 分页偏移
        api_key: API Key（默认读 ``CASEE_API_KEY`` 环境变量）
        base_url: API 基址（默认读环境变量）

    Returns:
        完整响应 dict（含 ``count`` / ``total`` / ``sources``）
    """
    with SourceSearch(
        keyword=keyword,
        category=category,
        region=region,
        language=language,
        min_tscore=min_tscore,
        sample_size=sample_size,
        limit=limit,
        skip=skip,
        api_key=api_key,
        base_url=base_url,
    ) as s:
        return s.get_dict()


# ---- 语义检索接口（v1.5 新增，基于 CVC 模型的两阶段语义检索）----


class SemanticSearch:
    """语义检索客户端：基于 CVC 模型的混合检索（BM25 + 向量 ANN + RRF 融合）。

    通过 ``POST /v1/semantic-search`` 端点，支持三种检索模式：
    - ``hybrid``（默认）：BM25 + 向量 ANN + RRF 融合
    - ``semantic``：纯向量语义检索
    - ``keyword``：纯关键词检索

    必传 ``cvc_model_id``（格式 ``^cvc_[a-z0-9]{8,32}$``）与 ``q``。

    Example:
        >>> from casee import SemanticSearch
        >>> s = SemanticSearch(
        ...     cvc_model_id="cvc_9f8e7d6c",
        ...     q="竞争对手在东南亚的电动化布局战略",
        ...     mode="hybrid",
        ...     top_k=20,
        ...     api_key="sk_xxx",
        ... )
        >>> items = s.get_organic_results()
    """

    def __init__(
        self,
        cvc_model_id: str,
        q: str,
        *,
        mode: str = "hybrid",
        top_k: int = 20,
        time_range: Optional[str] = None,
        days: Optional[int] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        category: Optional[str] = None,
        region: Optional[str] = None,
        language: Optional[str] = None,
        languages: Optional[List[str]] = None,
        source_categories: Optional[List[str]] = None,
        min_tscore: float = 0.0,
        rerank: bool = True,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> None:
        # 校验 cvc_model_id 格式
        import re
        if not re.match(r"^cvc_[a-z0-9]{8,32}$", cvc_model_id):
            raise ValidationError(
                f"cvc_model_id must match pattern ^cvc_[a-z0-9]{{8,32}}$, got: {cvc_model_id!r}"
            )

        # 校验 mode
        from .constants import SUPPORTED_SEMANTIC_MODES
        if mode not in SUPPORTED_SEMANTIC_MODES:
            raise ValidationError(
                f"Unsupported mode: {mode!r}. Supported: {', '.join(SUPPORTED_SEMANTIC_MODES)}"
            )

        if not q:
            raise ValidationError("SemanticSearch requires 'q' parameter (query text).")

        self._payload: Dict[str, Any] = {
            "cvc_model_id": cvc_model_id,
            "q": q,
            "mode": mode,
            "top_k": top_k,
            "rerank": rerank,
        }
        if time_range is not None:
            self._payload["time_range"] = time_range
        if days is not None:
            self._payload["days"] = days
        if start_date is not None:
            self._payload["start_date"] = start_date
        if end_date is not None:
            self._payload["end_date"] = end_date
        if category is not None:
            self._payload["category"] = category
        if region is not None:
            self._payload["region"] = region
        if language is not None:
            self._payload["language"] = language
        if languages is not None:
            self._payload["languages"] = languages
        if source_categories is not None:
            self._payload["source_categories"] = source_categories
        if min_tscore > 0:
            self._payload["min_tscore"] = min_tscore

        self._client = HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout)
        self._last_response: Optional[Dict[str, Any]] = None

    # ---- 同步 ----

    def get_dict(self) -> Dict[str, Any]:
        """发起语义检索请求，返回完整响应 dict（SerpAPI 风格四段式）。"""
        response = self._client.post(PATH_SEMANTIC_SEARCH, json_data=self._payload)
        self._last_response = response
        return response

    def get_organic_results(self) -> List[IntelligenceItem]:
        """快捷获取 ``organic_results`` 数组。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return self._last_response.get("organic_results", [])

    def get_fusion_stats(self) -> Dict[str, Any]:
        """获取融合统计信息（BM25 hits / vector hits / degraded 状态）。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        search_info = self._last_response.get("search_information", {})
        return search_info.get("fusion", {})

    def get_json(self, indent: Optional[int] = 2) -> str:
        """JSON 字符串形式返回。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return json.dumps(self._last_response, indent=indent, ensure_ascii=False)

    # ---- 上下文管理 ----

    def __enter__(self) -> "SemanticSearch":
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    @property
    def payload(self) -> Dict[str, Any]:
        return dict(self._payload)

    @property
    def last_response(self) -> Optional[Dict[str, Any]]:
        return self._last_response


def semantic_search(
    cvc_model_id: str,
    q: str,
    *,
    mode: str = "hybrid",
    top_k: int = 20,
    time_range: Optional[str] = None,
    days: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    category: Optional[str] = None,
    region: Optional[str] = None,
    language: Optional[str] = None,
    languages: Optional[List[str]] = None,
    source_categories: Optional[List[str]] = None,
    min_tscore: float = 0.0,
    rerank: bool = True,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """函数式语义检索接口（一次性请求，自动释放连接池）。

    基于 CVC（Competitive Value Chain）模型的两阶段语义检索，
    适用于竞品分析、市场趋势研判、客户需求洞察等场景。

    Example:
        >>> from casee import semantic_search
        >>> # 混合检索（推荐）
        >>> result = semantic_search(
        ...     cvc_model_id="cvc_9f8e7d6c",
        ...     q="竞争对手在东南亚的电动化布局战略",
        ...     mode="hybrid",
        ...     top_k=20,
        ...     api_key="sk_xxx",
        ... )
        >>> items = result.get("organic_results", [])
        >>> fusion = result.get("search_information", {}).get("fusion", {})

    Args:
        cvc_model_id: CVC 模型 ID，格式 ``^cvc_[a-z0-9]{8,32}$``（必填）
        q: 查询文本（必填）
        mode: 检索模式，可选值：
            - ``hybrid``（默认）：BM25 + 向量 ANN + RRF 融合
            - ``semantic``：纯向量语义检索
            - ``keyword``：纯关键词检索
        top_k: 返回条数上限，默认 20
        time_range: 预设时间范围（1d/7d/1m/3m），与 days 二选一
        days: 自定义时间窗口（天）
        category: 信源类别过滤
        region: 信源地区过滤
        language: 信源语言过滤
        min_tscore: 最低可信度（0.0-1.0）
        api_key: API Key（默认读 ``CASEE_API_KEY`` 环境变量）
        base_url: API 基址（默认读环境变量）

    Returns:
        SerpAPI 风格四段式响应 dict，含 ``search_metadata`` / ``search_parameters`` /
        ``search_information``（含 ``fusion`` 统计）/ ``organic_results``
    """
    with SemanticSearch(
        cvc_model_id=cvc_model_id,
        q=q,
        mode=mode,
        top_k=top_k,
        time_range=time_range,
        days=days,
        start_date=start_date,
        end_date=end_date,
        category=category,
        region=region,
        language=language,
        languages=languages,
        source_categories=source_categories,
        min_tscore=min_tscore,
        rerank=rerank,
        api_key=api_key,
        base_url=base_url,
    ) as s:
        return s.get_dict()


# ---- 服务端批量检索（v1.9 新增，POST /v1/search/batch）----


class BatchSearch:
    """服务端批量检索客户端：多组高级检索一次往返（POST /v1/search/batch）。

    与 :func:`search_many`（本地并发编排）不同，本类把整批检索交给服务端一次调用，
    由服务端并发执行各组并统一跨组去重，适合 CVC 生成 / 定时更新等大批量场景。
    batch 场景服务端恒不触发 Google News 补源（fallback 硬置 False）。

    Args:
        groups: 检索组列表。每组为 dict，字段与 /v1/searchx 高级参数一致：
            id（组标识，必填）、q / must_keywords / should_keywords /
            not_keywords / phrase_keywords / keywords、days（默认 30）、
            start_date / end_date / since_ts（增量下界 ISO8601）、
            category / region / language、source_ids、min_tscore、limit（默认 20）。
        dedupe: 是否跨组按 URL/标题归一化去重（默认 True，保留首次出现的组）。
        max_concurrency: 服务端并发组数上限（1-8，默认 4）。
        api_key / base_url / timeout: 客户端配置。

    Example:
        >>> from casee import BatchSearch
        >>> s = BatchSearch([
        ...     {"id": "must_ai", "must_keywords": ["AI"],
        ...      "should_keywords": ["Nvidia", "chip"], "days": 1000, "limit": 20},
        ...     {"id": "since_inc", "q": "+AI", "days": 30,
        ...      "since_ts": "2026-09-08T00:00:00Z", "limit": 10},
        ... ], api_key="sk_xxx")
        >>> result = s.get_dict()
        >>> for g in result["results"]:
        ...     print(g["id"], g.get("count"), g.get("error", ""))
    """

    def __init__(
        self,
        groups: List[Dict[str, Any]],
        *,
        dedupe: bool = True,
        max_concurrency: int = 4,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> None:
        if not isinstance(groups, (list, tuple)) or not groups:
            raise ValidationError("search_batch requires a non-empty 'groups' list.")
        if len(groups) > 50:
            raise ValidationError("search_batch supports at most 50 groups per call.")
        if max_concurrency < 1 or max_concurrency > 8:
            raise ValidationError("max_concurrency must be between 1 and 8.")

        self._payload: Dict[str, Any] = {
            "groups": groups,
            "dedupe": bool(dedupe),
            "max_concurrency": int(max_concurrency),
        }
        self._client = HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout)
        self._last_response: Optional[Dict[str, Any]] = None

    # ---- 同步 ----

    def get_dict(self) -> Dict[str, Any]:
        """发起批量检索请求，返回完整响应 dict。"""
        response = self._client.post(PATH_SEARCH_BATCH, json_data=self._payload)
        self._last_response = response
        return response

    def get_results(self) -> List[Dict[str, Any]]:
        """快捷获取 ``results`` 数组（每组含 id/count/items/stats 或 error）。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return self._last_response.get("results", [])

    def get_json(self, indent: Optional[int] = 2) -> str:
        """JSON 字符串形式返回。"""
        if self._last_response is None:
            self.get_dict()
        assert self._last_response is not None
        return json.dumps(self._last_response, indent=indent, ensure_ascii=False)

    # ---- 上下文管理 ----

    def __enter__(self) -> "BatchSearch":
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    @property
    def payload(self) -> Dict[str, Any]:
        return dict(self._payload)

    @property
    def last_response(self) -> Optional[Dict[str, Any]]:
        return self._last_response


def search_batch(
    groups: List[Dict[str, Any]],
    *,
    dedupe: bool = True,
    max_concurrency: int = 4,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Dict[str, Any]:
    """函数式服务端批量检索接口（一次性请求，自动释放连接池）。

    一次请求并发执行多组高级检索并由服务端统一跨组去重，对应 ``POST /v1/search/batch``。

    Example:
        >>> from casee import search_batch
        >>> out = search_batch([
        ...     {"id": "a", "q": "+AI +Nvidia -research", "days": 30, "limit": 10},
        ...     {"id": "b", "must_keywords": ["EV"], "should_keywords": ["battery"],
        ...      "start_date": "2026-08-01", "end_date": "2026-08-31", "limit": 10},
        ... ], api_key="sk_xxx")
        >>> for g in out["results"]:
        ...     print(g["id"], g.get("count"), g.get("error", ""))

    Args:
        groups: 检索组列表（每组字段与 /v1/searchx 高级参数一致，``id`` 必填）。
            - 快速组（仅裸 q 逗号串、无布尔词）：与 GET /v1/search 同语义（逗号 OR）；
            - 高级组（含 must/should/not/phrase/keywords 或 q 语法）：与 GET /v1/searchx 同语义。
        dedupe: 跨组 URL/标题去重（默认 True，保留首次出现的组）。
        max_concurrency: 服务端并发组数上限（1-8，默认 4）。
        api_key: API Key（默认读 ``CASEE_API_KEY`` 环境变量）。
        base_url: API 基址（默认读环境变量）。
        timeout: 请求超时（秒）。

    Returns:
        ``{"results": [...], "meta": {groups, returned_total, dedupe,
        cross_group_dropped, elapsed_ms}}``；单组失败以 ``error`` 字段隔离。
    """
    with BatchSearch(
        groups,
        dedupe=dedupe,
        max_concurrency=max_concurrency,
        api_key=api_key,
        base_url=base_url,
        timeout=timeout,
    ) as s:
        return s.get_dict()
