"""casee — CaSee Intelligence Server Python SDK.

快速开始：
    from casee import search

    result = search("AI,Nvidia", api_key="sk_xxx", days=30)

    from casee import search_advanced, search_sources, semantic_search

    # 高级检索：AND/OR/NOT 复杂逻辑
    result = search_advanced("+EV +(battery|charging) -China", source_ids=["reuters"],
                             api_key="sk_xxx")

    # 信源检索：发现可信信源
    result = search_sources(category="wire", min_tscore=0.7, api_key="sk_xxx")

    # 语义检索：基于 CVC 模型的混合检索
    result = semantic_search(
        cvc_model_id="cvc_9f8e7d6c",
        q="竞争对手在东南亚的电动化布局战略",
        mode="hybrid",
        top_k=20,
        api_key="sk_xxx",
    )

    # CVC 模型与关联情报管理（v1.7 新增）
    from casee import list_cvc_models, list_associated_docs, link_docs, unlink_docs

    list_cvc_models(api_key="sk_xxx")           # 模型列表（含关联 doc 数）
    list_associated_docs("cvc_9f8e7d6c", api_key="sk_xxx")
    link_docs("cvc_9f8e7d6c", ["66b1f0a1..."], q="人工补关联", api_key="sk_xxx")
    unlink_docs("cvc_9f8e7d6c", ["66b1f0a1..."], api_key="sk_xxx")  # 不删情报本身

环境变量：
    - ``CASEE_API_KEY``: API Key
    - ``CASEE_API_BASE_URL``: API 基址（默认 http://121.43.113.132:8000）
    - ``CASEE_TIMEOUT``: 请求超时（秒，默认 30）
"""
from .constants import (
    DEFAULT_API_BASE_URL,
    DEFAULT_DAYS,
    DEFAULT_ENGINE,
    DEFAULT_LIMIT,
    DEFAULT_MIN_TSCORE,
    DEFAULT_TIMEOUT,
    ENGINE_ENTITIES,
    ENGINE_FEED,
    ENGINE_INTELLIGENCE,
    ENGINE_LATEST,
    ENGINE_SOURCE,
    SEMANTIC_MODE_HYBRID,
    SEMANTIC_MODE_SEMANTIC,
    SEMANTIC_MODE_KEYWORD,
    SUPPORTED_ENGINES,
    SUPPORTED_SEMANTIC_MODES,
    __version__,
)
from .exceptions import (
    APIError,
    AuthenticationError,
    CaseeError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)
from .cvc import (
    batch_delete_cvc_models,
    cvc_cache_purge,
    cvc_cleanup_status,
    cvc_reindex,
    cvc_stats,
    delete_cvc_model,
    link_docs,
    list_associated_docs,
    list_cvc_models,
    register_cvc_model,
    unlink_docs,
)
from .models import (
    AssociatedDocsResponse,
    CvcLinkResult,
    CvcModelInfo,
    CvcModelsResponse,
    CvcUnlinkResult,
    IntelligenceItem,
    LocationsResponse,
    SearchInformation,
    SearchMetadata,
    SearchParameters,
    SearchResponse,
    SourceInfo,
    StatsResponse,
)
from .search import (
    AdvancedSearch,
    BatchSearch,
    EntitySearch,
    IntelligenceKeywordSearch,
    IntelligenceSearch,
    LatestBySource,
    LatestIntelligence,
    QuickSearch,
    SemanticSearch,
    SourceFeedSearch,
    SourceSearch,
    get_locations,
    get_organic_results,
    get_stats,
    list_sources,
    search,
    search_advanced,
    search_batch,
    search_sources,
    semantic_search,
)
from .many import search_many  # [v1.8.1] 批量检索助手（本地并发编排）
from .purge import (  # [v1.9] 全量历史情报清除
    get_intelligence_purge_status,
    intelligence_purge,
    intelligence_purge_status,
)
from .search_terms import clean_keywords  # [v1.8.1] 内置检索词卫生化

__all__ = [
    # 版本
    "__version__",
    # 核心类
    "QuickSearch",
    "AdvancedSearch",
    "SourceSearch",
    "SemanticSearch",
    "BatchSearch",  # [v1.9] 服务端批量检索
    # 向后兼容类（deprecated）
    "IntelligenceSearch",
    "IntelligenceKeywordSearch",
    "EntitySearch",
    "LatestIntelligence",
    "SourceFeedSearch",
    "LatestBySource",
    # 函数式接口
    "search",
    "search_advanced",
    "search_many",
    "clean_keywords",
    "search_batch",  # [v1.9] 服务端批量检索
    "search_sources",
    "semantic_search",
    "get_organic_results",
    "list_sources",
    "get_stats",
    "get_locations",
    # CVC 模型与关联情报管理（v1.7 新增）
    "list_cvc_models",
    "register_cvc_model",
    "delete_cvc_model",
    "batch_delete_cvc_models",
    "list_associated_docs",
    "link_docs",
    "unlink_docs",
    # CVC 运维接口（v1.9 新增）
    "cvc_stats",
    "cvc_cache_purge",
    "cvc_cleanup_status",
    "cvc_reindex",
    # 全量历史情报清除（v1.9 新增）
    "intelligence_purge",
    "intelligence_purge_status",
    "get_intelligence_purge_status",
    # 类型
    "SearchMetadata",
    "SearchParameters",
    "SearchInformation",
    "SearchResponse",
    "IntelligenceItem",
    "SourceInfo",
    "StatsResponse",
    "LocationsResponse",
    "CvcModelInfo",
    "CvcModelsResponse",
    "AssociatedDocsResponse",
    "CvcLinkResult",
    "CvcUnlinkResult",
    # 异常
    "CaseeError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "NotFoundError",
    "ServerError",
    "TimeoutError",
    "NetworkError",
    "APIError",
    # 语义检索常量
    "SEMANTIC_MODE_HYBRID",
    "SEMANTIC_MODE_SEMANTIC",
    "SEMANTIC_MODE_KEYWORD",
    "SUPPORTED_SEMANTIC_MODES",
    # 向后兼容常量（deprecated，v2.0 移除）
    "DEFAULT_API_BASE_URL",
    "DEFAULT_DAYS",
    "DEFAULT_ENGINE",
    "DEFAULT_LIMIT",
    "DEFAULT_MIN_TSCORE",
    "DEFAULT_TIMEOUT",
]
