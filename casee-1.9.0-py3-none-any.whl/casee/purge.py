"""casee SDK — 全量历史情报清除接口（v1.9 新增）。

对应 ``/v1/intelligence/purge`` 管理端点，支持按时间范围跨库清除旧历史情报：

- ``POST /v1/intelligence/purge``         全量历史清除（异步 202；dry_run 同步 200）
- ``GET  /v1/intelligence/purge/status``  进度与各库残留对账

函数式便捷接口：
    from casee import intelligence_purge, intelligence_purge_status

    # 预演：仅统计各库将清除数量（无副作用，同步 200）
    est = intelligence_purge(older_than_days=90, dry_run=True, api_key="sk_xxx")

    # 实际清除 >90 天旧情报（含 MongoDB 主存储，异步 202 → 返回 task_id）
    resp = intelligence_purge(older_than_days=90, include_mongodb=True, api_key="sk_xxx")

    # 轮询进度与残留对账
    status = intelligence_purge_status(resp["task_id"], api_key="sk_xxx")
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .client import HTTPClient
from .constants import PATH_INTELLIGENCE_PURGE, PATH_INTELLIGENCE_PURGE_STATUS
from .exceptions import ValidationError


def intelligence_purge(
    *,
    older_than_days: Optional[int] = None,
    end_date: Optional[str] = None,
    cvc_model_ids: Optional[List[str]] = None,
    include_mongodb: bool = True,
    dry_run: bool = False,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """全量历史情报清除（POST /v1/intelligence/purge）。

    按时间范围（``older_than_days`` / ``end_date`` 二选一定 cutoff 时间下界）
    清除所有库中的旧历史情报：MongoDB source_feed（可选，include_mongodb）→
    OpenSearch → Qdrant → Redis 失效。这是全系统唯一允许删除情报本体的入口。

    - ``older_than_days`` / ``end_date``：二选一（cutoff 时间下界）；
    - ``cvc_model_ids``：限定归集库范围（缺省全部）；
    - ``include_mongodb``：是否清除 source_feed 原始情报（默认 True）；
    - ``dry_run``：仅估算各库将清除数量（同步 200，无删除副作用）。

    Returns:
        ``dry_run=True`` → 各库估算数量（同步 200）；
        ``dry_run=False`` → 受理异步任务：202 + ``task_id``（可轮询
        :func:`intelligence_purge_status`）。

    Note:
        全局互斥：与 CVC 级全量清除/删除双向 409（服务端返回
        ``error_code=CONCURRENT_OP`` 时本 SDK 抛出对应 APIError）。
    """
    if older_than_days is None and not end_date:
        raise ValidationError(
            "intelligence_purge requires one of 'older_than_days' or 'end_date'."
        )
    if older_than_days is not None and end_date:
        raise ValidationError("older_than_days and end_date are mutually exclusive.")

    payload: Dict[str, Any] = {
        "older_than_days": older_than_days,
        "end_date": end_date,
        "cvc_model_ids": cvc_model_ids,
        "include_mongodb": bool(include_mongodb),
        "dry_run": bool(dry_run),
    }
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_INTELLIGENCE_PURGE, json_data=payload)


def intelligence_purge_status(
    task_id: Optional[str] = None,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """全量历史清除进度与各库残留对账（GET /v1/intelligence/purge/status）。

    返回任务状态机进度（pending → estimating → mongo_purging → os_purging →
    qd_purging → redis_invalidating → verifying → completed/failed）+ 各库
    count(published_at < cutoff) 实时残留计数。

    - ``task_id``：指定任务（缺省返回最近任务）。
    """
    params: Dict[str, Any] = {}
    if task_id:
        params["task_id"] = task_id
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_INTELLIGENCE_PURGE_STATUS, params=params or None)


def get_intelligence_purge_status(
    task_id: Optional[str] = None,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """兼容别名：``intelligence_purge_status`` 的同义词。"""
    return intelligence_purge_status(
        task_id, api_key=api_key, base_url=base_url
    )