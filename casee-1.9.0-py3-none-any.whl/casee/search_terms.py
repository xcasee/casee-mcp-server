"""检索词卫生化（SDK 优化 S2 / 服务端 FIX-S2 客户端对齐）。

背景（design/is-server-sdk-1.8.0-upgrade-and-optimization.md §5.2-2）：实体全称常含
全角括号注释（费列罗（Ferrero））、公司后缀（Inc./Ltd./Co., Ltd.）与泛词（Group/
Corporation/控股/集团 等）。这类"脏词"直接进入逗号 OR 串会让服务端整批检索脆弱
（历史上曾整批 0）。本模块提供与 EIRS ``search_terms`` 语义对齐的内置清洗：
``clean_keywords()`` 返回 ``(cleaned, dropped)``，供 SDK 批量助手 / 上层调用统一使用。
"""
from __future__ import annotations

import re
from typing import Iterable, List, Optional, Tuple

# 全角/半角括号内注释（如 费列罗（Ferrero））剥离
_PAREN_RE = re.compile(r"[（(][^（）()]*[)）]")
# 英文公司后缀（结尾，如 ... Inc / ... , Ltd）；仅在词为"多词英文实体"时剥离
_EN_SUFFIXES = {
    "inc", "corp", "corporation", "ltd", "limited",
    "group", "company", "co", "holdings", "holding",
}
# 通用泛词（中英，出现在词尾时剥离）
_GENERIC_STOP = {
    "group", "公司", "集团", "控股", "科技", "技术",
    "international", "collection", "line", "series",
}
_WHITESPACE_RE = re.compile(r"\s+")

# 建议的最大单词长度（超过视为异常 token）
_MAX_KEYWORD_LEN = 120


def clean_keywords(
    terms: Iterable[Optional[str]],
    *,
    drop_parenthetical: bool = True,
    drop_english_suffix: bool = True,
    drop_generic: bool = False,
    max_len: int = _MAX_KEYWORD_LEN,
) -> Tuple[List[str], List[str]]:
    """清洗检索词列表，返回 ``(cleaned, dropped)``。

    - ``drop_parenthetical``：剥离中文/英文括号注释（如 ``费列罗（Ferrero）`` → ``费列罗``）；
    - ``drop_english_suffix``：剥离英文实体词尾部公司后缀（``Mars, Incorporated`` → ``Mars``）；
    - ``drop_generic``：剥离尾部泛词（Group/公司/集团…），默认关闭（泛词可能是真实业务词）。
    - 空白/纯符号/超长 token 判脏剔除并计入 ``dropped``。
    """
    cleaned: List[str] = []
    dropped: List[str] = []
    for raw in terms:
        kw = (raw or "").strip()
        if not kw:
            continue
        if drop_parenthetical:
            kw = _PAREN_RE.sub("", kw).strip()
        if drop_english_suffix or drop_generic:
            words = _WHITESPACE_RE.split(kw)
            while len(words) > 1:
                tail = words[-1].strip(" ,，、.").lower()
                if drop_english_suffix and tail in _EN_SUFFIXES:
                    words.pop()
                    continue
                if drop_generic and tail in _GENERIC_STOP:
                    words.pop()
                    continue
                break
            kw = " ".join(words).strip()
        kw = _WHITESPACE_RE.sub(" ", kw).strip(" ,，、'\"")
        if not kw or len(kw) > max_len:
            dropped.append(str(raw))
            continue
        cleaned.append(kw)
    return cleaned, dropped
