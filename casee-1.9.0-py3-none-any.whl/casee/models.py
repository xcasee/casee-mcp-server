"""casee_intelligence SDK 类型定义。

使用 ``TypedDict`` 提供静态类型检查（runtime 零开销，无需 pydantic）。
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

try:
    from typing import TypedDict
except ImportError:  # Python 3.7 fallback
    from typing_extensions import TypedDict


class SearchMetadata(TypedDict, total=False):
    """``search_metadata`` 块：请求元信息。"""
    id: str
    status: str
    json_endpoint: str
    created_at: str
    processed_at: str
    total_time_taken: float


class SearchParameters(TypedDict, total=False):
    """``search_parameters`` 块：回显本次请求的查询参数。"""
    engine: str
    q: Optional[str]
    source_id: Optional[str]
    days: int
    time_range: Optional[str]
    start_date: Optional[str]
    end_date: Optional[str]
    cvc_model_id: Optional[str]
    category: Optional[str]
    region: Optional[str]
    language: Optional[str]
    min_tscore: float
    limit: int
    fallback: bool
    min_content_words: int


class SearchInformation(TypedDict, total=False):
    """``search_information`` 块：命中数 + 耗时 + 查询文本 + 计数/词表观测。

    [v1.8] 服务端 (2026-09 起) 透传存储层计数与词表卫生观测字段：
    raw_hits / dropped_by_filter / duplicates_removed / truncated 与
    hygiene_dropped / hygiene_partial（脏词剔除可观测，见 design/is-server-bugs.md FIX-S2）。
    """
    total_results: int
    time_elapsed_displayed: float
    query_displayed: str
    returned: int
    raw_hits: Optional[int]
    dropped_by_filter: Optional[int]
    duplicates_removed: Optional[int]
    truncated: bool
    hygiene_dropped: Optional[List[str]]
    hygiene_partial: Optional[bool]


class IntelligenceItem(TypedDict, total=False):
    """单条情报条目（``organic_results`` 数组元素）。"""
    news_id: str
    title: str
    link: str
    url: str
    published_at: str
    scraped_at: str
    content: str
    summary: str
    abstract: str
    description: str
    source_id: str
    source_name: str
    source_url: str
    source_category: str
    source_region: str
    source_language: str
    tscore: float
    author: str
    image_url: str
    original_image_url: str
    categories: List[str]
    guid: str
    collected_from: str
    matched_entity: str  # engine=entities 时


class SourceInfo(TypedDict, total=False):
    """``/v1/sources`` 返回的单个信源信息。"""
    source_id: str
    name: str
    url: str
    category: str
    region: str
    language: str
    avg_tscore: float
    document_count: int
    latest_published: str


class SearchResponse(TypedDict, total=False):
    """``GET /v1/search`` 完整响应包。"""
    search_metadata: SearchMetadata
    search_parameters: SearchParameters
    search_information: SearchInformation
    organic_results: List[IntelligenceItem]
    entities: List[str]  # engine=entities 时附带


class LocationsResponse(TypedDict, total=False):
    """``GET /v1/locations`` 响应。"""
    categories: List[str]
    regions: List[str]
    languages: List[str]


class StatsResponse(TypedDict, total=False):
    """``GET /v1/stats`` 响应。"""
    total_documents: int
    by_category: Dict[str, int]


class CvcModelInfo(TypedDict, total=False):
    """``GET /v1/cvc/models`` 返回的单个 CVC 模型。"""
    cvc_model_id: str
    doc_count: Optional[int]
    query_count: Optional[int]
    first_collected_at: Optional[str]
    last_collected_at: Optional[str]
    registered: bool
    registered_at: Optional[str]
    source: str


class CvcModelsResponse(TypedDict, total=False):
    """``GET /v1/cvc/models`` 响应。"""
    count: int
    models: List[CvcModelInfo]


class AssociatedDocsResponse(TypedDict, total=False):
    """``GET /v1/cvc/{id}/docs`` 响应（已关联情报，条目与检索结果同构）。"""
    cvc_model_id: str
    total: int
    returned: int
    skip: int
    limit: int
    stale_docs: int
    items: List[IntelligenceItem]


class CvcLinkResult(TypedDict, total=False):
    """``POST /v1/cvc/{id}/docs`` 关联结果。"""
    cvc_model_id: str
    requested: int
    found: int
    linked_new: int
    already_linked: int
    message: str


class CvcUnlinkResult(TypedDict, total=False):
    """``DELETE /v1/cvc/{id}/docs`` 解除关联结果。"""
    cvc_model_id: str
    requested: int
    removed: int
    not_associated: int
    message: str


# 便捷别名
SearchParams = Dict[str, Any]
"""搜索参数 dict（key 见 :class:`SearchParameters`，外加 ``api_key``）。"""
