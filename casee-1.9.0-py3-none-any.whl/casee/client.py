"""casee_intelligence SDK HTTP 客户端。

封装 httpx 同步/异步请求，自动：
- 注入 ``X-API-Key`` header
- 拼接 base_url + path
- 解析 JSON 响应
- 根据 HTTP 状态码抛出对应异常
- 指数退避重试（5xx / 网络错误）
"""
from __future__ import annotations

import logging
import re
import time
from typing import Any, Dict, Optional, Tuple

import httpx

from .constants import (
    DEFAULT_API_BASE_URL,
    DEFAULT_TIMEOUT,
    DEFAULT_USER_AGENT,
    ENV_API_BASE_URL,
    ENV_API_KEY,
    ENV_TIMEOUT,
)
from .exceptions import (
    APIError,
    AuthenticationError,
    NetworkError,
    RateLimitError,
    ServerError,
    TimeoutError,
    raise_for_status,
)

logger = logging.getLogger("casee_intelligence.client")


# ---- HTML detection helpers (defensive; see HTTPClient._parse_body) ----

_HTML_PREFIX_RE = re.compile(r"^\s*(<!doctype\s+html|<html\b)", re.IGNORECASE)
_HTML_TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)


def _looks_like_html(text: str) -> bool:
    """Best-effort HTML detection for responses that don't set Content-Type correctly."""
    if not text:
        return False
    stripped = text.lstrip()
    if _HTML_PREFIX_RE.match(stripped):
        return True
    # Some misbehaving proxies drop doctype but still serve full pages.
    lower = stripped[:500].lower()
    return "<html" in lower and ("<head" in lower or "<body" in lower)


def _extract_html_title(text: str) -> str:
    m = _HTML_TITLE_RE.search(text)
    if not m:
        return ""
    import html as _html
    return _html.unescape(m.group(1)).strip()[:200]


def _resolve_config(
    api_key: Optional[str],
    base_url: Optional[str],
    timeout: Optional[float],
) -> Tuple[str, str, float]:
    """解析最终配置：参数 > 环境变量 > 默认值。"""
    import os

    final_key = api_key or os.environ.get(ENV_API_KEY, "")
    final_base = (base_url or os.environ.get(ENV_API_BASE_URL, "") or DEFAULT_API_BASE_URL).rstrip("/")
    final_timeout = (
        timeout if timeout is not None
        else float(os.environ.get(ENV_TIMEOUT, "") or DEFAULT_TIMEOUT)
    )
    return final_key, final_base, final_timeout


class HTTPClient:
    """同步 + 异步双模 HTTP 客户端。

    自动复用连接池，支持上下文管理释放资源。

    Example:
        >>> with HTTPClient(api_key="sk_xxx") as client:
        ...     resp = client.get("/v1/search", params={"q": "AI"})
        ...     print(resp["organic_results"])
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: int = 3,
        backoff_factor: float = 0.5,
        user_agent: str = DEFAULT_USER_AGENT,
        connect_timeout: Optional[float] = None,
        read_timeout: Optional[float] = None,
        client: Optional[httpx.Client] = None,
    ) -> None:
        """HTTP 客户端。

        [v1.8.1] 分层超时与连接复用（design/is-server-sdk-1.8.0... §5.2）：
        - ``connect_timeout`` / ``read_timeout``：可单独配置（默认跟随 ``timeout``）；
        - ``client``：注入复用外部 ``httpx.Client``（keep-alive 连接池），批量高频场景
          多个 HTTPClient/检索实例共享同一连接，避免每次新建连接（不持有则不负责关闭）。
        """
        self.api_key, self.base_url, self.timeout = _resolve_config(api_key, base_url, timeout)
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor

        # 分层超时：connect/read 缺省跟随总超时；总超时即 self.timeout
        self.connect_timeout = connect_timeout if connect_timeout is not None else self.timeout
        self.read_timeout = read_timeout if read_timeout is not None else self.timeout
        self._httpx_timeout = httpx.Timeout(
            self.timeout,
            connect=self.connect_timeout,
            read=self.read_timeout,
            write=self.read_timeout,
            pool=self.connect_timeout,
        )

        self._headers = {
            "User-Agent": user_agent,
            "Accept": "application/json",
        }
        if self.api_key:
            self._headers["X-API-Key"] = self.api_key

        # 同步 client（懒创建）；异步 client 用完即弃
        self._sync_client: Optional[httpx.Client] = None
        self._owns_client = client is None
        if client is not None:
            self._sync_client = client

    # ---- 同步 ----

    @property
    def sync_client(self) -> httpx.Client:
        """懒创建/复用同步 httpx.Client。"""
        if self._sync_client is None:
            self._sync_client = httpx.Client(
                base_url=self.base_url,
                headers=self._headers,
                timeout=self._httpx_timeout,
                follow_redirects=True,
            )
        return self._sync_client

    def get(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """同步 GET 请求。

        Args:
            path: API 路径（如 ``/v1/search``）
            params: query 参数
            extra_headers: 附加请求头

        Returns:
            解析后的 JSON dict

        Raises:
            AuthenticationError / NotFoundError / ValidationError /
            RateLimitError / ServerError / TimeoutError / NetworkError / APIError
        """
        # 自动注入 api_key 到 query（SerpAPI 兼容，与 header 二选一即可）
        final_params = dict(params or {})
        if self.api_key and "api_key" not in final_params:
            final_params["api_key"] = self.api_key

        last_exc: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                resp = self.sync_client.get(path, params=final_params, headers=extra_headers or None)
                body = self._parse_body(resp)
                raise_for_status(resp.status_code, body, dict(resp.headers))
                return body if isinstance(body, dict) else {"data": body}

            except AuthenticationError:
                # 不可重试的错误：立即抛出
                raise
            except RateLimitError as exc:
                # [v1.8.1] 429 遵循 Retry-After 重试（仅在剩余尝试内且等待 ≤10s）
                raw_ra = getattr(exc, "retry_after", None)
                delay = 0.0
                try:
                    delay = float(raw_ra or 0) if raw_ra else 0.0
                except (TypeError, ValueError):
                    delay = 0.0
                if attempt < self.max_retries and 0 < delay <= 10:
                    logger.info("429 retry-after %.1fs (attempt %d/%d)", delay, attempt + 2, self.max_retries + 1)
                    last_exc = exc
                    time.sleep(delay)
                    continue
                raise
            except httpx.TimeoutException as exc:
                last_exc = TimeoutError(f"Request to {path} timed out: {exc}")
                logger.warning("Attempt %d timeout: %s", attempt + 1, exc)
            except httpx.ConnectError as exc:
                last_exc = NetworkError(f"Connection failed to {path}: {exc}")
                logger.warning("Attempt %d connect error: %s", attempt + 1, exc)
            except httpx.HTTPError as exc:
                last_exc = NetworkError(f"HTTP error for {path}: {exc}")
                logger.warning("Attempt %d http error: %s", attempt + 1, exc)
            except ServerError as exc:
                last_exc = exc
                logger.warning("Attempt %d server error %s: %s", attempt + 1, exc.status_code, exc)
            else:
                return body if isinstance(body, dict) else {"data": body}

            # 指数退避
            if attempt < self.max_retries:
                sleep = self.backoff_factor * (2 ** attempt)
                logger.info("Retrying in %.2fs (attempt %d/%d)", sleep, attempt + 2, self.max_retries + 1)
                time.sleep(sleep)

        # 全部重试失败
        assert last_exc is not None
        raise last_exc

    # ---- 异步 ----

    async def async_get(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """异步 GET 请求（每次创建独立 AsyncClient，无连接池复用）。"""
        final_params = dict(params or {})
        if self.api_key and "api_key" not in final_params:
            final_params["api_key"] = self.api_key

        last_exc: Optional[Exception] = None
        async with httpx.AsyncClient(
            base_url=self.base_url,
            headers={**self._headers, **(extra_headers or {})},
            timeout=self.timeout,
            follow_redirects=True,
        ) as client:
            for attempt in range(self.max_retries + 1):
                try:
                    resp = await client.get(path, params=final_params)
                    body = self._parse_body(resp)
                    raise_for_status(resp.status_code, body, dict(resp.headers))
                    return body if isinstance(body, dict) else {"data": body}

                except (RateLimitError, AuthenticationError):
                    raise
                except httpx.TimeoutException as exc:
                    last_exc = TimeoutError(f"Request to {path} timed out: {exc}")
                except httpx.ConnectError as exc:
                    last_exc = NetworkError(f"Connection failed to {path}: {exc}")
                except httpx.HTTPError as exc:
                    last_exc = NetworkError(f"HTTP error for {path}: {exc}")
                except ServerError as exc:
                    last_exc = exc
                else:
                    return body if isinstance(body, dict) else {"data": body}

                if attempt < self.max_retries:
                    sleep = self.backoff_factor * (2 ** attempt)
                    logger.info("Retrying in %.2fs (attempt %d/%d)", sleep, attempt + 2, self.max_retries + 1)
                    import asyncio
                    await asyncio.sleep(sleep)

        assert last_exc is not None
        raise last_exc

    # ---- POST ----

    def post(
        self,
        path: str,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """同步 POST 请求（用于语义检索等需要请求体的接口）。

        Args:
            path: API 路径（如 ``/v1/semantic-search``）
            json_data: JSON 请求体
            params: query 参数
            extra_headers: 附加请求头

        Returns:
            解析后的 JSON dict
        """
        final_params = dict(params or {})
        if self.api_key and "api_key" not in final_params:
            final_params["api_key"] = self.api_key

        last_exc: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                resp = self.sync_client.post(
                    path,
                    params=final_params,
                    json=json_data,
                    headers=extra_headers or None,
                )
                body = self._parse_body(resp)
                raise_for_status(resp.status_code, body, dict(resp.headers))
                return body if isinstance(body, dict) else {"data": body}

            except (RateLimitError, AuthenticationError):
                raise
            except httpx.TimeoutException as exc:
                last_exc = TimeoutError(f"POST {path} timed out: {exc}")
                logger.warning("Attempt %d timeout: %s", attempt + 1, exc)
            except httpx.ConnectError as exc:
                last_exc = NetworkError(f"Connection failed to {path}: {exc}")
                logger.warning("Attempt %d connect error: %s", attempt + 1, exc)
            except httpx.HTTPError as exc:
                last_exc = NetworkError(f"HTTP error for {path}: {exc}")
                logger.warning("Attempt %d http error: %s", attempt + 1, exc)
            except ServerError as exc:
                last_exc = exc
                logger.warning("Attempt %d server error %s: %s", attempt + 1, exc.status_code, exc)
            else:
                return body if isinstance(body, dict) else {"data": body}

            if attempt < self.max_retries:
                sleep = self.backoff_factor * (2 ** attempt)
                logger.info("Retrying in %.2fs (attempt %d/%d)", sleep, attempt + 2, self.max_retries + 1)
                time.sleep(sleep)

        assert last_exc is not None
        raise last_exc

    # ---- DELETE ----

    def delete(
        self,
        path: str,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """同步 DELETE 请求（支持 JSON body，用于解除关联等操作）。

        httpx 的 ``Client.delete`` 不直接接受 ``json``，这里统一走
        ``Client.request("DELETE", ...)``。

        Args:
            path: API 路径（如 ``/v1/cvc/{id}/docs``）
            json_data: JSON 请求体（可选）
            params: query 参数
            extra_headers: 附加请求头

        Returns:
            解析后的 JSON dict
        """
        final_params = dict(params or {})
        if self.api_key and "api_key" not in final_params:
            final_params["api_key"] = self.api_key

        last_exc: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                resp = self.sync_client.request(
                    "DELETE",
                    path,
                    params=final_params,
                    json=json_data,
                    headers=extra_headers or None,
                )
                body = self._parse_body(resp)
                raise_for_status(resp.status_code, body, dict(resp.headers))
                return body if isinstance(body, dict) else {"data": body}

            except (RateLimitError, AuthenticationError):
                raise
            except httpx.TimeoutException as exc:
                last_exc = TimeoutError(f"DELETE {path} timed out: {exc}")
                logger.warning("Attempt %d timeout: %s", attempt + 1, exc)
            except httpx.ConnectError as exc:
                last_exc = NetworkError(f"Connection failed to {path}: {exc}")
                logger.warning("Attempt %d connect error: %s", attempt + 1, exc)
            except httpx.HTTPError as exc:
                last_exc = NetworkError(f"HTTP error for {path}: {exc}")
                logger.warning("Attempt %d http error: %s", attempt + 1, exc)
            except ServerError as exc:
                last_exc = exc
                logger.warning("Attempt %d server error %s: %s", attempt + 1, exc.status_code, exc)
            else:
                return body if isinstance(body, dict) else {"data": body}

            if attempt < self.max_retries:
                sleep = self.backoff_factor * (2 ** attempt)
                logger.info("Retrying in %.2fs (attempt %d/%d)", sleep, attempt + 2, self.max_retries + 1)
                time.sleep(sleep)

        assert last_exc is not None
        raise last_exc

    async def async_delete(
        self,
        path: str,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """异步 DELETE 请求（支持 JSON body）。"""
        final_params = dict(params or {})
        if self.api_key and "api_key" not in final_params:
            final_params["api_key"] = self.api_key

        last_exc: Optional[Exception] = None
        async with httpx.AsyncClient(
            base_url=self.base_url,
            headers={**self._headers, **(extra_headers or {})},
            timeout=self.timeout,
            follow_redirects=True,
        ) as client:
            for attempt in range(self.max_retries + 1):
                try:
                    resp = await client.request(
                        "DELETE", path, params=final_params, json=json_data
                    )
                    body = self._parse_body(resp)
                    raise_for_status(resp.status_code, body, dict(resp.headers))
                    return body if isinstance(body, dict) else {"data": body}

                except (RateLimitError, AuthenticationError):
                    raise
                except httpx.TimeoutException as exc:
                    last_exc = TimeoutError(f"DELETE {path} timed out: {exc}")
                except httpx.ConnectError as exc:
                    last_exc = NetworkError(f"Connection failed to {path}: {exc}")
                except httpx.HTTPError as exc:
                    last_exc = NetworkError(f"HTTP error for {path}: {exc}")
                except ServerError as exc:
                    last_exc = exc
                else:
                    return body if isinstance(body, dict) else {"data": body}

                if attempt < self.max_retries:
                    sleep = self.backoff_factor * (2 ** attempt)
                    logger.info("Retrying in %.2fs (attempt %d/%d)", sleep, attempt + 2, self.max_retries + 1)
                    import asyncio
                    await asyncio.sleep(sleep)

        assert last_exc is not None
        raise last_exc

    # ---- 工具 ----

    @staticmethod
    def _parse_body(resp: httpx.Response) -> Any:
        """Parse response body as JSON.

        Defensive checks to avoid silently wrapping HTML error pages
        (e.g. when CASEE_API_BASE_URL points at a static website, or when a
        redirect leads to a non-API page) as ``{"data": "<!doctype html>..."}``.
        """
        content_type = resp.headers.get("content-type", "").lower()
        text = resp.text

        # Fast path: JSON content-type — just parse.
        if "application/json" in content_type:
            try:
                return resp.json()
            except Exception as exc:
                raise APIError(
                    f"Server returned Content-Type=application/json but body is not valid JSON. "
                    f"URL={resp.url!s} status={resp.status_code} body_preview={text[:200]!r}",
                    status_code=resp.status_code,
                    body={"raw": text[:1000]},
                ) from exc

        # HTML responses on a JSON API almost always indicate misconfiguration
        # (wrong base URL, nginx fallback page, SPA catch-all route, etc.).
        if "text/html" in content_type or _looks_like_html(text):
            # Try to extract <title> for a friendlier error
            title = _extract_html_title(text)
            raise APIError(
                f"Expected JSON response but got HTML from {resp.url!s} (status={resp.status_code}). "
                f"{('Page title: ' + repr(title) + '. ') if title else ''}"
                f"This usually means CASEE_API_BASE_URL is pointing at a web page instead of the "
                f"CaSee API server (e.g. a portal/landing page). Check the CASEE_API_BASE_URL "
                f"environment variable. Body preview: {text[:200]!r}",
                status_code=resp.status_code,
                body={"raw": text[:1000], "content_type": content_type, "title": title},
            )

        # Other non-JSON content types: try JSON parse; if it fails, raise.
        try:
            return resp.json()
        except Exception:
            # Last resort: return raw text for endpoints that might return
            # plain text (health used to do this in older versions).
            return text

    # ---- 上下文管理 ----

    def __enter__(self) -> "HTTPClient":
        # 预创建同步 client
        _ = self.sync_client
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def close(self) -> None:
        """释放底层 httpx 连接池（外部注入的 client 不负责关闭）。"""
        if self._sync_client is not None and self._owns_client:
            self._sync_client.close()
        if self._owns_client:
            self._sync_client = None
