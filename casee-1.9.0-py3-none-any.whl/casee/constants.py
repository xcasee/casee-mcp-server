"""casee SDK 常量定义。

定义搜索引擎枚举、默认值、环境变量名等。
"""
from __future__ import annotations

# 默认 API 端点（可被环境变量覆盖）
# 指向 CaSee 情报服务（FastAPI），切勿指向官网门户 https://casee.me
DEFAULT_API_BASE_URL = "http://121.43.113.132:8000"

# 环境变量名
ENV_API_KEY = "CASEE_API_KEY"
ENV_API_BASE_URL = "CASEE_API_BASE_URL"
ENV_TIMEOUT = "CASEE_TIMEOUT"

# 默认请求超时（秒）
DEFAULT_TIMEOUT = 30.0

# [v1.8 / FIX-S3] 检索请求 fallback 默认值：False = 默认只查本地库，不自动触发 Google
# News 外部补源。原因：出网受限/检索请求量大时，默认开启补源会触发大量一次性 gnews 采集
# 任务（2026-09-08 生产取证：近批 completed 任务 100% 为 fallback、87.7% 零入库），
# 并可能造成 30s+ 阻塞。确需"本地未命中即走 Google News 补源"的调用方请显式传
# ``fallback=True``（服务端另受 ``GNEWS_FALLBACK_ALLOW`` 硬闸管控）。
DEFAULT_FALLBACK = False

# 默认 User-Agent
DEFAULT_USER_AGENT = "casee-sdk-python/1.9.0"

# 搜索引擎枚举（deprecated，将在 v2.0 移除）
_ENGINE_INTELLIGENCE = "intelligence"
_ENGINE_ENTITIES = "entities"
_ENGINE_LATEST = "latest"
_ENGINE_FEED = "feed"
_ENGINE_SOURCE = "source"

# 向后兼容别名
ENGINE_INTELLIGENCE = _ENGINE_INTELLIGENCE
ENGINE_ENTITIES = _ENGINE_ENTITIES
ENGINE_LATEST = _ENGINE_LATEST
ENGINE_FEED = _ENGINE_FEED
ENGINE_SOURCE = _ENGINE_SOURCE

SUPPORTED_ENGINES = (
    _ENGINE_INTELLIGENCE,
    _ENGINE_ENTITIES,
    _ENGINE_LATEST,
    _ENGINE_FEED,
    _ENGINE_SOURCE,
)

# API 路径
PATH_SEARCH = "/v1/search"
PATH_SEARCHX = "/v1/searchx"
PATH_SEARCH_BATCH = "/v1/search/batch"  # [v1.9] 服务端批量检索（多组一次往返）
PATH_SEMANTIC_SEARCH = "/v1/semantic-search"
# CVC 模型与关联情报管理（v1.7 新增；``{cvc_model_id}`` 用 str.format 展开）
PATH_CVC_MODELS = "/v1/cvc/models"
PATH_CVC_MODELS_BATCH_DELETE = "/v1/cvc/models/batch-delete"
PATH_CVC_MODEL = "/v1/cvc/{cvc_model_id}"  # DELETE 删除模型
PATH_CVC_MODEL_DOCS = "/v1/cvc/{cvc_model_id}/docs"  # GET 列 / POST 关联 / DELETE 解除
# CVC 运维接口（v1.9 新增）
PATH_CVC_MODEL_STATS = "/v1/cvc/{cvc_model_id}/stats"            # GET 归集统计
PATH_CVC_MODEL_CACHE_PURGE = "/v1/cvc/{cvc_model_id}/cache/purge"  # POST 缓存重置（异步 202）
PATH_CVC_MODEL_CLEANUP_STATUS = "/v1/cvc/{cvc_model_id}/cleanup/status"  # GET 清除进度与三库对账
PATH_CVC_MODEL_REINDEX = "/v1/cvc/{cvc_model_id}/reindex"        # POST 重放归集审计重建归集库
# 全量历史情报清除（v1.9 新增）
PATH_INTELLIGENCE_PURGE = "/v1/intelligence/purge"        # POST 全量历史清除（异步 202 / dry_run 200）
PATH_INTELLIGENCE_PURGE_STATUS = "/v1/intelligence/purge/status"  # GET 清除进度与残留对账
PATH_SOURCES = "/v1/sources"
PATH_SOURCES_SEARCH = "/v1/sources/search"
PATH_STATS = "/v1/stats"
PATH_LOCATIONS = "/v1/locations"
PATH_ADVANCED_SEARCH = "/intelligence/search"  # deprecated，请使用 PATH_SEARCHX

# 语义检索模式
SEMANTIC_MODE_HYBRID = "hybrid"
SEMANTIC_MODE_SEMANTIC = "semantic"
SEMANTIC_MODE_KEYWORD = "keyword"
SUPPORTED_SEMANTIC_MODES = (SEMANTIC_MODE_HYBRID, SEMANTIC_MODE_SEMANTIC, SEMANTIC_MODE_KEYWORD)

# 默认值
DEFAULT_LIMIT = 50
DEFAULT_DAYS = 30
DEFAULT_ENGINE = _ENGINE_INTELLIGENCE
DEFAULT_MIN_TSCORE = 0.0

# 版本号
__version__ = "1.9.0"
