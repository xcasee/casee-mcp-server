"""casee_intelligence SDK 异常类型。

异常层次：
    CaseeError                    # 基类
    ├── AuthenticationError       # 401/403 鉴权失败
    ├── RateLimitError            # 429 限流
    ├── ValidationError           # 422 参数校验失败
    ├── NotFoundError             # 404 资源不存在
    ├── ServerError               # 5xx 服务端错误
    ├── TimeoutError              # 请求超时
    ├── NetworkError              # 网络层错误（连接拒绝/DNS 失败等）
    └── APIError                  # 其他 API 错误（带 status_code）
"""
from __future__ import annotations

from typing import Any, Dict, Optional


class CaseeError(Exception):
    """SDK 所有异常的基类。"""


class AuthenticationError(CaseeError):
    """鉴权失败（401 / 403）：API Key 无效或缺失。"""


class RateLimitError(CaseeError):
    """请求频率超限（429）。"""

    def __init__(self, message: str, retry_after: Optional[float] = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class ValidationError(CaseeError):
    """参数校验失败（422）：FastAPI 返回的请求体错误。"""

    def __init__(self, message: str, detail: Any = None) -> None:
        super().__init__(message)
        self.detail = detail


class NotFoundError(CaseeError):
    """资源不存在（404）。"""


class ServerError(CaseeError):
    """服务端错误（5xx）。"""

    def __init__(self, message: str, status_code: int, body: Any = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class TimeoutError(CaseeError):
    """请求超时（client-side timeout）。"""


class NetworkError(CaseeError):
    """网络层错误（连接拒绝/DNS 失败/SSL 错误等）。"""


class APIError(CaseeError):
    """其他 API 错误，附带 HTTP 状态码与原始响应体。"""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        body: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


def raise_for_status(status_code: int, body: Any, headers: Dict[str, str]) -> None:
    """根据 HTTP 状态码抛出对应的异常。

    Args:
        status_code: HTTP 响应状态码
        body: 响应体（已解析为 dict 或保持原始字符串）
        headers: 响应头（用于读取 Retry-After）
    """
    if 200 <= status_code < 300:
        return

    # 提取错误消息
    message = ""
    if isinstance(body, dict):
        message = body.get("detail") or body.get("message") or body.get("error") or str(body)
    elif isinstance(body, str):
        message = body
    else:
        message = str(body)

    if status_code in (401, 403):
        raise AuthenticationError(message or "Authentication failed: invalid API Key.")
    if status_code == 404:
        raise NotFoundError(message or "Resource not found.")
    if status_code == 422:
        raise ValidationError(message or "Validation failed.", detail=body)
    if status_code == 429:
        retry_after_raw = headers.get("retry-after") or headers.get("Retry-After")
        retry_after = float(retry_after_raw) if (retry_after_raw or "").isdigit() else None
        raise RateLimitError(message or "Rate limit exceeded.", retry_after=retry_after)
    if 500 <= status_code < 600:
        raise ServerError(message or "Server error.", status_code=status_code, body=body)

    raise APIError(message or "API error.", status_code=status_code, body=body if isinstance(body, dict) else {"raw": body})
