"""casee_intelligence SDK 类型定义。

使用 ``TypedDict`` 提供静态类型检查（runtime 零开销，无需 pydantic）。
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

try:
    from typing import TypedDict
except ImportError:  # Python 3.7 fallback
    from typing_extensions import TypedDict


class SearchMetadata(TypedDict, total=False):
    """``search_metadata`` 块：请求元信息。"""
    id: str
    status: str
    json_endpoint: str
    created_at: str
    processed_at: str
    total_time_taken: float


class SearchParameters(TypedDict, total=False):
    """``search_parameters`` 块：回显本次请求的查询参数。"""
    engine: str
    q: Optional[str]
    source_id: Optional[str]
    days: int
    time_range: Optional[str]
    start_date: Optional[str]
    end_date: Optional[str]
    cvc_model_id: Optional[str]
    category: Optional[str]
    region: Optional[str]
    language: Optional[str]
    min_tscore: float
    limit: int
    fallback: bool
    min_content_words: int


class SearchInformation(TypedDict, total=False):
    """``search_information`` 块：命中数 + 耗时 + 查询文本。"""
    total_results: int
    time_elapsed_displayed: float
    query_displayed: str


class IntelligenceItem(TypedDict, total=False):
    """单条情报条目（``organic_results`` 数组元素）。"""
    news_id: str
    title: str
    link: str
    url: str
    published_at: str
    scraped_at: str
    content: str
    summary: str
    abstract: str
    description: str
    source_id: str
    source_name: str
    source_url: str
    source_category: str
    source_region: str
    source_language: str
    tscore: float
    author: str
    image_url: str
    original_image_url: str
    categories: List[str]
    guid: str
    collected_from: str
    matched_entity: str  # engine=entities 时


class SourceInfo(TypedDict, total=False):
    """``/v1/sources`` 返回的单个信源信息。"""
    source_id: str
    name: str
    url: str
    category: str
    region: str
    language: str
    avg_tscore: float
    document_count: int
    latest_published: str


class SearchResponse(TypedDict, total=False):
    """``GET /v1/search`` 完整响应包。"""
    search_metadata: SearchMetadata
    search_parameters: SearchParameters
    search_information: SearchInformation
    organic_results: List[IntelligenceItem]
    entities: List[str]  # engine=entities 时附带


class LocationsResponse(TypedDict, total=False):
    """``GET /v1/locations`` 响应。"""
    categories: List[str]
    regions: List[str]
    languages: List[str]


class StatsResponse(TypedDict, total=False):
    """``GET /v1/stats`` 响应。"""
    total_documents: int
    by_category: Dict[str, int]


# 便捷别名
SearchParams = Dict[str, Any]
"""搜索参数 dict（key 见 :class:`SearchParameters`，外加 ``api_key``）。"""
