"""casee SDK — 访问分析接口（v1.11 新增）。

对应 ``/access/*`` 审计面端点，基于访问日志（access_logs）聚合：

- 负载总览：KPI（请求/成功/错误/限流/拒绝）+ 健康评分 + 系统资源
- 访问时序：请求量 / 错误 / 延迟按时间桶聚合（折线图用）
- 访问来源 TopN：按 ip / key / user 维度统计请求、错误与延迟
- 查询内容 TopN：最常被调用的查询串与路径
- 延迟分布：直方图 + 百分位（p50/p90/p95/p99）+ 按路由拆分
- 异常请求：错误 / 慢查询 / 限流 / 拒绝 / 零结果列表（分页）与单请求明细
- 访问日志：全量访问日志列表（分页）与筛选可选项

时间窗口统一支持 ``range``（如 ``24h`` / ``7d``）或 ``since``/``until``
（ISO8601，优先于 range）。

函数式便捷接口：
    from casee import access_overview, access_timeseries, access_sources
    from casee import access_queries, access_latency, access_anomalies
    from casee import access_anomaly_detail, access_logs, access_filters

    # 最近 24 小时负载总览与健康评分
    access_overview(api_key="sk_xxx")

    # 访问量/错误/延迟时序（5 分钟桶）
    access_timeseries(range_="24h", bucket="5m", api_key="sk_xxx")

    # 按密钥维度的来源 TopN
    access_sources(dim="key", api_key="sk_xxx")

    # 异常请求列表（慢查询）
    access_anomalies(kind="slow", api_key="sk_xxx")
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from .client import HTTPClient
from .constants import (
    PATH_ACCESS_ANOMALIES,
    PATH_ACCESS_ANOMALY_DETAIL,
    PATH_ACCESS_FILTERS,
    PATH_ACCESS_LATENCY,
    PATH_ACCESS_LOGS,
    PATH_ACCESS_OVERVIEW,
    PATH_ACCESS_QUERIES,
    PATH_ACCESS_SOURCES,
    PATH_ACCESS_TIMESERIES,
)

_RANGES = ("1h", "6h", "24h", "7d", "30d")


def _window_params(
    range_: Optional[str],
    since: Optional[str],
    until: Optional[str],
) -> Dict[str, Any]:
    params: Dict[str, Any] = {}
    if range_ and not since:
        params["range"] = range_
    if since:
        params["since"] = since
    if until:
        params["until"] = until
    return params


def access_overview(
    *,
    range_: str = "24h",
    since: Optional[str] = None,
    until: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Dict[str, Any]:
    """访问负载总览（GET /access/overview）。

    返回 KPI（请求/成功/客户端错误/服务端错误/限流/拒绝/独立 IP 与密钥）、
    成功率与错误率、延迟分位、吞吐峰值、Top 路由、零结果数、健康评分
    （``health.status`` / ``health.score`` / ``health.reasons``）与系统资源。

    - ``range_``: 统计窗口（``1h|6h|24h|7d|30d``，默认 24h）
    - ``since``/``until``: 自定义起止（ISO8601，优先于 range）
    """
    params = _window_params(range_, since, until)
    with HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        return client.get(PATH_ACCESS_OVERVIEW, params=params)


def access_timeseries(
    *,
    range_: str = "24h",
    since: Optional[str] = None,
    until: Optional[str] = None,
    bucket: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Dict[str, Any]:
    """访问量 / 错误 / 延迟时序（GET /access/timeseries）。

    返回按时间桶聚合的 requests / errors / latency 序列（折线图数据）。

    - ``bucket``: 聚合粒度（如 ``1m|5m|30m|2h``；缺省由服务端按窗口自动选择）
    """
    params = _window_params(range_, since, until)
    if bucket:
        params["bucket"] = bucket
    with HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        return client.get(PATH_ACCESS_TIMESERIES, params=params)


def access_sources(
    *,
    range_: str = "24h",
    since: Optional[str] = None,
    until: Optional[str] = None,
    dim: str = "ip",
    sort: str = "requests",
    limit: int = 20,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Dict[str, Any]:
    """访问来源 TopN（GET /access/sources）。

    按维度统计请求 / 错误 / 延迟并排序返回 TopN。

    - ``dim``: 维度 ``ip | key | user``（默认 ip）
    - ``sort``: 排序 ``requests | errors | latency``（默认 requests）
    - ``limit``: 返回条数（1-100，默认 20）
    """
    params = _window_params(range_, since, until)
    params.update({"dim": dim, "sort": sort, "limit": int(limit)})
    with HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        return client.get(PATH_ACCESS_SOURCES, params=params)


def access_queries(
    *,
    range_: str = "24h",
    since: Optional[str] = None,
    until: Optional[str] = None,
    path: Optional[str] = None,
    limit: int = 20,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Dict[str, Any]:
    """查询内容 TopN（GET /access/queries）。

    统计最常被调用的查询串（可限定路径，如 ``/v1/searchx``）。

    - ``path``: 限定请求路径
    - ``limit``: 返回条数（1-100，默认 20）
    """
    params = _window_params(range_, since, until)
    params["limit"] = int(limit)
    if path:
        params["path"] = path
    with HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        return client.get(PATH_ACCESS_QUERIES, params=params)


def access_latency(
    *,
    range_: str = "24h",
    since: Optional[str] = None,
    until: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Dict[str, Any]:
    """延迟分布（GET /access/latency）。

    返回延迟直方图、百分位（p50/p90/p95/p99/max）与按路由拆分的延迟统计。
    """
    params = _window_params(range_, since, until)
    with HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        return client.get(PATH_ACCESS_LATENCY, params=params)


def access_anomalies(
    *,
    range_: str = "24h",
    since: Optional[str] = None,
    until: Optional[str] = None,
    kind: str = "all",
    status: Optional[int] = None,
    path: Optional[str] = None,
    ip: Optional[str] = None,
    key_id: Optional[str] = None,
    q: Optional[str] = None,
    min_latency_ms: Optional[float] = None,
    page: int = 1,
    page_size: int = 50,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Dict[str, Any]:
    """异常请求追踪列表（GET /access/anomalies，分页）。

    返回错误 / 慢查询 / 限流 / 拒绝 / 零结果请求的列表与分页信息。

    - ``kind``: ``all|error|slow|rate_limited|denied|zero_result``（默认 all）
    - ``status``: 精确状态码过滤
    - ``path`` / ``ip`` / ``key_id``: 维度过滤
    - ``q``: 模糊匹配查询串 / 错误信息 / 路径
    - ``min_latency_ms``: 最低延迟（毫秒）
    - ``page`` / ``page_size``: 分页（page_size 1-200，默认 50）
    """
    params = _window_params(range_, since, until)
    params.update({"kind": kind, "page": int(page), "page_size": int(page_size)})
    if status is not None:
        params["status"] = int(status)
    for key, value in (("path", path), ("ip", ip), ("key_id", key_id), ("q", q)):
        if value:
            params[key] = value
    if min_latency_ms is not None:
        params["min_latency_ms"] = float(min_latency_ms)
    with HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        return client.get(PATH_ACCESS_ANOMALIES, params=params)


def access_anomaly_detail(
    request_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Dict[str, Any]:
    """单请求完整明细（GET /access/anomalies/{request_id}）。

    返回一个请求的全部审计字段（请求/响应/耗时/密钥/用户/IP 等）。
    ``request_id`` 不存在时服务端返回 404。

    - ``request_id``（必填）: 请求 ID（可由 :func:`access_anomalies` 取得）
    """
    with HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        return client.get(PATH_ACCESS_ANOMALY_DETAIL.format(request_id=request_id))


def access_logs(
    *,
    range_: str = "24h",
    since: Optional[str] = None,
    until: Optional[str] = None,
    status: Optional[int] = None,
    path: Optional[str] = None,
    ip: Optional[str] = None,
    key_id: Optional[str] = None,
    q: Optional[str] = None,
    min_latency_ms: Optional[float] = None,
    page: int = 1,
    page_size: int = 50,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Dict[str, Any]:
    """访问日志列表（GET /access/logs，分页）。

    返回全量访问日志（不限于异常），过滤参数与 :func:`access_anomalies` 一致。
    """
    params = _window_params(range_, since, until)
    params.update({"page": int(page), "page_size": int(page_size)})
    if status is not None:
        params["status"] = int(status)
    for key, value in (("path", path), ("ip", ip), ("key_id", key_id), ("q", q)):
        if value:
            params[key] = value
    if min_latency_ms is not None:
        params["min_latency_ms"] = float(min_latency_ms)
    with HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        return client.get(PATH_ACCESS_LOGS, params=params)


def access_filters(
    *,
    range_: str = "24h",
    since: Optional[str] = None,
    until: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Dict[str, Any]:
    """筛选可选项（GET /access/filters）。

    返回路由分组、Top IP 与 Top 密钥，用于构建 :func:`access_anomalies` /
    :func:`access_logs` 的筛选下拉。
    """
    params = _window_params(range_, since, until)
    with HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        return client.get(PATH_ACCESS_FILTERS, params=params)
