"""casee CLI 入口。

支持命令行搜索：

    # 快速检索
    casee search "AI,Nvidia" --days 30 --api-key sk_xxx

    # 高级检索
    casee searchx "+EV +(battery|charging) -China" --source-ids reuters,bloomberg --min-tscore 0.6

    # 语义检索（基于 CVC 模型）
    casee semantic cvc_9f8e7d6c "竞争对手在东南亚的电动化布局战略" --mode hybrid --top-k 20

    # 统计
    casee stats

    # 枚举过滤值
    casee locations

环境变量：
    CASEE_API_KEY            — API Key
    CASEE_API_BASE_URL       — API 基址（默认 http://121.43.113.132:8000）
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Dict, List, Optional

from . import __version__
from .exceptions import CaseeError
from .search import (
    IntelligenceSearch,
    get_locations,
    get_stats,
    search_advanced,
)
from .search import semantic_search as semantic_search_fn
from . import (  # v1.10 新增数据类家族（包顶层导出）
    cancel_task,
    create_task,
    discover_sensors,
    feed_by_id,
    feed_by_name,
    feed_stats,
    get_log,
    get_sensor,
    intel_entities,
    intel_latest,
    latest_log,
    list_logs,
    list_sensors,
    list_tasks,
    monitor_dashboard,
    monitor_run_sources,
    monitor_sources,
    monitor_trend,
    news_ai,
    news_site,
    news_upload_remote,
    panel_cache_clear,
    panel_cache_stats,
    panel_data,
    run_scheduler,
    scrape_page,
    set_sensor_status,
    source_latest,
    tasks_stats,
    trust_source,
    trust_stats,
)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="casee",
        description="CaSee Intelligence CLI — 情报检索命令行工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
子命令:
  search         快速检索（简单关键词 + 时间窗口）
  searchx        高级检索（AND/OR/NOT/短语 + 信源过滤 + tscore + 精确时间窗口）
  semantic       语义检索（基于 CVC 模型的两阶段混合检索）
  stats          情报集合统计
  locations      过滤值枚举
  feed           信源视角聚合（统计 / 按信源查询情报）
  source-latest  某信源最新一条情报
  latest         最新情报
  entities       按实体查询情报
  trust          信源信任分（tscore）：统计 / 单信源详情
  sensors        采集探针：列表 / 主动探测 / 详情 / 设置状态
  tasks          采集任务：列表 / 统计 / 详情 / 取消 / 创建
  logs           采集运行日志：列表 / 最新 / 按 run_id 查看
  monitor        采集监控：面板摘要 / 信源连通性 / 趋势 / 单次运行明细
  panel          面板数据：取数 / 缓存统计 / 清理缓存
  news           内容源：AI 新闻 / 站点新闻 / 远程上传
  scrape         抓取页面内容（经 gateway 派发到探针）
  scheduler      手动触发一轮采集

示例:
  # 快速检索
  casee search "AI,Nvidia" --days 30

  # 快速检索（预设时间范围 + 关闭回退）
  casee search "AI,Nvidia" --time-range 7d --no-fallback

  # 高级检索（查询语法）
  casee searchx "+EV +(battery|charging) -China" --source-ids reuters,bloomberg --min-tscore 0.6

  # 高级检索（高级参数 + 预设时间范围）
  casee searchx --must-keywords EV,battery --not-keywords China --time-range 3m

  # 语义检索（混合模式）
  casee semantic cvc_9f8e7d6c "竞争对手在东南亚的电动化布局战略" --mode hybrid --top-k 20

  # 统计
  casee stats

  # 枚举过滤值
  casee locations

  # 信源视角：统计 / 按信源查询近 7 天情报
  casee feed --stats
  casee feed --source-id reuters --days 7 --limit 50

  # 信源最新一条情报
  casee source-latest reuters

  # 最新情报（近 7 天，限定分类）
  casee latest --days 7 --category tech --min-tscore 0.6 --limit 30

  # 按实体查询情报
  casee entities "Nvidia,TSMC" --days 30 --limit-per-entity 10

  # 单信源信任分详情
  casee trust --source-id reuters

  # 采集探针：巡检与暂停
  casee sensors --status active
  casee sensors --set-status paused --sensor-id sensor-001

  # 采集任务：查看 / 创建 / 取消
  casee tasks --status running
  casee tasks --create --type collect_source --payload '{"source_id":"reuters"}' --priority 5
  casee tasks --cancel --task-id task_123

  # 采集运行日志
  casee logs --latest

  # 采集监控（最近 10 次运行摘要 / 趋势）
  casee monitor --dashboard --recent 10
  casee monitor --trend --limit 30

  # 面板数据（缓存统计 / 清理缓存）
  casee panel ai_market "新能源汽车,比亚迪" --days 90
  casee panel --clear-cache ai_market

  # 内容源：AI 新闻 / 远程上传
  casee news "新能源汽车" --days 7 --limit 10 --language zh

  # 抓取页面 / 手动触发采集
  casee scrape "https://example.com/a.html"
  casee scheduler

环境变量:
  CASEE_API_KEY            API Key
  CASEE_API_BASE_URL       API 基址（默认 http://121.43.113.132:8000）
  CASEE_TIMEOUT            请求超时秒数（默认 30）
""",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    subparsers = parser.add_subparsers(dest="command", help="子命令")

    # ---- search（快速检索）----
    search_p = subparsers.add_parser("search", help="快速检索：简单关键词 + 时间窗口")
    search_p.add_argument("q", type=str, nargs="?", default=None,
                          help="查询关键词（逗号分隔，OR 逻辑）")
    search_p.add_argument("--days", type=int, default=30, help="时间窗口（天），默认 30")
    search_p.add_argument("--time-range", dest="time_range", type=str, default=None,
                          help="预设时间范围：1d/7d/1m/3m（优先于 days）")
    search_p.add_argument("--start-date", dest="start_date", type=str, default=None,
                          help="起始日期 YYYY-MM-DD（优先于 time_range/days）")
    search_p.add_argument("--end-date", dest="end_date", type=str, default=None,
                          help="结束日期 YYYY-MM-DD")
    search_p.add_argument("--cvc-model-id", dest="cvc_model_id", type=str, default=None,
                          help="CVC 模型 ID（传入时检索结果异步归集到语义检索库）")
    search_p.add_argument("--category", type=str, default=None, help="信源类别过滤")
    search_p.add_argument("--region", type=str, default=None, help="信源地区过滤")
    search_p.add_argument("--language", type=str, default=None, help="信源语言过滤")
    search_p.add_argument("--min-tscore", dest="min_tscore", type=float, default=0.0,
                          help="最低 tscore（0.0-1.0）")
    search_p.add_argument("--limit", type=int, default=50, help="返回条数上限，默认 50")
    search_p.add_argument("--fallback", dest="fallback", action="store_true", default=False,
                          help="无结果时启用外部补源回退检索（[v1.8 FIX-S3] 默认关闭）")
    search_p.add_argument("--no-fallback", dest="fallback", action="store_false",
                          help="关闭外部补源回退检索")
    search_p.add_argument("--min-content-words", dest="min_content_words", type=int, default=200,
                          help="最低正文字数过滤（0=不过滤，默认 200）")
    _add_auth_args(search_p)
    _add_output_args(search_p)

    # ---- searchx（高级检索）----
    searchx_p = subparsers.add_parser("searchx", help="高级检索：AND/OR/NOT/短语 + 信源过滤 + tscore")
    searchx_p.add_argument("q", type=str, nargs="?", default=None,
                           help="查询语法字符串（类 Google 语法）")
    searchx_p.add_argument("--must-keywords", dest="must_keywords", type=str, default=None,
                           help="AND 关键词（逗号分隔）")
    searchx_p.add_argument("--should-keywords", dest="should_keywords", type=str, default=None,
                           help="OR 关键词（逗号分隔）")
    searchx_p.add_argument("--not-keywords", dest="not_keywords", type=str, default=None,
                           help="NOT 排除关键词（逗号分隔）")
    searchx_p.add_argument("--phrase-keywords", dest="phrase_keywords", type=str, default=None,
                           help="精确短语（逗号分隔）")
    searchx_p.add_argument("--keywords", type=str, default=None,
                           help="[兼容] 逗号分隔关键词（OR 逻辑）")
    searchx_p.add_argument("--days", type=int, default=30, help="时间窗口（天），默认 30")
    searchx_p.add_argument("--time-range", dest="time_range", type=str, default=None,
                           help="预设时间范围：1d/7d/1m/3m（优先于 days）")
    searchx_p.add_argument("--start-date", dest="start_date", type=str, default=None,
                           help="起始日期 YYYY-MM-DD")
    searchx_p.add_argument("--end-date", dest="end_date", type=str, default=None,
                           help="结束日期 YYYY-MM-DD")
    searchx_p.add_argument("--cvc-model-id", dest="cvc_model_id", type=str, default=None,
                           help="CVC 模型 ID（传入时检索结果异步归集到语义检索库）")
    searchx_p.add_argument("--category", type=str, default=None, help="信源类别过滤")
    searchx_p.add_argument("--region", type=str, default=None, help="信源地区过滤")
    searchx_p.add_argument("--language", type=str, default=None, help="信源语言过滤")
    searchx_p.add_argument("--source-ids", dest="source_ids", type=str, default=None,
                           help="信源 ID 列表（逗号分隔），如 reuters,bloomberg")
    searchx_p.add_argument("--min-tscore", dest="min_tscore", type=float, default=0.0,
                           help="最低 tscore（0.0-1.0）")
    searchx_p.add_argument("--limit", type=int, default=50, help="返回条数上限，默认 50")
    searchx_p.add_argument("--fallback", dest="fallback", action="store_true", default=False,
                           help="无结果时启用外部补源回退检索（[v1.8 FIX-S3] 默认关闭）")
    searchx_p.add_argument("--no-fallback", dest="fallback", action="store_false",
                           help="关闭外部补源回退检索")
    searchx_p.add_argument("--min-content-words", dest="min_content_words", type=int, default=200,
                           help="最低正文字数过滤（0=不过滤，默认 200）")
    _add_auth_args(searchx_p)
    _add_output_args(searchx_p)

    # ---- semantic（语义检索）----
    semantic_p = subparsers.add_parser(
        "semantic", help="语义检索：基于 CVC 模型的两阶段混合检索（BM25 + 向量 ANN + RRF 融合）")
    semantic_p.add_argument("cvc_model_id", type=str,
                           help="CVC 模型 ID（格式 ^cvc_[a-z0-9]{8,32}$）")
    semantic_p.add_argument("q", type=str, help="查询文本（自然语言）")
    semantic_p.add_argument("--mode", type=str, default="hybrid",
                            choices=["hybrid", "semantic", "keyword"],
                            help="检索模式：hybrid（默认）/ semantic / keyword")
    semantic_p.add_argument("--top-k", dest="top_k", type=int, default=20,
                            help="返回条数上限，默认 20")
    semantic_p.add_argument("--time-range", dest="time_range", type=str, default=None,
                            help="预设时间范围：1d/7d/1m/3m")
    semantic_p.add_argument("--days", type=int, default=None, help="自定义时间窗口（天）")
    semantic_p.add_argument("--start-date", dest="start_date", type=str, default=None,
                            help="起始日期 YYYY-MM-DD")
    semantic_p.add_argument("--end-date", dest="end_date", type=str, default=None,
                            help="结束日期 YYYY-MM-DD")
    semantic_p.add_argument("--category", type=str, default=None, help="信源类别过滤")
    semantic_p.add_argument("--region", type=str, default=None, help="信源地区过滤")
    semantic_p.add_argument("--language", type=str, default=None, help="信源语言过滤（单个，如 en/zh）")
    semantic_p.add_argument("--languages", dest="languages", type=str, default=None,
                            help="信源语言过滤（逗号分隔多个，如 en,zh）")
    semantic_p.add_argument("--source-categories", dest="source_categories", type=str, default=None,
                            help="信源类别过滤（逗号分隔多个，如 wire,tech）")
    semantic_p.add_argument("--min-tscore", dest="min_tscore", type=float, default=0.0,
                            help="最低 tscore（0.0-1.0）")
    semantic_p.add_argument("--rerank", dest="rerank", action="store_true", default=True,
                            help="启用结果重排序（默认开启）")
    semantic_p.add_argument("--no-rerank", dest="rerank", action="store_false",
                            help="关闭结果重排序")
    _add_auth_args(semantic_p)
    _add_output_args(semantic_p)

    # ---- stats ----
    stats_p = subparsers.add_parser("stats", help="情报集合统计")
    _add_auth_args(stats_p)
    _add_output_args(stats_p)

    # ---- locations ----
    locations_p = subparsers.add_parser("locations", help="过滤值枚举")
    _add_auth_args(locations_p)
    _add_output_args(locations_p)

    # ---- feed（信源视角聚合）----
    feed_p = subparsers.add_parser("feed", help="信源视角聚合：统计 / 按信源查询情报")
    feed_p.add_argument("--stats", dest="feed_stats", action="store_true",
                        help="输出信源情报统计（GET /feed/stats）")
    feed_p.add_argument("--source-id", dest="source_id", type=str, default=None,
                        help="按信源 ID 查询情报（GET /feed/by-id/{source_id}）")
    feed_p.add_argument("--source-name", dest="source_name", type=str, default=None,
                        help="按信源名称查询情报（GET /feed/{source_name}）")
    feed_p.add_argument("--days", type=int, default=None, help="时间窗口（天），配合 --source-id")
    feed_p.add_argument("--limit", type=int, default=None, help="返回条数上限")
    _add_auth_args(feed_p)
    _add_output_args(feed_p)

    # ---- source-latest（信源最新一条情报）----
    source_latest_p = subparsers.add_parser("source-latest", help="某信源最新一条情报")
    source_latest_p.add_argument("source_id", type=str, help="信源 ID")
    _add_auth_args(source_latest_p)
    _add_output_args(source_latest_p)

    # ---- latest（最新情报）----
    latest_p = subparsers.add_parser("latest", help="最新情报（GET /intelligence/latest）")
    latest_p.add_argument("--days", type=int, default=None, help="时间窗口（回溯天数）")
    latest_p.add_argument("--category", type=str, default=None, help="分类过滤")
    latest_p.add_argument("--region", type=str, default=None, help="地区过滤")
    latest_p.add_argument("--language", type=str, default=None, help="语言过滤")
    latest_p.add_argument("--min-tscore", dest="min_tscore", type=float, default=None,
                          help="最低 tscore")
    latest_p.add_argument("--limit", type=int, default=None, help="返回条数上限")
    _add_auth_args(latest_p)
    _add_output_args(latest_p)

    # ---- entities（按实体查询情报）----
    entities_p = subparsers.add_parser("entities", help="按实体查询情报（GET /intelligence/entities）")
    entities_p.add_argument("entities", type=str, help="实体列表（逗号分隔），如 Nvidia,TSMC")
    entities_p.add_argument("--days", type=int, default=None, help="时间窗口（回溯天数）")
    entities_p.add_argument("--language", type=str, default=None, help="语言过滤")
    entities_p.add_argument("--min-tscore", dest="min_tscore", type=float, default=None,
                            help="最低 tscore")
    entities_p.add_argument("--limit-per-entity", dest="limit_per_entity", type=int, default=None,
                            help="每个实体返回条数上限")
    _add_auth_args(entities_p)
    _add_output_args(entities_p)

    # ---- trust（信源信任分）----
    trust_p = subparsers.add_parser("trust", help="信源信任分（tscore）：统计 / 单信源详情")
    trust_p.add_argument("--stats", dest="trust_stats", action="store_true",
                         help="信任分分布统计（GET /trust/stats）")
    trust_p.add_argument("--source-id", dest="source_id", type=str, default=None,
                         help="单信源信任分详情（GET /trust/{source_id}）")
    _add_auth_args(trust_p)
    _add_output_args(trust_p)

    # ---- sensors（采集探针）----
    sensors_p = subparsers.add_parser("sensors", help="采集探针：列表 / 主动探测 / 详情 / 设置状态")
    sensors_p.add_argument("--discover", action="store_true",
                           help="主动探测在线探针（GET /sensors/discover，耗时较长）")
    sensors_p.add_argument("--sensor-id", dest="sensor_id", type=str, default=None,
                           help="探针 ID（详情 / 设置状态用）")
    sensors_p.add_argument("--set-status", dest="set_status", type=str, default=None,
                           choices=["active", "paused", "disabled"],
                           help="设置探针状态（需配合 --sensor-id）")
    sensors_p.add_argument("--status", type=str, default=None, help="探针状态过滤：active / paused / disabled")
    sensors_p.add_argument("--region", type=str, default=None, help="探针所属区域过滤")
    sensors_p.add_argument("--capability", type=str, default=None, help="探针能力过滤（如 rss / web）")
    sensors_p.add_argument("--tag", type=str, default=None, help="探针标签过滤")
    sensors_p.add_argument("--limit", type=int, default=None, help="返回条数上限")
    _add_auth_args(sensors_p)
    _add_output_args(sensors_p)

    # ---- tasks（采集任务）----
    tasks_p = subparsers.add_parser("tasks", help="采集任务：列表 / 统计 / 详情 / 取消 / 创建")
    tasks_p.add_argument("--stats", dest="tasks_stats", action="store_true",
                         help="任务统计摘要（GET /tasks/stats）")
    tasks_p.add_argument("--task-id", dest="task_id", type=str, default=None,
                         help="任务 ID（详情 / 取消用）")
    tasks_p.add_argument("--cancel", action="store_true", help="取消任务（需配合 --task-id）")
    tasks_p.add_argument("--create", action="store_true", help="创建采集任务（需配合 --type）")
    tasks_p.add_argument("--status", type=str, default=None, help="任务状态过滤")
    tasks_p.add_argument("--sensor-id", dest="sensor_id", type=str, default=None, help="限定执行探针")
    tasks_p.add_argument("--type", type=str, default=None,
                         help="任务类型（如 collect_source / scrape_url）")
    tasks_p.add_argument("--payload", type=str, default=None,
                         help="任务参数体（JSON 字符串），如 '{\"source_id\":\"reuters\"}'")
    tasks_p.add_argument("--priority", type=int, default=None, help="优先级（数值越大越优先）")
    tasks_p.add_argument("--limit", type=int, default=None, help="返回条数上限")
    tasks_p.add_argument("--skip", type=int, default=None, help="分页偏移")
    _add_auth_args(tasks_p)
    _add_output_args(tasks_p)

    # ---- logs（采集运行日志）----
    logs_p = subparsers.add_parser("logs", help="采集运行日志：列表 / 最新 / 按 run_id 查看")
    logs_p.add_argument("--latest", dest="latest_log", action="store_true",
                        help="最近一次运行日志（GET /logs/latest）")
    logs_p.add_argument("--run-id", dest="run_id", type=str, default=None,
                        help="按 run_id 查看单次运行日志")
    logs_p.add_argument("--limit", type=int, default=None, help="返回条数上限")
    logs_p.add_argument("--skip", type=int, default=None, help="分页偏移")
    _add_auth_args(logs_p)
    _add_output_args(logs_p)

    # ---- monitor（采集监控）----
    monitor_p = subparsers.add_parser("monitor", help="采集监控：面板摘要 / 信源连通性 / 趋势 / 单次运行明细")
    monitor_p.add_argument("--dashboard", action="store_true",
                           help="监控面板摘要（默认，GET /monitor/dashboard）")
    monitor_p.add_argument("--sources", dest="monitor_sources", action="store_true",
                           help="信源连通性历史（GET /monitor/sources）")
    monitor_p.add_argument("--trend", action="store_true", help="采集趋势时序（GET /monitor/trend）")
    monitor_p.add_argument("--run-sources", dest="monitor_run_sources", action="store_true",
                           help="单次运行逐信源明细（需配合 --run-id）")
    monitor_p.add_argument("--recent", type=int, default=None, help="纳入统计的最近 N 次运行（dashboard）")
    monitor_p.add_argument("--source-id", dest="source_id", type=str, default=None,
                           help="仅返回指定信源（sources）")
    monitor_p.add_argument("--limit", type=int, default=None, help="返回条数上限")
    monitor_p.add_argument("--run-id", dest="run_id", type=str, default=None, help="运行 ID（run-sources）")
    _add_auth_args(monitor_p)
    _add_output_args(monitor_p)

    # ---- panel（面板数据）----
    panel_p = subparsers.add_parser("panel", help="面板数据：取数 / 缓存统计 / 清理缓存")
    panel_p.add_argument("panel_id", type=str, nargs="?", default=None,
                         help="面板 ID（取数时必填）")
    panel_p.add_argument("keywords", type=str, nargs="?", default=None,
                         help="逗号分隔关键词（取数时必填），如 \"新能源汽车,比亚迪\"")
    panel_p.add_argument("--cache-stats", dest="panel_cache_stats", action="store_true",
                         help="面板缓存统计（GET /panel/cache/stats）")
    panel_p.add_argument("--clear-cache", dest="panel_cache_clear", action="store_true",
                         help="清除面板缓存（DELETE /panel/cache；给出 panel_id 仅清该面板）")
    panel_p.add_argument("--force-refresh", dest="force_refresh", action="store_true", default=None,
                         help="绕过服务端缓存强制重算（较慢）")
    panel_p.add_argument("--cvc-name", dest="cvc_name", type=str, default=None,
                         help="CVC 模型名称（用于缓存隔离）")
    panel_p.add_argument("--days", type=int, default=None, help="时间窗口（天，默认 90）")
    _add_auth_args(panel_p)
    _add_output_args(panel_p)

    # ---- news（内容源）----
    news_p = subparsers.add_parser("news", help="内容源：AI 新闻 / 站点新闻 / 远程上传")
    news_p.add_argument("keywords", type=str, nargs="?", default=None,
                        help="关键词（多个用逗号分隔）")
    news_p.add_argument("--ai", action="store_true", help="AI 生成新闻（默认，GET /news/ai）")
    news_p.add_argument("--site", type=str, default=None, help="站点定向新闻搜索（GET /news/site）")
    news_p.add_argument("--upload-remote", dest="upload_remote", type=str, default=None,
                        help="远程抓取并上传为新闻（POST /news/upload/remote）")
    news_p.add_argument("--days", type=int, default=None, help="时间范围（天）")
    news_p.add_argument("--limit", type=int, default=None, help="返回条数上限")
    news_p.add_argument("--language", type=str, default=None, help="语言代码（如 en / zh）")
    news_p.add_argument("--source-name", dest="source_name", type=str, default=None,
                        help="来源名称（--upload-remote 用）")
    _add_auth_args(news_p)
    _add_output_args(news_p)

    # ---- scrape（抓取页面）----
    scrape_p = subparsers.add_parser("scrape", help="抓取页面内容（经 gateway 派发到探针）")
    scrape_p.add_argument("url", type=str, help="目标页面地址")
    scrape_p.add_argument("--scrape-timeout", dest="scrape_timeout", type=str, default=None,
                          help="服务端抓取超时（按端点定义可选，原样透传）")
    _add_auth_args(scrape_p)
    _add_output_args(scrape_p)

    # ---- scheduler（手动触发采集）----
    scheduler_p = subparsers.add_parser("scheduler", help="手动触发一轮采集（POST /scheduler/run）")
    _add_auth_args(scheduler_p)
    _add_output_args(scheduler_p)

    return parser


def _add_auth_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--api-key", dest="api_key", type=str, default=None,
                   help="API Key（默认读 CASEE_API_KEY 环境变量）")
    p.add_argument("--base-url", dest="base_url", type=str, default=None,
                   help="API 基址（默认读 CASEE_API_BASE_URL 环境变量）")
    p.add_argument("--timeout", type=float, default=None, help="请求超时秒数")


def _add_output_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("-o", "--output", dest="output", type=str, default=None,
                   help="输出到文件（默认 stdout）")
    p.add_argument("--indent", type=int, default=2, help="JSON 缩进，默认 2")
    p.add_argument("--no-indent", dest="indent", action="store_const", const=None,
                   help="不缩进（紧凑输出）")
    p.add_argument("--links", action="store_true", help="仅输出 links（每行一个 URL）")
    p.add_argument("--ids", action="store_true", help="仅输出 news_id 列表")
    p.add_argument("--titles", action="store_true", help="仅输出标题列表")


def main(argv: Optional[List[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help(sys.stderr)
        return 2

    try:
        if args.command == "stats":
            result = get_stats(api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "locations":
            result = get_locations(api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "search":
            if not args.q:
                print("Error: search requires a query argument", file=sys.stderr)
                return 2
            params: Dict[str, Any] = {
                "engine": "intelligence",
                "q": args.q,
                "days": args.days,
                "time_range": args.time_range,
                "start_date": args.start_date,
                "end_date": args.end_date,
                "cvc_model_id": args.cvc_model_id,
                "category": args.category,
                "region": args.region,
                "language": args.language,
                "min_tscore": args.min_tscore,
                "limit": args.limit,
                "fallback": args.fallback,
                "min_content_words": args.min_content_words,
                "api_key": args.api_key,
                "api_base_url": args.base_url,
                "timeout": args.timeout,
            }
            params = {k: v for k, v in params.items() if v is not None}

            with IntelligenceSearch(params) as search:
                response = search.get_dict()
            return _format_output(response, args)

        if args.command == "searchx":
            if not any([args.q, args.must_keywords, args.should_keywords,
                        args.not_keywords, args.phrase_keywords, args.keywords]):
                print("Error: searchx requires at least one search parameter", file=sys.stderr)
                return 2

            result = search_advanced(
                q=args.q,
                must_keywords=args.must_keywords.split(",") if args.must_keywords else None,
                should_keywords=args.should_keywords.split(",") if args.should_keywords else None,
                not_keywords=args.not_keywords.split(",") if args.not_keywords else None,
                phrase_keywords=args.phrase_keywords.split(",") if args.phrase_keywords else None,
                keywords=args.keywords,
                days=args.days,
                time_range=args.time_range,
                start_date=args.start_date,
                end_date=args.end_date,
                cvc_model_id=args.cvc_model_id,
                category=args.category,
                region=args.region,
                language=args.language,
                source_ids=args.source_ids.split(",") if args.source_ids else None,
                min_tscore=args.min_tscore,
                limit=args.limit,
                fallback=args.fallback,
                min_content_words=args.min_content_words,
                api_key=args.api_key,
                base_url=args.base_url,
            )
            return _print_json(result, args)

        if args.command == "semantic":
            result = semantic_search_fn(
                cvc_model_id=args.cvc_model_id,
                q=args.q,
                mode=args.mode,
                top_k=args.top_k,
                time_range=args.time_range,
                days=args.days,
                start_date=args.start_date,
                end_date=args.end_date,
                category=args.category,
                region=args.region,
                language=args.language,
                languages=args.languages.split(",") if args.languages else None,
                source_categories=args.source_categories.split(",") if args.source_categories else None,
                min_tscore=args.min_tscore,
                rerank=args.rerank,
                api_key=args.api_key,
                base_url=args.base_url,
            )
            return _format_output(result, args)

        if args.command == "feed":
            if getattr(args, "feed_stats", False):
                result = feed_stats(api_key=args.api_key, base_url=args.base_url)
            elif args.source_id:
                result = feed_by_id(args.source_id, days=args.days, limit=args.limit,
                                    api_key=args.api_key, base_url=args.base_url)
            elif args.source_name:
                result = feed_by_name(args.source_name, limit=args.limit,
                                      api_key=args.api_key, base_url=args.base_url)
            else:
                print("Error: feed requires one of --stats / --source-id / --source-name",
                      file=sys.stderr)
                return 2
            return _print_json(result, args)

        if args.command == "source-latest":
            result = source_latest(args.source_id,
                                   api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "latest":
            result = intel_latest(days=args.days, category=args.category, region=args.region,
                                  language=args.language, min_tscore=args.min_tscore,
                                  limit=args.limit, api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "entities":
            result = intel_entities(args.entities, days=args.days, language=args.language,
                                    min_tscore=args.min_tscore,
                                    limit_per_entity=args.limit_per_entity,
                                    api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "trust":
            if getattr(args, "trust_stats", False):
                result = trust_stats(api_key=args.api_key, base_url=args.base_url)
            elif args.source_id:
                result = trust_source(args.source_id,
                                      api_key=args.api_key, base_url=args.base_url)
            else:
                print("Error: trust requires one of --stats / --source-id", file=sys.stderr)
                return 2
            return _print_json(result, args)

        if args.command == "sensors":
            if args.discover:
                result = discover_sensors(region=args.region, capability=args.capability,
                                          tag=args.tag, limit=args.limit,
                                          api_key=args.api_key, base_url=args.base_url)
            elif args.set_status is not None:
                if not args.sensor_id:
                    print("Error: sensors --set-status requires --sensor-id", file=sys.stderr)
                    return 2
                result = set_sensor_status(args.sensor_id, args.set_status,
                                           api_key=args.api_key, base_url=args.base_url)
            elif args.sensor_id:
                result = get_sensor(args.sensor_id,
                                    api_key=args.api_key, base_url=args.base_url)
            else:
                result = list_sensors(status=args.status, region=args.region,
                                      capability=args.capability, tag=args.tag,
                                      limit=args.limit,
                                      api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "tasks":
            if args.create:
                if not args.type:
                    print("Error: tasks --create requires --type", file=sys.stderr)
                    return 2
                payload = None
                if args.payload is not None:
                    try:
                        payload = json.loads(args.payload)
                    except json.JSONDecodeError as exc:
                        print(f"Error: --payload is not valid JSON: {exc}", file=sys.stderr)
                        return 2
                result = create_task(args.type, payload=payload, priority=args.priority,
                                     api_key=args.api_key, base_url=args.base_url)
            elif args.cancel:
                if not args.task_id:
                    print("Error: tasks --cancel requires --task-id", file=sys.stderr)
                    return 2
                result = cancel_task(args.task_id,
                                     api_key=args.api_key, base_url=args.base_url)
            elif getattr(args, "tasks_stats", False):
                result = tasks_stats(api_key=args.api_key, base_url=args.base_url)
            elif args.task_id:
                result = get_task(args.task_id,
                                  api_key=args.api_key, base_url=args.base_url)
            else:
                result = list_tasks(status=args.status, sensor_id=args.sensor_id,
                                    type=args.type, limit=args.limit, skip=args.skip,
                                    api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "logs":
            if getattr(args, "latest_log", False):
                result = latest_log(api_key=args.api_key, base_url=args.base_url)
            elif args.run_id:
                result = get_log(args.run_id,
                                 api_key=args.api_key, base_url=args.base_url)
            else:
                result = list_logs(limit=args.limit, skip=args.skip,
                                   api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "monitor":
            if getattr(args, "monitor_sources", False):
                result = monitor_sources(source_id=args.source_id, limit=args.limit,
                                         api_key=args.api_key, base_url=args.base_url)
            elif getattr(args, "monitor_trend", False):
                result = monitor_trend(limit=args.limit,
                                       api_key=args.api_key, base_url=args.base_url)
            elif getattr(args, "monitor_run_sources", False):
                if not args.run_id:
                    print("Error: monitor --run-sources requires --run-id", file=sys.stderr)
                    return 2
                result = monitor_run_sources(args.run_id,
                                             api_key=args.api_key, base_url=args.base_url)
            else:
                result = monitor_dashboard(recent=args.recent,
                                           api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "panel":
            if getattr(args, "panel_cache_stats", False):
                result = panel_cache_stats(api_key=args.api_key, base_url=args.base_url)
            elif getattr(args, "panel_cache_clear", False):
                result = panel_cache_clear(panel_id=args.panel_id,
                                           api_key=args.api_key, base_url=args.base_url)
            else:
                if not args.panel_id or not args.keywords:
                    print("Error: panel requires <panel_id> and <keywords>", file=sys.stderr)
                    return 2
                result = panel_data(args.panel_id, args.keywords, cvc_name=args.cvc_name,
                                    days=args.days, force_refresh=args.force_refresh,
                                    api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "news":
            if args.upload_remote:
                result = news_upload_remote(args.upload_remote, source_name=args.source_name,
                                            api_key=args.api_key, base_url=args.base_url)
            elif args.site:
                result = news_site(args.site, keywords=args.keywords, days=args.days,
                                   limit=args.limit, language=args.language,
                                   api_key=args.api_key, base_url=args.base_url)
            else:
                if not args.keywords:
                    print("Error: news requires <keywords>", file=sys.stderr)
                    return 2
                result = news_ai(args.keywords, days=args.days, limit=args.limit,
                                 language=args.language,
                                 api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "scrape":
            result = scrape_page(args.url, timeout=args.scrape_timeout,
                                 api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        if args.command == "scheduler":
            result = run_scheduler(api_key=args.api_key, base_url=args.base_url)
            return _print_json(result, args)

        return 0

    except CaseeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


def _format_output(response: Dict[str, Any], args: argparse.Namespace) -> int:
    """格式化输出（支持 --links / --ids / --titles 等特殊格式）。"""
    if args.links:
        items = response.get("organic_results", [])
        for item in items:
            link = item.get("link") or item.get("url") or ""
            if link:
                print(link)
        return 0

    if args.ids:
        items = response.get("organic_results", [])
        for item in items:
            print(item.get("news_id", ""))
        return 0

    if args.titles:
        items = response.get("organic_results", [])
        for item in items:
            print(item.get("title", ""))
        return 0

    return _print_json(response, args)


def _print_json(data: Any, args: argparse.Namespace) -> int:
    """输出 JSON 到 stdout 或文件。"""
    text = json.dumps(data, indent=args.indent, ensure_ascii=False, default=str)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"Written to {args.output}", file=sys.stderr)
    else:
        print(text)

    return 0


if __name__ == "__main__":
    sys.exit(main())
