"""casee SDK — intelligence 家族端点（v1.10 新增覆盖）。

对应 ``/intelligence/*`` 端点家族：

- 最新情报：``GET /intelligence/latest``
- 按实体查询：``GET /intelligence/entities``
- 图片本地化：``POST /intelligence/localize-images``（无请求体，limit 走 query）
- 情报统计：``GET /intelligence/stats``

函数式便捷接口：
    from casee.intel import intel_latest, intel_entities, intel_localize_images

    # 最新情报（近 7 天，限定分类与地区）
    latest = intel_latest(days=7, category="tech", region="us", api_key="sk_xxx")

    # 按实体查询（逗号分隔字符串或 list 均可）
    rows = intel_entities(["Nvidia", "TSMC"], days=30, api_key="sk_xxx")

    # 图片本地化（POST，limit 走 query 参数）
    resp = intel_localize_images(limit=50, api_key="sk_xxx")
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .client import HTTPClient
from .constants import (
    PATH_INTEL_ENTITIES,
    PATH_INTEL_LATEST,
    PATH_INTEL_LOCALIZE_IMAGES,
    PATH_INTEL_STATS,
)


def intel_latest(
    *,
    days: Optional[int] = None,
    category: Optional[str] = None,
    region: Optional[str] = None,
    language: Optional[str] = None,
    min_tscore: Optional[float] = None,
    limit: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """最新情报（GET /intelligence/latest）。

    - ``days``: 时间窗口（回溯天数）
    - ``category``: 分类过滤
    - ``region``: 地区过滤
    - ``language``: 语言过滤
    - ``min_tscore``: 最低 tscore 过滤
    - ``limit``: 返回条数上限
    """
    params: Dict[str, Any] = {}
    if days is not None:
        params["days"] = int(days)
    if category is not None:
        params["category"] = category
    if region is not None:
        params["region"] = region
    if language is not None:
        params["language"] = language
    if min_tscore is not None:
        params["min_tscore"] = float(min_tscore)
    if limit is not None:
        params["limit"] = int(limit)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_INTEL_LATEST, params=params)


def intel_entities(
    entities: str | List[str],
    *,
    days: Optional[int] = None,
    language: Optional[str] = None,
    min_tscore: Optional[float] = None,
    limit_per_entity: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """按实体查询情报（GET /intelligence/entities）。

    - ``entities``: 实体，支持 list 或逗号分隔字符串（list 会 join 为逗号分隔）
    - ``days``: 时间窗口（回溯天数）
    - ``language``: 语言过滤
    - ``min_tscore``: 最低 tscore 过滤
    - ``limit_per_entity``: 每个实体返回条数上限
    """
    if isinstance(entities, (list, tuple)):
        entities = ",".join(str(x) for x in entities)
    params: Dict[str, Any] = {"entities": entities}
    if days is not None:
        params["days"] = int(days)
    if language is not None:
        params["language"] = language
    if min_tscore is not None:
        params["min_tscore"] = float(min_tscore)
    if limit_per_entity is not None:
        params["limit_per_entity"] = int(limit_per_entity)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_INTEL_ENTITIES, params=params)


def intel_localize_images(
    *,
    limit: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """情报图片本地化（POST /intelligence/localize-images）。

    无请求体，``limit`` 作为 query 参数传递：触发待本地化图片的处理，把外链
    图片抓取落盘为本地资源。

    - ``limit``: 本次处理条数上限（query 参数）
    """
    params: Dict[str, Any] = {}
    if limit is not None:
        params["limit"] = int(limit)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_INTEL_LOCALIZE_IMAGES, params=params)


def intel_stats(
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """情报统计（GET /intelligence/stats）。

    Note:
        与 ``/v1/stats``（``PATH_STATS``）同源同缓存，返回结构一致。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_INTEL_STATS)
