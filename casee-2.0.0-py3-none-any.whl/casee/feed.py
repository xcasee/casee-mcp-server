"""casee SDK — 信源视角聚合接口（v1.10 新增覆盖）。

对应 ``/feed/*`` 与 ``/source/*`` 端点，以"信源"为主视角聚合情报：

- 信源情报统计：``GET /feed/stats``
- 按信源查询情报：``GET /feed/by-id/{source_id}`` / ``GET /feed/{source_name}``
- 信源最新一条情报：``GET /source/{source_id}/latest``

函数式便捷接口：
    from casee.feed import feed_by_id, source_latest

    # 按信源 ID 查询近 7 天情报
    docs = feed_by_id("reuters", days=7, limit=50, api_key="sk_xxx")

    # 某信源最新一条情报
    latest = source_latest("reuters", api_key="sk_xxx")
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from .client import HTTPClient
from .constants import (
    PATH_FEED_BY_ID,
    PATH_FEED_BY_NAME,
    PATH_FEED_STATS,
    PATH_SOURCE_LATEST,
)


def feed_stats(
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """信源情报统计（GET /feed/stats）。

    返回 ``{"total_documents": int, "by_category": {...}}``：情报总量与按分类
    维度的分布。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_FEED_STATS)


def feed_by_id(
    source_id: str,
    *,
    days: Optional[int] = None,
    limit: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """按信源 ID + 时间窗口查询情报（GET /feed/by-id/{source_id}）。

    - ``source_id``: 信源 ID（必填）
    - ``days``: 时间窗口（回溯天数）
    - ``limit``: 返回条数上限
    """
    params: Dict[str, Any] = {}
    if days is not None:
        params["days"] = int(days)
    if limit is not None:
        params["limit"] = int(limit)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_FEED_BY_ID.format(source_id=source_id), params=params)


def feed_by_name(
    source_name: str,
    *,
    limit: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """按信源名称查询情报（GET /feed/{source_name}）。

    - ``source_name``: 信源名称（必填）
    - ``limit``: 返回条数上限
    """
    params: Dict[str, Any] = {}
    if limit is not None:
        params["limit"] = int(limit)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_FEED_BY_NAME.format(source_name=source_name), params=params)


def source_latest(
    source_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """某信源最新一条情报（GET /source/{source_id}/latest）。

    - ``source_id``: 信源 ID（必填）
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_SOURCE_LATEST.format(source_id=source_id))
