"""casee SDK — 内容源接口：AI 新闻 / 站点新闻 / 上传（v1.10 新增）。

对应 ``/news/*`` 端点。``news_ai`` 外，其余端点会经
is_server → gateway **派发到采集探针执行**，延迟取决于探针在线与网络情况，
**延迟可能较高**，必要时请增大客户端超时（``timeout``）。

- ``news_ai``: DeepSeek + DSPy 生成的 AI 新闻
- ``news_site``: 站点定向新闻搜索
- ``news_upload`` / ``news_upload_remote``: 上传新闻稿件 / 远程抓取并上传

函数式便捷接口：
    from casee import news_ai, news_site
    from casee import news_upload, news_upload_remote

    news_ai("新能源汽车", days=7, limit=10, language="zh", api_key="sk_xxx")
    news_site("reuters.com", keywords="EV", days=7, api_key="sk_xxx")

    news_upload("正文内容", "标题", source_url="https://...", tags=["EV"], api_key="sk_xxx")
    news_upload_remote("https://example.com/news/1", source_name="示例", api_key="sk_xxx")
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .client import HTTPClient
from .constants import (
    PATH_NEWS_AI,
    PATH_NEWS_SITE,
    PATH_NEWS_UPLOAD,
    PATH_NEWS_UPLOAD_REMOTE,
)


def news_ai(
    keywords: str,
    *,
    days: Optional[int] = None,
    limit: Optional[int] = None,
    language: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """AI 生成新闻（GET /news/ai）。

    DeepSeek + DSPy 生成，探针执行后同步写入 MongoDB，响应原样回传。**延迟可能较高**。

    - ``keywords``（必填）: 关键词（多个用逗号分隔）
    - ``days``: 时间范围（天，服务端范围 1-90，默认 7；映射为 sensor 的 window）
    - ``limit``: 返回条数上限（服务端范围 1-50，默认 10）
    - ``language``: 语言代码（如 ``en`` / ``zh`` / ``ja``，默认 ``en``）
    """
    params: Dict[str, Any] = {"keywords": keywords}
    if days is not None:
        params["days"] = int(days)
    if limit is not None:
        params["limit"] = int(limit)
    if language is not None:
        params["language"] = language
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_NEWS_AI, params=params)


def news_site(
    site: str,
    *,
    keywords: Optional[str] = None,
    days: Optional[int] = None,
    limit: Optional[int] = None,
    language: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """站点定向新闻搜索（GET /news/site）。

    经 gateway 派发到具备 ``news/site`` 能力的探针，**延迟可能较高**。
    服务端会把 ``site`` 映射为 sensor 的 ``sites``。

    - ``site``（必填）: 站点域名或 URL（多个用逗号分隔）
    - ``keywords``: 关键词（多个用逗号分隔），省略则返回站点所有要闻
    - ``days``: 时间范围（天，服务端范围 1-90，默认 7）
    - ``limit``: 返回条数上限（服务端范围 1-50，默认 10）
    - ``language``: 语言代码（默认 ``en``）
    """
    params: Dict[str, Any] = {"site": site}
    if keywords is not None:
        params["keywords"] = keywords
    if days is not None:
        params["days"] = int(days)
    if limit is not None:
        params["limit"] = int(limit)
    if language is not None:
        params["language"] = language
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_NEWS_SITE, params=params)


def news_upload(
    content: str,
    title: str,
    *,
    source_url: Optional[str] = None,
    source_name: Optional[str] = None,
    image_url: Optional[str] = None,
    published_at: Optional[str] = None,
    tags: Optional[List[str]] = None,
    keywords: Optional[List[str]] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """上传新闻稿件（POST /news/upload）。

    经 gateway 派发到具备 ``news/upload`` 能力的探针，探针将内容写入 MongoDB，
    **延迟可能较高**。请求体**仅写入调用方显式传入的字段**（未传的项不下发）。

    - ``content``（必填）: 正文内容
    - ``title``（必填）: 标题
    - ``source_url``: 原始来源 URL
    - ``source_name``: 来源名称
    - ``image_url``: 图片 URL
    - ``published_at``: 发布时间（ISO 格式字符串）
    - ``tags``: 标签列表
    - ``keywords``: 关键词列表
    """
    payload: Dict[str, Any] = {"content": content, "title": title}
    if source_url is not None:
        payload["source_url"] = source_url
    if source_name is not None:
        payload["source_name"] = source_name
    if image_url is not None:
        payload["image_url"] = image_url
    if published_at is not None:
        payload["published_at"] = published_at
    if tags is not None:
        payload["tags"] = tags
    if keywords is not None:
        payload["keywords"] = keywords
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_NEWS_UPLOAD, json_data=payload)


def news_upload_remote(
    url: str,
    *,
    source_name: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """远程抓取页面并上传为新闻（POST /news/upload/remote）。

    经 gateway 派发到探针，探针抓取页面内容后写入 MongoDB，**延迟可能较高**。
    本接口**无请求体**，``url`` / ``source_name`` 均作为 query 参数下发。

    - ``url``（必填）: 远程页面 URL
    - ``source_name``: 来源名称
    """
    params: Dict[str, Any] = {"url": url}
    if source_name is not None:
        params["source_name"] = source_name
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_NEWS_UPLOAD_REMOTE, params=params)
