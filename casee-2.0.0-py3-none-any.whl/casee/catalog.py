"""casee SDK — 采集探针接口（v1.10 新增）。

对应采集探针 ``/sensors*`` 管理端点，支持：

- 采集探针：列表过滤 / 主动探测在线探针 / 按 id 查看 / 设置探针状态

函数式便捷接口：
    from casee import list_sensors, discover_sensors, set_sensor_status

    # 探针巡检：列出探针并主动探测在线情况
    list_sensors(status="active", api_key="sk_xxx")
    discover_sensors(region="cn", capability="rss", api_key="sk_xxx")

    # 暂停某探针
    set_sensor_status("sensor-001", "paused", api_key="sk_xxx")
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from .client import HTTPClient
from .constants import (
    PATH_SENSOR,
    PATH_SENSOR_STATUS,
    PATH_SENSORS,
    PATH_SENSORS_DISCOVER,
)
from .exceptions import ValidationError

# 探针合法状态值（set_sensor_status 校验用）
_SENSOR_STATUSES = ("active", "paused", "disabled")


def list_sensors(
    *,
    status: Optional[str] = None,
    region: Optional[str] = None,
    capability: Optional[str] = None,
    tag: Optional[str] = None,
    limit: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """列出采集探针（GET /sensors）。

    返回已注册的采集探针节点列表，支持按状态 / 区域 / 能力 / 标签过滤：

    - ``status``: 探针状态（``active`` / ``paused`` / ``disabled``）
    - ``region``: 探针所属区域
    - ``capability``: 探针能力（如 ``rss`` / ``web``）
    - ``tag``: 探针标签
    - ``limit``: 每页条数
    """
    params: Dict[str, Any] = {}
    if status is not None:
        params["status"] = status
    if region is not None:
        params["region"] = region
    if capability is not None:
        params["capability"] = capability
    if tag is not None:
        params["tag"] = tag
    if limit is not None:
        params["limit"] = int(limit)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_SENSORS, params=params)


def discover_sensors(
    *,
    region: Optional[str] = None,
    capability: Optional[str] = None,
    tag: Optional[str] = None,
    limit: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """主动探测在线采集探针（GET /sensors/discover）。

    会主动向探针发起探测以判定在线情况，**耗时较长**（需等待各探针响应），
    请在高频调用场景谨慎使用、必要时增大客户端超时。

    - ``region`` / ``capability`` / ``tag``: 限定探测范围
    - ``limit``: 返回条数上限
    """
    params: Dict[str, Any] = {}
    if region is not None:
        params["region"] = region
    if capability is not None:
        params["capability"] = capability
    if tag is not None:
        params["tag"] = tag
    if limit is not None:
        params["limit"] = int(limit)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_SENSORS_DISCOVER, params=params)


def get_sensor(
    sensor_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """查看单个采集探针详情（GET /sensors/{sensor_id}）。

    按 ``sensor_id`` 返回该探针的注册信息、能力与当前运行状态。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_SENSOR.format(sensor_id=sensor_id))


def set_sensor_status(
    sensor_id: str,
    status: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """设置采集探针状态（POST /sensors/{sensor_id}/status）。

    - ``sensor_id``: 目标探针 id
    - ``status``: 目标状态，合法值为 ``active`` / ``paused`` / ``disabled``，
      其它值抛出 :class:`~casee.exceptions.ValidationError`

    ``paused`` 暂停调度但保留注册；``disabled`` 停用探针。
    """
    if status not in _SENSOR_STATUSES:
        raise ValidationError(
            f"status must be one of {_SENSOR_STATUSES}, got: {status!r}"
        )
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(
            PATH_SENSOR_STATUS.format(sensor_id=sensor_id),
            json_data={"status": status},
        )
