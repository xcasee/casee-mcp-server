"""casee SDK — 采集运行日志接口（v1.10 新增）。

对应 ``/logs*`` 端点，查询采集运行（run）产生的执行日志：

- 最新一次运行日志 / 运行日志列表 / 按 run_id 查看单次运行日志

函数式便捷接口：
    from casee import latest_log, list_logs, get_log

    # 查看最近一次运行日志
    latest_log(api_key="sk_xxx")

    # 分页查看历史运行日志
    runs = list_logs(limit=20, api_key="sk_xxx")

    # 查看某次运行（run_id）的完整日志
    get_log(runs["logs"][0]["run_id"], api_key="sk_xxx")
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from .client import HTTPClient
from .constants import PATH_LOG, PATH_LOGS_LATEST, PATH_LOGS_LIST


def latest_log(
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """获取最近一次采集运行日志（GET /logs/latest）。

    返回最近一次采集运行（run）的日志内容与摘要，便于快速排查最新一轮采集情况。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_LOGS_LATEST)


def list_logs(
    *,
    limit: Optional[int] = None,
    skip: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """分页列出采集运行日志（GET /logs/list）。

    - ``limit`` / ``skip``: 分页（每页条数 / 跳过条数）
    """
    params: Dict[str, Any] = {}
    if limit is not None:
        params["limit"] = int(limit)
    if skip is not None:
        params["skip"] = int(skip)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_LOGS_LIST, params=params)


def get_log(
    run_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """查看单次采集运行日志（GET /logs/{run_id}）。

    按 ``run_id`` 返回该次运行的完整日志明细（可用 :func:`list_logs` 取得 run_id）。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_LOG.format(run_id=run_id))
