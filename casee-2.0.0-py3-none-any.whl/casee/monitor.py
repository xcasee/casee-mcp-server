"""casee SDK — 采集监控聚合接口（v1.10 新增）。

对应 ``/monitor/*`` 端点，直查 run_logs 聚合查询，用于观察采集运行的成败与趋势：

- 监控面板摘要：跨运行聚合统计（成功率 / 总条数 / 平均耗时 / 逐次摘要）
- 信源连通性历史：跨运行聚合每个信源的成功 / 失败次数 + 最近错误
- 采集趋势时序：每次运行的成 / 败信源数 + 总条数（折线图用）
- 单次运行逐信源明细：某次运行各信源的连接结果

函数式便捷接口：
    from casee import monitor_dashboard, monitor_sources, monitor_trend
    from casee import monitor_run_sources

    # 最近 10 次运行的聚合摘要
    monitor_dashboard(recent=10, api_key="sk_xxx")

    # 各信源成功 / 失败次数与最近错误
    monitor_sources(limit=50, api_key="sk_xxx")

    # 采集趋势时序（折线图数据）
    monitor_trend(limit=30, api_key="sk_xxx")

    # 某次运行（run_id）的逐信源明细
    monitor_run_sources("run_20261001_0800", api_key="sk_xxx")
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from .client import HTTPClient
from .constants import (
    PATH_MONITOR_DASHBOARD,
    PATH_MONITOR_RUN_SOURCES,
    PATH_MONITOR_SOURCES,
    PATH_MONITOR_TREND,
)


def monitor_dashboard(
    *,
    recent: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """监控面板摘要（GET /monitor/dashboard）。

    跨运行聚合统计：成功率、总条数、平均耗时与逐次摘要，便于快速掌握最近采集情况。

    - ``recent``: 纳入统计的最近 N 次运行（服务端默认 10，范围 1-50）
    """
    params: Dict[str, Any] = {}
    if recent is not None:
        params["recent"] = int(recent)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_MONITOR_DASHBOARD, params=params)


def monitor_sources(
    *,
    source_id: Optional[str] = None,
    limit: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """信源连通性历史（GET /monitor/sources）。

    跨运行聚合每个信源的成功 / 失败次数 + 最近错误，返回
    ``{"count": int, "sources": [...]}``。

    - ``source_id``: 仅返回指定信源
    - ``limit``: 返回信源数上限（服务端默认 50，范围 1-500）
    """
    params: Dict[str, Any] = {}
    if source_id is not None:
        params["source_id"] = source_id
    if limit is not None:
        params["limit"] = int(limit)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_MONITOR_SOURCES, params=params)


def monitor_trend(
    *,
    limit: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """采集趋势时序（GET /monitor/trend）。

    返回每次运行的成 / 败信源数 + 总条数（时序图用），
    ``{"count": int, "trend": [...]}``。

    - ``limit``: 最近 N 次运行（服务端默认 30，范围 1-100）
    """
    params: Dict[str, Any] = {}
    if limit is not None:
        params["limit"] = int(limit)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_MONITOR_TREND, params=params)


def monitor_run_sources(
    run_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """某次运行的逐信源明细（GET /monitor/runs/{run_id}/sources）。

    返回单次运行中各信源的连接结果：成功 / 失败 + 条数 + 错误。
    ``run_id`` 不存在时服务端返回 404。

    - ``run_id``（必填）: 采集运行 ID（可由 :func:`monitor_trend` 或
      :func:`casee.list_logs` 取得）
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_MONITOR_RUN_SOURCES.format(run_id=run_id))
