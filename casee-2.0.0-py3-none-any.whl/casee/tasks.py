"""casee SDK — 采集任务管理接口（v1.10 新增）。

对应 ``/tasks*`` 管理端点，支持：

- 任务列表过滤 / 查看任务详情
- 创建采集任务（采集信源 / 抓取指定 URL 等）
- 任务统计摘要 / 取消任务

函数式便捷接口：
    from casee import list_tasks, create_task, tasks_stats, get_task, cancel_task

    # 查看进行中的任务
    list_tasks(status="running", api_key="sk_xxx")

    # 提交采集任务（type 常见取值：collect_source / scrape_url）
    task = create_task("collect_source", payload={"source_id": "src-001"},
                       name="补采", priority=5, api_key="sk_xxx")

    # 查看统计、查询与取消
    tasks_stats(api_key="sk_xxx")
    get_task(task["task_id"], api_key="sk_xxx")
    cancel_task(task["task_id"], api_key="sk_xxx")
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from .client import HTTPClient
from .constants import (
    PATH_TASK,
    PATH_TASK_CANCEL,
    PATH_TASKS,
    PATH_TASKS_STATS,
)


def list_tasks(
    *,
    status: Optional[str] = None,
    sensor_id: Optional[str] = None,
    type: Optional[str] = None,
    limit: Optional[int] = None,
    skip: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """列出采集任务（GET /tasks）。

    支持按状态 / 探针 / 任务类型过滤与分页：

    - ``status``: 任务状态（如 ``pending`` / ``running`` / ``completed`` / ``failed``）
    - ``sensor_id``: 限定执行探针
    - ``type``: 任务类型（如 ``collect_source`` / ``scrape_url``）
    - ``limit`` / ``skip``: 分页（每页条数 / 跳过条数）
    """
    params: Dict[str, Any] = {}
    if status is not None:
        params["status"] = status
    if sensor_id is not None:
        params["sensor_id"] = sensor_id
    if type is not None:
        params["type"] = type
    if limit is not None:
        params["limit"] = int(limit)
    if skip is not None:
        params["skip"] = int(skip)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_TASKS, params=params)


def create_task(
    type: str,
    *,
    payload: Optional[Dict[str, Any]] = None,
    priority: Optional[int] = None,
    name: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    target_sensor_id: Optional[str] = None,
    max_retries: Optional[int] = None,
    timeout_seconds: Optional[int] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """创建采集任务（POST /tasks）。

    请求体**仅写入调用方显式传入的字段**（未传的项不下发给服务端，由服务端取默认值）。

    - ``type``（必填）: 任务类型，常见取值 ``collect_source``（按信源采集）、
      ``scrape_url``（抓取指定 URL）
    - ``payload``: 任务参数体（如 ``{"source_id": "..."}`` / ``{"url": "..."}``）
    - ``priority``: 优先级（数值越大越优先）
    - ``name``: 任务名称（便于检索）
    - ``metadata``: 自定义元数据
    - ``target_sensor_id``: 指定执行探针
    - ``max_retries``: 最大重试次数
    - ``timeout_seconds``: 单次执行超时（秒）
    """
    body: Dict[str, Any] = {"type": type}
    if payload is not None:
        body["payload"] = payload
    if priority is not None:
        body["priority"] = int(priority)
    if name is not None:
        body["name"] = name
    if metadata is not None:
        body["metadata"] = metadata
    if target_sensor_id is not None:
        body["target_sensor_id"] = target_sensor_id
    if max_retries is not None:
        body["max_retries"] = int(max_retries)
    if timeout_seconds is not None:
        body["timeout_seconds"] = int(timeout_seconds)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_TASKS, json_data=body)


def tasks_stats(
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """采集任务统计摘要（GET /tasks/stats）。

    返回各状态任务数量、类型分布 / 成功率等汇总指标，供运维观察任务积压情况。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_TASKS_STATS)


def get_task(
    task_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """查看单个采集任务详情（GET /tasks/{task_id}）。

    按 ``task_id`` 返回任务状态、参数体、执行结果 / 错误信息等。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_TASK.format(task_id=task_id))


def cancel_task(
    task_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """取消采集任务（POST /tasks/{task_id}/cancel）。

    取消指定 ``task_id`` 的待执行 / 执行中任务。无请求体。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_TASK_CANCEL.format(task_id=task_id))
