"""casee SDK — 面板数据接口（v1.10 新增）。

对应 ``/panel/*`` 端点，基于 is_server 情报检索结果经启发式统计生成面板展示数据
（图表类型由 ``panel_id`` 推断），并带服务端缓存（缓存 key 含
panel_id / keywords / cvc_name / 数据源指纹，TTL 24 小时）：

- ``panel_data`` / ``panel_data_post``：取单个面板数据。GET 与 POST 是**等价的两种
  入参方式**，POST 支持更复杂的组合条件（``must_keywords`` AND + ``should_keywords`` OR
  + ``sources`` 信源过滤）
- ``panel_batch`` / ``panel_batch_post``：一次取多个面板
- ``panel_cache_stats`` / ``panel_cache_clear``：查看 / 清除面板缓存

函数式便捷接口：
    from casee import panel_data, panel_data_post, panel_batch, panel_batch_post
    from casee import panel_cache_stats, panel_cache_clear

    # GET：逗号分隔关键词，简单直接
    panel_data("ai_market", keywords="AI,芯片", days=90, api_key="sk_xxx")

    # POST：更复杂的组合条件（must=AND / should=OR）
    panel_data_post(
        "ai_market",
        keywords=["AI", "芯片"],
        must_keywords=["Nvidia"],
        should_keywords=["GPU", "算力"],
        api_key="sk_xxx",
    )

    # 批量取多个面板（panel_ids 支持列表或逗号分隔字符串）
    panel_batch(["ai_market", "ev_market"], keywords="AI", api_key="sk_xxx")
    panel_batch_post([{"panel_id": "ai_market", "keywords": ["AI"]}], api_key="sk_xxx")

    # 缓存查看 / 清除
    panel_cache_stats(api_key="sk_xxx")
    panel_cache_clear(panel_id="ai_market", api_key="sk_xxx")
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .client import HTTPClient
from .constants import (
    PATH_PANEL_BATCH,
    PATH_PANEL_CACHE,
    PATH_PANEL_CACHE_STATS,
    PATH_PANEL_DATA,
)
from .exceptions import ValidationError


def _split_list(value: Any) -> List[str]:
    """把逗号分隔字符串 / 列表统一为清洗后的非空字符串列表。"""
    if isinstance(value, str):
        return [v.strip() for v in value.split(",") if v.strip()]
    if isinstance(value, (list, tuple)):
        return [str(v).strip() for v in value if str(v).strip()]
    return [str(value).strip()] if str(value).strip() else []


def panel_data(
    panel_id: str,
    keywords: str,
    *,
    cvc_name: Optional[str] = None,
    days: Optional[int] = None,
    force_refresh: Optional[bool] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """获取单个面板数据（GET /panel/data）。

    基于关键词从 is_server 检索情报数据并生成面板展示数据。缓存 key =
    md5(panel_id + keywords + cvc_name + 数据源指纹)，命中时响应带 ``_cached=True``。

    等价于 :func:`panel_data_post` 的简化入参方式（简单 OR 关键词场景用本接口即可）。

    - ``panel_id``（必填）: 面板 ID，决定启发式推断的图表类型
    - ``keywords``（必填）: 逗号分隔的关键词列表（OR 逻辑），如 ``"新能源汽车,比亚迪"``
    - ``cvc_name``: CVC 模型名称（用于缓存隔离）
    - ``days``: 时间窗口（天，服务端范围 1-365，默认 90）
    - ``force_refresh``: ``True`` 时绕过服务端缓存强制重算（**较慢**）
    """
    if not keywords:
        raise ValidationError("keywords must be a non-empty comma-separated string.")
    params: Dict[str, Any] = {"panel_id": panel_id, "keywords": keywords}
    if cvc_name is not None:
        params["cvc_name"] = cvc_name
    if days is not None:
        params["days"] = int(days)
    if force_refresh is not None:
        params["force_refresh"] = bool(force_refresh)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_PANEL_DATA, params=params)


def panel_data_post(
    panel_id: str,
    *,
    keywords: Optional[Any] = None,
    must_keywords: Optional[Any] = None,
    should_keywords: Optional[Any] = None,
    cvc_id: Optional[str] = None,
    cvc_name: Optional[str] = None,
    sources: Optional[Any] = None,
    time_window_days: Optional[int] = None,
    limit: Optional[int] = None,
    force_refresh: Optional[bool] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """获取单个面板数据（POST /panel/data，支持复杂入参）。

    与 :func:`panel_data`（GET）**等价**，但请求体支持更复杂的组合条件：

    - ``keywords``: OR 逻辑关键词
    - ``must_keywords``（AND）+ ``should_keywords``（OR）: 二者任一非空时优先走高级检索模式
    - ``sources``: 信源过滤列表（直接下发，通常为信源对象列表）

    请求体**仅写入调用方显式传入的字段**（未传的项不下发给服务端，由服务端取默认值）。
    ``keywords`` / ``must_keywords`` / ``should_keywords`` 既接受字符串列表，也接受
    逗号分隔字符串（与 GET 用法一致，SDK 会拆分为列表）。

    - ``panel_id``（必填）: 面板 ID
    - ``cvc_id`` / ``cvc_name``: CVC 模型标识（用于检索与缓存隔离）
    - ``time_window_days``: 时间窗口（天，默认 90）
    - ``limit``: 检索条数上限（默认 100）
    - ``force_refresh``: ``True`` 时绕过服务端缓存强制重算（**较慢**）
    """
    payload: Dict[str, Any] = {"panel_id": panel_id}
    if keywords is not None:
        payload["keywords"] = _split_list(keywords)
    if must_keywords is not None:
        payload["must_keywords"] = _split_list(must_keywords)
    if should_keywords is not None:
        payload["should_keywords"] = _split_list(should_keywords)
    if cvc_id is not None:
        payload["cvc_id"] = cvc_id
    if cvc_name is not None:
        payload["cvc_name"] = cvc_name
    if sources is not None:
        payload["sources"] = sources
    if time_window_days is not None:
        payload["time_window_days"] = int(time_window_days)
    if limit is not None:
        payload["limit"] = int(limit)
    if force_refresh is not None:
        payload["force_refresh"] = bool(force_refresh)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_PANEL_DATA, json_data=payload)


def panel_batch(
    panel_ids: Any,
    keywords: str,
    *,
    cvc_name: Optional[str] = None,
    days: Optional[int] = None,
    force_refresh: Optional[bool] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """批量获取多个面板数据（GET /panel/batch）。

    逐面板返回结果与错误，``{"results": {...}, "errors": {...}, "timestamp": ...}``。

    - ``panel_ids``（必填）: 面板 ID 列表，支持 ``["a", "b"]`` 或逗号分隔字符串
      ``"a,b"``（列表会被 join 为逗号分隔串）
    - ``keywords``（必填）: 逗号分隔的关键词列表（对所有面板生效）
    - ``cvc_name`` / ``days`` / ``force_refresh``: 同 :func:`panel_data`
      （``force_refresh=True`` 会绕过服务端缓存，**较慢**）
    """
    ids = _split_list(panel_ids)
    if not ids:
        raise ValidationError("panel_ids must be a non-empty list or comma-separated string.")
    if not keywords:
        raise ValidationError("keywords must be a non-empty comma-separated string.")
    params: Dict[str, Any] = {"panel_ids": ",".join(ids), "keywords": keywords}
    if cvc_name is not None:
        params["cvc_name"] = cvc_name
    if days is not None:
        params["days"] = int(days)
    if force_refresh is not None:
        params["force_refresh"] = bool(force_refresh)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_PANEL_BATCH, params=params)


def panel_batch_post(
    panels: List[Dict[str, Any]],
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """批量获取多个面板数据（POST /panel/batch）。

    - ``panels``（必填）: 面板请求对象列表，每项字段与 :func:`panel_data_post`
      的请求体一致（至少含 ``panel_id``）。一次请求内逐面板返回结果与错误，
      ``{"success": True, "data": {"results": [...], "errors": {...}}}``。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_PANEL_BATCH, json_data={"panels": panels})


def panel_cache_stats(
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """面板缓存统计（GET /panel/cache/stats）。

    返回缓存条目总数与最近 24 小时新增数，``{"total": int, "recent_24h": int}``。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_PANEL_CACHE_STATS)


def panel_cache_clear(
    *,
    panel_id: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """清除面板缓存（DELETE /panel/cache）。

    - ``panel_id``: 指定则仅清除该面板缓存；省略则清除**全部**面板缓存
    """
    params: Dict[str, Any] = {}
    if panel_id is not None:
        params["panel_id"] = panel_id
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.delete(PATH_PANEL_CACHE, params=params)
