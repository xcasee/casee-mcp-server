"""casee SDK — 媒体与抓取/调度接口（v1.10 新增）。

对应端点：

- ``POST /images/upload``：把图片上传到主服务器本地存储（分布式场景下远程
  sensor 下载图片后同步到主服务器，使情报里的 ``image_url`` 指向主服务器）
- ``GET /images/{filename}``：下载主服务器本地图片（非 JSON，返回字节）
- ``GET /scrape``：抓取指定 URL 的页面内容（经 gateway 派发到 sensor）
- ``POST /scheduler/run``：手动触发一轮采集（经 gateway 派发到 sensor）

函数式便捷接口：
    from casee import upload_image, download_image, scrape_page, run_scheduler

    upload_image("news-001.jpg", "./cover.jpg", api_key="sk_xxx")
    blob = download_image("news-001.jpg", api_key="sk_xxx")
    page = scrape_page("https://example.com/a.html", api_key="sk_xxx")
    run_scheduler(api_key="sk_xxx")
"""
from __future__ import annotations

import os
from typing import Any, BinaryIO, Dict, Optional, Union

from .client import HTTPClient
from .constants import (
    PATH_IMAGE,
    PATH_IMAGES_UPLOAD,
    PATH_SCHEDULER_RUN,
    PATH_SCRAPE,
)

_FileSource = Union[str, bytes, bytearray, BinaryIO]


def _to_files_part(filename: str, source: _FileSource) -> Any:
    """把路径 / 字节 / 文件对象统一转成 httpx ``files=`` 需要的元组。

    返回 ``(part, opened_fh)``：``opened_fh`` 非 None 时表示本函数打开了文件，
    由调用方负责关闭。
    """
    if isinstance(source, (bytes, bytearray)):
        return (filename, bytes(source), None), None
    if isinstance(source, str):
        if not os.path.isfile(source):
            raise FileNotFoundError(f"image file not found: {source}")
        fh = open(source, "rb")
        return (filename, fh, None), fh
    return (filename, source, None), None


def upload_image(
    filename: str,
    file: _FileSource,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """上传图片到主服务器本地存储（POST /images/upload，multipart/form-data）。

    - ``filename``: 目标文件名（不含路径；服务端会做路径穿越与扩展名校验）
    - ``file``: 图片来源，支持**本地路径**、**bytes** 或**文件对象**

    主要用于分布式场景：远程 sensor 抓到情报后把配图同步到主服务器，避免
    情报中的 ``image_url`` 指向 sensor 本地地址导致前端 404。
    """
    if not filename or "/" in filename or "\\" in filename:
        from .exceptions import ValidationError

        raise ValidationError(
            f"filename must be a bare file name without path separators, got: {filename!r}"
        )
    part, opened = _to_files_part(filename, file)
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        try:
            return client.post_files(
                PATH_IMAGES_UPLOAD,
                files={"file": part},
                data={"filename": filename},
            )
        finally:
            # 由本函数以路径方式打开的文件句柄需自行关闭
            if opened is not None:
                opened.close()


def download_image(
    filename: str,
    *,
    save_to: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> bytes:
    """下载主服务器本地图片（GET /images/{filename}）。

    该端点是图片服务端（非 JSON），因此返回**原始 bytes**。

    - ``save_to``: 可选，给出本地路径则同时写入该文件
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        blob = client.get_bytes(PATH_IMAGE.format(filename=filename))
    if save_to:
        with open(save_to, "wb") as fh:
            fh.write(blob)
    return blob


def scrape_page(
    url: str,
    *,
    timeout: Optional[Any] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """抓取页面内容（GET /scrape，经 gateway 派发到 sensor）。

    - ``url``: 目标页面地址
    - ``timeout``: 服务端抓取超时（按端点定义为可选查询参数，原样透传）

    注意：该请求需经 gateway 派发到采集探针执行，**延迟可能较高**，
    调用方可适当加大 SDK 侧 ``timeout``。
    """
    params: Dict[str, Any] = {"url": url}
    if timeout is not None:
        params["timeout"] = timeout
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_SCRAPE, params=params)


def run_scheduler(
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """手动触发一轮采集（POST /scheduler/run，经 gateway 派发到 sensor）。

    无请求体与查询参数。返回触发结果摘要（创建任务数等）。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.post(PATH_SCHEDULER_RUN)
