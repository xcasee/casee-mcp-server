"""casee — CaSee Intelligence Server Python SDK.

快速开始：
    from casee import search

    result = search("AI,Nvidia", api_key="sk_xxx", days=30)

    from casee import search_advanced, search, semantic_search

    # 高级检索：AND/OR/NOT 复杂逻辑
    result = search_advanced("+EV +(battery|charging) -China", source_ids=["reuters"],
                             api_key="sk_xxx")

    # 语义检索：基于 CVC 模型的混合检索
    result = semantic_search(
        cvc_model_id="cvc_9f8e7d6c",
        q="竞争对手在东南亚的电动化布局战略",
        mode="hybrid",
        top_k=20,
        api_key="sk_xxx",
    )

    # CVC 模型与关联情报管理（v1.7 新增）
    from casee import list_cvc_models, list_associated_docs, link_docs, unlink_docs

    list_cvc_models(api_key="sk_xxx")           # 模型列表（含关联 doc 数）
    list_associated_docs("cvc_9f8e7d6c", api_key="sk_xxx")
    link_docs("cvc_9f8e7d6c", ["66b1f0a1..."], q="人工补关联", api_key="sk_xxx")
    unlink_docs("cvc_9f8e7d6c", ["66b1f0a1..."], api_key="sk_xxx")  # 不删情报本身

环境变量：
    - ``CASEE_API_KEY``: API Key
    - ``CASEE_API_BASE_URL``: API 基址（默认 http://121.43.113.132:8000）
    - ``CASEE_TIMEOUT``: 请求超时（秒，默认 30）
"""
from .constants import (
    DEFAULT_API_BASE_URL,
    DEFAULT_DAYS,
    DEFAULT_ENGINE,
    DEFAULT_LIMIT,
    DEFAULT_MIN_TSCORE,
    DEFAULT_TIMEOUT,
    ENGINE_ENTITIES,
    ENGINE_FEED,
    ENGINE_INTELLIGENCE,
    ENGINE_LATEST,
    ENGINE_SOURCE,
    SEMANTIC_MODE_HYBRID,
    SEMANTIC_MODE_SEMANTIC,
    SEMANTIC_MODE_KEYWORD,
    SUPPORTED_ENGINES,
    SUPPORTED_SEMANTIC_MODES,
    __version__,
)
from .exceptions import (
    APIError,
    AuthenticationError,
    CaseeError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)
from .cvc import (
    batch_delete_cvc_models,
    cvc_cache_purge,
    cvc_cleanup_status,
    cvc_reindex,
    cvc_stats,
    delete_cvc_model,
    link_docs,
    list_associated_docs,
    list_cvc_models,
    register_cvc_model,
    unlink_docs,
)
from .models import (
    AssociatedDocsResponse,
    CvcLinkResult,
    CvcModelInfo,
    CvcModelsResponse,
    CvcUnlinkResult,
    IntelligenceItem,
    LocationsResponse,
    SearchInformation,
    SearchMetadata,
    SearchParameters,
    SearchResponse,
    SourceInfo,
    StatsResponse,
)
from .search import (
    AdvancedSearch,
    BatchSearch,
    EntitySearch,
    IntelligenceKeywordSearch,
    IntelligenceSearch,
    LatestBySource,
    LatestIntelligence,
    QuickSearch,
    SemanticSearch,
    SourceFeedSearch,
    aggregate_by_source,
    analyze_trend,
    get_locations,
    get_organic_results,
    get_stats,
    search,
    search_advanced,
    search_batch,
    semantic_search,
)
from .many import search_many  # [v1.8.1] 批量检索助手（本地并发编排）
from .purge import (  # [v1.9] 全量历史情报清除
    get_intelligence_purge_status,
    intelligence_purge,
    intelligence_purge_status,
)
from .search_terms import clean_keywords  # [v1.8.1] 内置检索词卫生化

# ---- 数据类家族（v1.10 新增覆盖，对齐 is-server openapi）----
from .feed import (  # 信源视角聚合
    feed_by_id,
    feed_by_name,
    feed_stats,
    source_latest,
)
from .trust import trust_source, trust_stats  # 信源信任分
from .intel import (  # intelligence 家族
    intel_entities,
    intel_latest,
    intel_localize_images,
    intel_stats,
)
from .catalog import (  # 采集探针
    discover_sensors,
    get_sensor,
    list_sensors,
    set_sensor_status,
)
from .tasks import (  # 采集任务
    cancel_task,
    create_task,
    get_task,
    list_tasks,
    tasks_stats,
)
from .logs import get_log, latest_log, list_logs  # 采集运行日志
from .monitor import (  # 采集监控
    monitor_dashboard,
    monitor_run_sources,
    monitor_sources,
    monitor_trend,
)
from .panel import (  # 面板数据
    panel_batch,
    panel_batch_post,
    panel_cache_clear,
    panel_cache_stats,
    panel_data,
    panel_data_post,
)
from .access import (  # [v1.11] 访问分析（审计面）
    access_anomalies,
    access_anomaly_detail,
    access_filters,
    access_latency,
    access_logs,
    access_overview,
    access_queries,
    access_sources,
    access_timeseries,
)
from .news import (  # 内容源（AI/站点新闻、上传）
    news_ai,
    news_site,
    news_upload,
    news_upload_remote,
)
from .media import (  # 图片与抓取/调度
    download_image,
    run_scheduler,
    scrape_page,
    upload_image,
)

__all__ = [
    # 版本
    "__version__",
    # 核心类
    "QuickSearch",
    "AdvancedSearch",
    "SemanticSearch",
    "BatchSearch",  # [v1.9] 服务端批量检索
    # 向后兼容类（deprecated）
    "IntelligenceSearch",
    "IntelligenceKeywordSearch",
    "EntitySearch",
    "LatestIntelligence",
    "SourceFeedSearch",
    "LatestBySource",
    # 函数式接口
    "search",
    "search_advanced",
    "search_many",
    "clean_keywords",
    "search_batch",  # [v1.9] 服务端批量检索
    "semantic_search",
    "get_organic_results",
    "get_stats",
    "get_locations",
    # CVC 模型与关联情报管理（v1.7 新增）
    "list_cvc_models",
    "register_cvc_model",
    "delete_cvc_model",
    "batch_delete_cvc_models",
    "list_associated_docs",
    "link_docs",
    "unlink_docs",
    # CVC 运维接口（v1.9 新增）
    "cvc_stats",
    "cvc_cache_purge",
    "cvc_cleanup_status",
    "cvc_reindex",
    # 全量历史情报清除（v1.9 新增）
    "intelligence_purge",
    "intelligence_purge_status",
    "get_intelligence_purge_status",
    # 数据类家族（v1.10 新增覆盖）
    # 信源视角聚合
    "feed_stats",
    "feed_by_id",
    "feed_by_name",
    "source_latest",
    # 信任分
    "trust_stats",
    "trust_source",
    # intelligence 家族
    "intel_latest",
    "intel_entities",
    "intel_localize_images",
    "intel_stats",
    # 采集探针
    "list_sensors",
    "discover_sensors",
    "get_sensor",
    "set_sensor_status",
    # 采集任务
    "list_tasks",
    "create_task",
    "tasks_stats",
    "get_task",
    "cancel_task",
    # 采集运行日志
    "latest_log",
    "list_logs",
    "get_log",
    # 采集监控
    "monitor_dashboard",
    "monitor_sources",
    "monitor_trend",
    "monitor_run_sources",
    # 访问分析（v1.11）
    "access_overview",
    "access_timeseries",
    "access_sources",
    "access_queries",
    "access_latency",
    "access_anomalies",
    "access_anomaly_detail",
    "access_logs",
    "access_filters",
    # 检索聚合（v1.11）
    "analyze_trend",
    "aggregate_by_source",
    # 面板数据
    "panel_data",
    "panel_data_post",
    "panel_batch",
    "panel_batch_post",
    "panel_cache_stats",
    "panel_cache_clear",
    # 内容源
    "news_ai",
    "news_site",
    "news_upload",
    "news_upload_remote",
    # 图片与抓取/调度
    "upload_image",
    "download_image",
    "scrape_page",
    "run_scheduler",
    # 类型
    "SearchMetadata",
    "SearchParameters",
    "SearchInformation",
    "SearchResponse",
    "IntelligenceItem",
    "SourceInfo",
    "StatsResponse",
    "LocationsResponse",
    "CvcModelInfo",
    "CvcModelsResponse",
    "AssociatedDocsResponse",
    "CvcLinkResult",
    "CvcUnlinkResult",
    # 异常
    "CaseeError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "NotFoundError",
    "ServerError",
    "TimeoutError",
    "NetworkError",
    "APIError",
    # 语义检索常量
    "SEMANTIC_MODE_HYBRID",
    "SEMANTIC_MODE_SEMANTIC",
    "SEMANTIC_MODE_KEYWORD",
    "SUPPORTED_SEMANTIC_MODES",
    # 向后兼容常量（deprecated，v2.0 移除）
    "DEFAULT_API_BASE_URL",
    "DEFAULT_DAYS",
    "DEFAULT_ENGINE",
    "DEFAULT_LIMIT",
    "DEFAULT_MIN_TSCORE",
    "DEFAULT_TIMEOUT",
]
