"""casee SDK — 信源信任分（tscore）接口（v1.10 新增覆盖）。

对应 ``/trust/*`` 端点，提供信源信任分的查询能力：

- 信任分分布统计（各分档信源数）：``GET /trust/stats``
- 单个信源详情（含 tscore 因子分解）：``GET /trust/{source_id}``

函数式便捷接口：
    from casee.trust import trust_stats, trust_source

    # 信任分分布
    dist = trust_stats(api_key="sk_xxx")

    # 单信源详情（含因子分解）
    detail = trust_source("reuters", api_key="sk_xxx")
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from .client import HTTPClient
from .constants import PATH_TRUST_SOURCE, PATH_TRUST_STATS


def trust_stats(
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """信任分分布统计（GET /trust/stats）。

    返回各信任分档（bucket）的信源数量分布。
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_TRUST_STATS)


def trust_source(
    source_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """单个信源信任分详情（GET /trust/{source_id}）。

    含该信源 tscore 的因子分解（各评分维度贡献）。

    - ``source_id``: 信源 ID（必填）
    """
    with HTTPClient(api_key=api_key, base_url=base_url) as client:
        return client.get(PATH_TRUST_SOURCE.format(source_id=source_id))
